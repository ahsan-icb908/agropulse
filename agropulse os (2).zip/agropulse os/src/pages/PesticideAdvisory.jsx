import { useState } from 'react';
import { ShieldCheck, FlaskConical, Leaf, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const PESTS = [
  { key: 'aphids', label: 'Aphids', treatment: 'Neem Oil (Azadirachtin)', rate: 2.5, unit: 'ml per liter water', interval: '7 days', eco: true, safety: 'Spray early morning or late evening. Wear gloves. Avoid flowering stage to protect bees. Re-apply after rain.' },
  { key: 'bollworm', label: 'Bollworm / Fruit borer', treatment: 'Bacillus thuringiensis (Bt)', rate: 1, unit: 'kg per hectare', interval: '10 days', eco: true, safety: 'Harmless to humans, animals, and beneficial insects. Apply when larvae are small (under 5mm). Best results at 25°C.' },
  { key: 'whitefly', label: 'Whitefly', treatment: 'Yellow Sticky Traps', rate: 5, unit: 'traps per hectare', interval: 'Replace monthly', eco: true, safety: 'Non-toxic. Place traps just above the crop canopy. Monitor weekly and replace when full.' },
  { key: 'fungal', label: 'Fungal disease', treatment: 'Bordeaux Mixture', rate: 7.5, unit: 'g per liter (0.75% solution)', interval: '14 days', eco: true, safety: 'Wear mask and gloves while mixing. Do not spray in direct sunlight. Stop 7 days before harvest.' },
  { key: 'nematodes', label: 'Nematodes', treatment: 'Marigold intercropping + crop rotation', rate: 0, unit: 'Plant marigold as barrier crop', interval: 'Season-long', eco: true, safety: 'Biological control — no chemical exposure. Plant marigold 2 weeks before main crop.' },
  { key: 'armyworm', label: 'Armyworm', treatment: 'NPV (Nuclear Polyhedrosis Virus)', rate: 250, unit: 'LE per hectare', interval: '7 days', eco: true, safety: 'Specific to caterpillars — safe for all other organisms. Apply at dusk (UV sensitive).' },
];

export default function PesticideAdvisory() {
  const [pest, setPest] = useState('aphids');
  const [area, setArea] = useState('');
  const [water, setWater] = useState('');

  const selected = PESTS.find((p) => p.key === pest);
  const totalProduct = selected && area ? (selected.rate * parseFloat(area)).toFixed(1) : null;
  const totalWater = water ? parseFloat(water) : null;
  const productPerTank = totalWater && selected ? (selected.rate * totalWater).toFixed(1) : null;

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">Pesticide Advisory</h1>
        <p className="text-sm text-muted-foreground mt-1">Eco-friendly dosage calculators and chemical safety guides for responsible pest management.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Widget>
          <WidgetHeader title="Dosage Calculator" icon={FlaskConical} />
          <WidgetBody className="space-y-4">
            <div>
              <Label>Pest / Problem</Label>
              <Select value={pest} onValueChange={setPest}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>{PESTS.map((p) => <SelectItem key={p.key} value={p.key}>{p.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div><Label>Area (hectares)</Label><Input type="number" value={area} onChange={(e) => setArea(e.target.value)} className="mt-1" placeholder="2.5" /></div>
            <div><Label>Tank size (liters of water)</Label><Input type="number" value={water} onChange={(e) => setWater(e.target.value)} className="mt-1" placeholder="200" /></div>
          </WidgetBody>
        </Widget>

        <Widget>
          <WidgetHeader title="Recommendation" icon={ShieldCheck} />
          <WidgetBody className="space-y-4">
            <div className="rounded-lg border border-border p-3">
              <div className="flex items-center justify-between">
                <p className="font-semibold text-sm">{selected.treatment}</p>
                <Badge variant="secondary" className="gap-1 bg-emerald-500/10 text-emerald-700"><Leaf className="w-3 h-3" /> Eco-friendly</Badge>
              </div>
              <p className="text-xs text-muted-foreground mt-1">Rate: {selected.rate} {selected.unit}</p>
              <p className="text-xs text-muted-foreground">Repeat every {selected.interval}</p>
            </div>
            {totalProduct && (
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-lg bg-primary/5 p-3"><p className="text-xs text-muted-foreground">Total product needed</p><p className="font-heading text-lg font-bold mt-0.5">{totalProduct} <span className="text-xs font-normal">{selected.unit.includes('ml') ? 'ml' : selected.unit.includes('kg') ? 'kg' : 'units'}</span></p></div>
                {productPerTank && <div className="rounded-lg bg-primary/5 p-3"><p className="text-xs text-muted-foreground">Product per tank</p><p className="font-heading text-lg font-bold mt-0.5">{productPerTank} ml</p></div>}
              </div>
            )}
            <div className="rounded-lg bg-amber-500/5 border border-amber-500/20 p-3">
              <p className="text-xs font-semibold flex items-center gap-1.5 text-amber-700"><AlertTriangle className="w-3.5 h-3.5" /> Safety Guidelines</p>
              <p className="text-xs text-muted-foreground mt-1.5 leading-relaxed">{selected.safety}</p>
            </div>
          </WidgetBody>
        </Widget>
      </div>

      <Widget>
        <WidgetHeader title="Non-Toxic Alternatives" icon={Leaf} />
        <WidgetBody>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {[
              { name: 'Companion Planting', desc: 'Plant marigold, basil, or mint alongside crops to naturally repel pests.' },
              { name: 'Crop Rotation', desc: 'Rotate crop families each season to break pest and disease cycles.' },
              { name: 'Neem Spray', desc: 'Broad-spectrum organic spray. 5 ml neem oil + 1 ml soap per liter water.' },
              { name: 'Trichoderma', desc: 'Beneficial fungus that prevents soil-borne diseases. Apply to soil.' },
              { name: 'Pheromone Traps', desc: 'Species-specific traps that monitor and reduce pest populations.' },
              { name: 'Mulching', desc: 'Organic mulch suppresses weeds and retains soil moisture naturally.' },
            ].map((alt) => (
              <div key={alt.name} className="rounded-lg border border-border p-3">
                <p className="text-sm font-medium flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> {alt.name}</p>
                <p className="text-xs text-muted-foreground mt-1">{alt.desc}</p>
              </div>
            ))}
          </div>
        </WidgetBody>
      </Widget>
    </div>
  );
}