import { useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Upload, Leaf, Sparkles, X, AlertCircle, CheckCircle2, Loader2, RotateCcw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useCollection } from '@/hooks/useCollection';
import { cn } from '@/lib/utils';

const ACCEPTED = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_MB = 8;

export default function CropScan() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const inputRef = useRef(null);

  const [file, setFile] = useState(null);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [crop, setCrop] = useState('');
  const [symptoms, setSymptoms] = useState('');
  const [error, setError] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);

  const { data: fields } = useCollection('Field', { sort: '-created_date', limit: 100 });

  function handleFile(f) {
    setError('');
    if (!f) return;
    if (!ACCEPTED.includes(f.type)) {
      setError('Please upload a JPG, PNG, or WebP image.');
      return;
    }
    if (f.size > MAX_MB * 1024 * 1024) {
      setError(`Image must be under ${MAX_MB} MB.`);
      return;
    }
    setFile(f);
    setPreviewUrl(URL.createObjectURL(f));
    setResult(null);
  }

  function reset() {
    setFile(null);
    setPreviewUrl(null);
    setCrop('');
    setSymptoms('');
    setError('');
    setResult(null);
    if (inputRef.current) inputRef.current.value = '';
  }

  async function analyze() {
    if (!file) {
      setError('Upload a crop photo first.');
      return;
    }
    setAnalyzing(true);
    setError('');
    try {
      // 1. Upload to private storage (stored privately)
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      // 2. Analyse the photo with the workspace's own Gemini key (server-side).
      const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({ file_uri, expires_in: 300 });
      const res = await base44.functions.invoke('cropScan', { image_url: signed_url, crop, symptoms });
      const data = res.data || {};
      if (data.status !== 'ok') {
        throw new Error(data.message || 'Analysis failed. Please try again.');
      }

      const parsed = {
        diagnosis: data.diagnosis,
        confidence: data.confidence,
        possible_causes: data.possible_causes || [],
        next_steps: data.next_steps || [],
        needs_expert: data.needs_expert,
        note: data.note,
      };
      setResult(parsed);
      // 3. Persist the analysis record (linked to a field if provided).
      await base44.entities.CropAnalysis.create({
        crop: crop || 'Unknown',
        symptoms,
        image_uri: file_uri,
        result: parsed?.diagnosis || '',
        confidence: parsed?.confidence ?? null,
        possible_causes: parsed?.possible_causes || [],
        next_steps: parsed?.next_steps || [],
        status: parsed?.diagnosis === 'Unclear image' ? 'unavailable' : 'analyzed',
        needs_expert: !!parsed?.needs_expert,
      });
    } catch (e) {
      setError(e?.message || 'Analysis failed. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">{t('nav.cropscan')}</h1>
        <p className="text-sm text-muted-foreground mt-1">
          Upload a photo of a plant — AI scans for symptoms and suggests possible causes and next steps.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* Upload + form */}
        <Widget>
          <WidgetHeader title="1. Upload & describe" icon={Upload} />
          <WidgetBody className="space-y-4">
            <input
              ref={inputRef}
              type="file"
              accept={ACCEPTED.join(',')}
              className="hidden"
              onChange={(e) => handleFile(e.target.files?.[0])}
            />

            {!previewUrl ? (
              <button
                onClick={() => inputRef.current?.click()}
                className="w-full rounded-2xl border-2 border-dashed border-border hover:border-primary/50 hover:bg-primary/5 transition-colors py-10 flex flex-col items-center gap-2 text-muted-foreground"
              >
                <span className="w-12 h-12 rounded-full bg-primary/10 text-primary flex items-center justify-center">
                  <Upload className="w-6 h-6" />
                </span>
                <span className="font-medium text-foreground">Tap to upload a crop photo</span>
                <span className="text-xs">JPG, PNG or WebP · max {MAX_MB} MB</span>
              </button>
            ) : (
              <div className="relative rounded-2xl overflow-hidden border border-border bg-muted/30">
                <img src={previewUrl} alt="crop preview" className="w-full h-56 object-cover" />
                <button
                  onClick={reset}
                  className="absolute top-2 end-2 w-8 h-8 rounded-full bg-black/60 text-white flex items-center justify-center hover:bg-black/80"
                  aria-label="Remove"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}

            <div className="grid gap-3">
              <div>
                <Label htmlFor="crop">Crop (optional)</Label>
                <Input id="crop" list="field-crops" value={crop} onChange={(e) => setCrop(e.target.value)} placeholder="e.g. Wheat, Maize, Tomato" className="mt-1" />
                <datalist id="field-crops">
                  {[...new Set(fields.map((f) => f.crop).filter(Boolean))].map((c) => (
                    <option key={c} value={c} />
                  ))}
                </datalist>
              </div>
              <div>
                <Label htmlFor="symptoms">Observed symptoms (optional)</Label>
                <Textarea id="symptoms" value={symptoms} onChange={(e) => setSymptoms(e.target.value)} placeholder="e.g. yellowing leaves, brown spots on stems" className="mt-1" rows={3} />
              </div>
            </div>

            {error && (
              <div className="flex items-start gap-2 text-sm text-destructive bg-destructive/10 rounded-lg p-3">
                <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <div className="flex gap-2">
              <Button onClick={analyze} disabled={!file || analyzing} className="flex-1 gap-2">
                {analyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                {analyzing ? 'Analyzing…' : 'Scan with AI'}
              </Button>
              <Button variant="outline" onClick={reset} disabled={analyzing} className="gap-2">
                <RotateCcw className="w-4 h-4" /> Reset
              </Button>
            </div>
            <p className="text-[11px] text-muted-foreground">
              Photos are uploaded (stored privately) and analyzed by an AI model. Results are advisory — confirm with an agronomist before treatment.
            </p>
          </WidgetBody>
        </Widget>

        {/* Result */}
        <Widget>
          <WidgetHeader title="2. AI analysis" icon={Leaf} />
          <WidgetBody>
            {!result && !analyzing && (
              <div className="flex flex-col items-center justify-center text-center py-16 text-muted-foreground">
                <Leaf className="w-10 h-10 mb-3 opacity-40" />
                <p className="text-sm">Your diagnosis will appear here.</p>
              </div>
            )}
            {analyzing && (
              <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
                <Loader2 className="w-8 h-8 animate-spin text-primary mb-3" />
                <p className="text-sm">Scanning image for symptoms…</p>
              </div>
            )}
            {result && (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-xs text-muted-foreground">Diagnosis</p>
                    <p className="text-xl font-heading font-bold">{result.diagnosis || '—'}</p>
                  </div>
                  {typeof result.confidence === 'number' && (
                    <Badge className={cn('text-sm', confidenceTone(result.confidence))}>
                      {result.confidence}% confidence
                    </Badge>
                  )}
                </div>

                {result.note && (
                  <p className="text-xs text-muted-foreground bg-muted/50 rounded-lg p-3">{result.note}</p>
                )}

                {result.possible_causes?.length > 0 && (
                  <div>
                    <p className="text-sm font-semibold mb-1.5">Possible causes</p>
                    <ul className="space-y-1.5">
                      {result.possible_causes.map((c, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-2 shrink-0" />
                          {c}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {result.next_steps?.length > 0 && (
                  <div>
                    <p className="text-sm font-semibold mb-1.5">Suggested next steps</p>
                    <ul className="space-y-1.5">
                      {result.next_steps.map((s, i) => (
                        <li key={i} className="flex items-start gap-2 text-sm">
                          <CheckCircle2 className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                          {s}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}

                {result.needs_expert && (
                  <div className="flex items-start gap-2 text-sm bg-amber-500/10 text-amber-700 dark:text-amber-400 rounded-lg p-3">
                    <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
                    <span>An expert agronomist assessment is recommended before acting.</span>
                  </div>
                )}

                <div className="flex gap-2 pt-2">
                  <Button variant="outline" size="sm" onClick={() => navigate('/farms')} className="gap-2">
                    View farm records
                  </Button>
                  <Button variant="ghost" size="sm" onClick={reset} className="gap-2">
                    Scan another
                  </Button>
                </div>
              </div>
            )}
          </WidgetBody>
        </Widget>
      </div>
    </div>
  );
}

function confidenceTone(c) {
  if (c >= 75) return 'bg-success/15 text-success';
  if (c >= 50) return 'bg-amber-500/15 text-amber-600';
  return 'bg-muted text-muted-foreground';
}