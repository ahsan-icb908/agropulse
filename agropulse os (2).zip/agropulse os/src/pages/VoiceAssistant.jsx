import { useState } from 'react';
import { Mic, Send, AlertTriangle, RotateCcw } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useI18n } from '@/i18n/LanguageContext';
import { useSpeech } from '@/hooks/useSpeech';
import { useUrduRecognition } from '@/hooks/useUrduRecognition';
import VoiceOrb from '@/components/voice/VoiceOrb';
import AnswerCard from '@/components/voice/AnswerCard';
import DailyBriefing from '@/components/voice/DailyBriefing';

const COPY = {
  en: {
    kicker: 'Urdu voice assistant · SDG 5 & 10',
    title: 'Bolo aur Pucho',
    sub: 'Tap the mic and describe your crop problem in Urdu. The answer is written and spoken in Urdu.',
    idle: 'Tap to speak',
    listening: 'Listening… tap to stop',
    thinking: 'Thinking…',
    typed: 'Or type your question',
    send: 'Ask',
    youSaid: 'You said',
    unsupported: 'Voice recognition is not available in this browser. Type your question below instead.',
    denied: 'Microphone access was refused. Allow it in your browser, or type your question below.',
    unavailable: 'The assistant could not answer right now. Please try again.',
    tooShort: 'Say or type a little more about the problem.',
    example: 'Example: “Gandum ke pattay peele ho rahe hain”',
  },
  ur: {
    kicker: 'اردو آواز معاون · SDG 5 اور 10',
    title: 'بولو اور پوچھو',
    sub: 'مائیک دبائیں اور اپنی فصل کا مسئلہ اردو میں بتائیں۔ جواب اردو میں لکھا اور سنا جائے گا۔',
    idle: 'بولنے کے لیے دبائیں',
    listening: 'سن رہے ہیں… روکنے کے لیے دبائیں',
    thinking: 'سوچ رہا ہے…',
    typed: 'یا یہاں لکھ کر پوچھیں',
    send: 'پوچھیں',
    youSaid: 'آپ نے کہا',
    unsupported: 'اس براؤزر میں آواز کی پہچان دستیاب نہیں۔ نیچے لکھ کر پوچھیں۔',
    denied: 'مائیک کی اجازت نہیں ملی۔ براؤزر میں اجازت دیں یا نیچے لکھ کر پوچھیں۔',
    unavailable: 'ابھی جواب نہیں مل سکا۔ دوبارہ کوشش کریں۔',
    tooShort: 'مسئلے کے بارے میں کچھ اور بتائیں۔',
    example: 'مثال: «گندم کے پتے پیلے ہو رہے ہیں»',
  },
};

export default function VoiceAssistant() {
  const { lang } = useI18n();
  const copy = COPY[lang] || COPY.en;
  const { speak, speaking } = useSpeech();
  const recognition = useUrduRecognition();
  const [answer, setAnswer] = useState(null);
  const [asked, setAsked] = useState('');
  const [thinking, setThinking] = useState(false);
  const [error, setError] = useState(null);
  const [typed, setTyped] = useState('');

  async function ask(question) {
    const text = String(question || '').trim();
    if (text.length < 3) {
      setError(copy.tooShort);
      return;
    }
    setAsked(text);
    setThinking(true);
    setError(null);
    setAnswer(null);
    try {
      const res = await base44.functions.invoke('urduVoiceAdvice', { question: text });
      const data = res.data || {};
      if (data.status === 'ok') {
        setAnswer(data);
        speak(data.answer_ur, 'ur');
      } else {
        setError(data.message || copy.unavailable);
      }
    } catch {
      setError(copy.unavailable);
    } finally {
      setThinking(false);
    }
  }

  function handleMic() {
    if (recognition.listening) {
      recognition.stop();
      return;
    }
    recognition.start((text) => ask(text));
  }

  const micLabel = recognition.listening ? copy.listening : thinking ? copy.thinking : copy.idle;

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
          <Mic className="h-4 w-4" aria-hidden="true" />
          {copy.kicker}
        </div>
        <h1 className="mt-1 font-heading text-2xl font-bold tracking-tight">{copy.title}</h1>
        <p className="mx-auto mt-1 max-w-lg text-sm text-muted-foreground">{copy.sub}</p>
      </div>

      <Widget>
        <WidgetBody className="flex flex-col items-center gap-4 py-8">
          <VoiceOrb
            listening={recognition.listening}
            thinking={thinking}
            disabled={thinking || !recognition.supported}
            onClick={handleMic}
            label={micLabel}
          />

          {!recognition.supported && (
            <p className="max-w-sm text-center text-xs text-amber-700">{copy.unsupported}</p>
          )}
          {recognition.error === 'mic_denied' && (
            <p className="max-w-sm text-center text-xs text-amber-700">{copy.denied}</p>
          )}

          {recognition.transcript && (
            <div className="w-full rounded-lg bg-muted/60 p-3">
              <p className="text-[11px] uppercase tracking-wide text-muted-foreground">{copy.youSaid}</p>
              <p className="mt-1 font-urdu text-end text-base leading-loose" dir="rtl" lang="ur">
                {recognition.transcript}
              </p>
            </div>
          )}

          <p className="text-center text-[11px] text-muted-foreground">{copy.example}</p>
        </WidgetBody>
      </Widget>

      <DailyBriefing />

      {error && (
        <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-800">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          {error}
        </div>
      )}

      {thinking && (
        <p className="text-center text-sm text-muted-foreground">{copy.thinking}</p>
      )}

      {answer && (
        <div className="space-y-3">
          <p className="text-xs text-muted-foreground">
            {copy.youSaid}: <span className="font-urdu" dir="rtl">{asked}</span>
          </p>
          <AnswerCard
            answer={answer}
            speaking={speaking}
            onReplay={() => speak(answer.answer_ur, 'ur')}
          />
          <Button variant="outline" onClick={() => { recognition.reset(); setAnswer(null); setTyped(''); }} className="w-full gap-2">
            <RotateCcw className="h-4 w-4" />
            {lang === 'ur' ? copy.idle : 'Ask another question'}
          </Button>
        </div>
      )}

      <Widget>
        <WidgetHeader title={copy.typed} />
        <WidgetBody>
          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              ask(typed);
            }}
          >
            <Input
              value={typed}
              onChange={(e) => setTyped(e.target.value)}
              placeholder={copy.example}
              dir={lang === 'ur' ? 'rtl' : 'ltr'}
              aria-label={copy.typed}
            />
            <Button type="submit" disabled={thinking || typed.trim().length < 3} className="gap-2">
              <Send className="h-4 w-4" />
              {copy.send}
            </Button>
          </form>
        </WidgetBody>
      </Widget>
    </div>
  );
}