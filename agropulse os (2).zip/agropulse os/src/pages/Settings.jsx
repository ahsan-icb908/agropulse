import { useEffect, useState } from 'react';
import { Languages, User, Shield, Bell, LogOut, Accessibility, Wifi } from 'lucide-react';
import { Switch } from '@/components/ui/switch';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function Settings() {
  const { t, lang, toggleLang } = useI18n();
  const [me, setMe] = useState(null);
  const [lowBandwidth, setLowBandwidth] = useState(() => localStorage.getItem('agropulse.lowBandwidth') === 'true');

  useEffect(() => {
    base44.auth.me().then(setMe).catch(() => {});
    document.documentElement.classList.toggle('low-bandwidth', localStorage.getItem('agropulse.lowBandwidth') === 'true');
  }, []);

  function toggleLowBandwidth() {
    const next = !lowBandwidth;
    setLowBandwidth(next);
    localStorage.setItem('agropulse.lowBandwidth', String(next));
    document.documentElement.classList.toggle('low-bandwidth', next);
  }

  return (
    <div className="space-y-5 max-w-2xl">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">{t('nav.settings')}</h1>
        <p className="text-sm text-muted-foreground mt-1">Your profile and app preferences.</p>
      </div>

      <Widget>
        <WidgetHeader title="Profile" icon={User} />
        <WidgetBody className="space-y-3">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 rounded-full bg-primary/10 text-primary font-bold text-xl flex items-center justify-center">
              {(me?.full_name || me?.email || 'U').slice(0, 1).toUpperCase()}
            </div>
            <div>
              <p className="font-semibold">{me?.full_name || '—'}</p>
              <p className="text-sm text-muted-foreground">{me?.email || '—'}</p>
              <Badge variant="secondary" className="mt-1 capitalize gap-1"><Shield className="w-3 h-3" /> {me?.role || 'user'}</Badge>
            </div>
          </div>
        </WidgetBody>
      </Widget>

      <Widget>
        <WidgetHeader title={t('lang.label')} icon={Languages} />
        <WidgetBody>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-sm">Interface language</p>
              <p className="text-xs text-muted-foreground">English or Urdu (with RTL layout)</p>
            </div>
            <Button onClick={toggleLang} variant="outline" className="gap-2">
              <Languages className="w-4 h-4" />
              {lang === 'en' ? 'اردو میں بدلیں' : 'Switch to English'}
            </Button>
          </div>
        </WidgetBody>
      </Widget>

      <Widget>
        <WidgetHeader title="Notifications" icon={Bell} />
        <WidgetBody>
          <p className="text-sm text-muted-foreground">Notification preferences and subscriptions will appear here.</p>
        </WidgetBody>
      </Widget>

      <Widget>
        <WidgetHeader title="Accessibility & Low-Bandwidth" icon={Accessibility} />
        <WidgetBody className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-sm flex items-center gap-1.5"><Wifi className="w-4 h-4" /> Low-bandwidth mode</p>
              <p className="text-xs text-muted-foreground">Disables animations and effects for 2G/3G networks and basic devices.</p>
            </div>
            <Switch checked={lowBandwidth} onCheckedChange={toggleLowBandwidth} />
          </div>
          <div className="rounded-lg bg-muted/50 p-3 text-xs text-muted-foreground">
            <p className="font-medium text-foreground mb-1">Accessibility features:</p>
            <ul className="space-y-0.5 list-disc list-inside">
              <li>Screen-reader compatible semantic HTML</li>
              <li>Urdu language with RTL layout support</li>
              <li>Keyboard navigable interface</li>
              <li>Reduced motion respects system preferences</li>
            </ul>
          </div>
        </WidgetBody>
      </Widget>

      <Widget>
        <WidgetBody>
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-sm">Sign out</p>
              <p className="text-xs text-muted-foreground">End your session on this device.</p>
            </div>
            <Button variant="outline" className="gap-2" onClick={() => base44.auth.logout('/login')}>
              <LogOut className="w-4 h-4" /> Sign out
            </Button>
          </div>
        </WidgetBody>
      </Widget>

      <p className="text-center text-[11px] text-muted-foreground/60 pt-2">
        Developed by Ahsan Safwan · XI-B Pre-Engg & his team
      </p>
    </div>
  );
}