import { useMemo, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup, Circle } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { Sprout, AlertTriangle, Users, Leaf, ShieldAlert } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import MapList from '@/components/map/MapList';
import MapStatus from '@/components/map/MapStatus';
import MapViewport from '@/components/map/MapViewport';
import useMapRecord from '@/components/map/useMapRecords';
import { stageInfo } from '@/components/fields/GrowthStageBadge';
import { cn } from '@/lib/utils';

const SEV_COLOR = { extreme: '#dc2626', severe: '#ea580c', moderate: '#d97706', minor: '#0284c7' };
const ALERT_PROXIMITY_KM = 5;

function pinIcon(color) {
  return L.divIcon({
    className: 'ap-pin',
    html: `<span style="display:block;width:26px;height:26px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:${color};border:2px solid #fff;box-shadow:0 2px 6px rgba(0,0,0,.35)"></span>`,
    iconSize: [26, 26],
    iconAnchor: [13, 24],
    popupAnchor: [0, -22],
  });
}

function fieldIcon(color, atRisk) {
  return L.divIcon({
    className: 'ap-field-pin',
    html: `<span style="display:flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:6px;background:${color};border:2px solid #fff;box-shadow:0 1px 4px rgba(0,0,0,.3)${atRisk ? ';outline:2px dashed #dc2626;outline-offset:2px' : ''}"><svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/><path d="M2 21c0-3 1.85-5.36 5.08-6"/></svg></span>`,
    iconSize: [22, 22],
    iconAnchor: [11, 11],
    popupAnchor: [0, -11],
  });
}

function haversine(lat1, lng1, lat2, lng2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a = Math.sin(dLat / 2) ** 2 + Math.cos((lat1 * Math.PI) / 180) * Math.cos((lat2 * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

function farmRadiusMeters(areaHectares) {
  return Math.sqrt(Math.max(areaHectares || 1, 0.1) * 10000 / Math.PI);
}

export default function MapPage() {
  const { t } = useI18n();
  const [fly, setFly] = useState(null);
  const [layers, setLayers] = useState({ farms: true, fields: true, alerts: true, reports: true });

  const farmRecords = useMapRecord('Farm');
  const fieldRecords = useMapRecord('Field');
  const alertRecords = useMapRecord('Alert', { status: 'active' });
  const reportRecords = useMapRecord('CivicReport');

  const farmsWithGeo = farmRecords.data;
  const fieldsWithGeo = fieldRecords.data;
  const alertsWithGeo = alertRecords.data;
  const reportsWithGeo = reportRecords.data;

  // Compute proximity: which fields are within ALERT_PROXIMITY_KM of an active alert
  const fieldsAtRisk = useMemo(() => {
    if (!alertsWithGeo.length) return new Map();
    const map = new Map();
    for (const field of fieldsWithGeo) {
      const minDist = Math.min(...alertsWithGeo.map((a) => haversine(field.lat, field.lng, a.lat, a.lng)));
      if (minDist <= ALERT_PROXIMITY_KM) map.set(field.id, minDist);
    }
    return map;
  }, [fieldsWithGeo, alertsWithGeo]);

  const points = useMemo(
    () => [...farmsWithGeo, ...fieldsWithGeo, ...alertsWithGeo, ...reportsWithGeo].map((r) => [r.lat, r.lng]),
    [farmsWithGeo, fieldsWithGeo, alertsWithGeo, reportsWithGeo]
  );

  const select = (layer, record, zoom = 14) => {
    setLayers((c) => ({ ...c, [layer]: true }));
    setFly({ center: [record.lat, record.lng], zoom });
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">{t('nav.map')}</h1>
          <p className="text-sm text-muted-foreground mt-1">Farm boundaries, field growth stages, active hazard alerts and community reports.</p>
        </div>
      </div>

      {/* Proximity warning */}
      {fieldsAtRisk.size > 0 && (
        <div className="flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/5 px-3 py-2 text-sm">
          <ShieldAlert className="w-4 h-4 text-destructive shrink-0" />
          <span className="text-destructive-foreground">{fieldsAtRisk.size} field{fieldsAtRisk.size > 1 ? 's' : ''} within {ALERT_PROXIMITY_KM} km of an active hazard alert.</span>
        </div>
      )}

      {/* Layer toggles */}
      <div className="flex flex-wrap gap-2">
        <LayerToggle active={layers.farms} onClick={() => setLayers((l) => ({ ...l, farms: !l.farms }))} color="bg-primary" icon={Sprout} label={`Farms (${farmRecords.count ?? '…'})`} />
        <LayerToggle active={layers.fields} onClick={() => setLayers((l) => ({ ...l, fields: !l.fields }))} color="bg-emerald-500" icon={Leaf} label={`Fields (${fieldRecords.count ?? '…'})`} />
        <LayerToggle active={layers.alerts} onClick={() => setLayers((l) => ({ ...l, alerts: !l.alerts }))} color="bg-orange-500" icon={AlertTriangle} label={`Alerts (${alertRecords.count ?? '…'})`} />
        <LayerToggle active={layers.reports} onClick={() => setLayers((l) => ({ ...l, reports: !l.reports }))} color="bg-sky-500" icon={Users} label={`Reports (${reportRecords.count ?? '…'})`} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Map */}
        <Widget className="lg:col-span-2 p-0 overflow-hidden">
          <div className="h-[60vh] min-h-[420px] w-full">
            <MapContainer center={[31.4504, 73.135]} zoom={11} scrollWheelZoom className="h-full w-full isolate" aria-label="Farm and hazard map">
              <TileLayer attribution='&copy; OpenStreetMap' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
              <MapViewport points={points} target={fly} />

              {/* Farm boundary circles */}
              {layers.farms && farmsWithGeo.map((f) => (
                <Circle key={`c-${f.id}`} center={[f.lat, f.lng]} radius={farmRadiusMeters(f.area_hectares)} pathOptions={{ color: '#16a34a', weight: 2, fillColor: '#16a34a', fillOpacity: 0.06 }} />
              ))}

              {/* Farm pins */}
              {layers.farms && farmsWithGeo.map((f) => (
                <Marker key={`f-${f.id}`} position={[f.lat, f.lng]} icon={pinIcon('#16a34a')}>
                  <Popup>
                    <strong>{f.name}</strong><br />
                    {f.location_text}<br />
                    {f.crop_focus ? `Crop focus: ${f.crop_focus}` : ''}<br />
                    {f.area_hectares ? `${f.area_hectares} ha` : ''}
                  </Popup>
                </Marker>
              ))}

              {/* Field pins (colored by growth stage, dashed ring if at risk) */}
              {layers.fields && fieldsWithGeo.map((field) => {
                const info = stageInfo(field.growth_stage);
                const atRisk = fieldsAtRisk.has(field.id);
                return (
                  <Marker key={`fld-${field.id}`} position={[field.lat, field.lng]} icon={fieldIcon(info.color, atRisk)}>
                    <Popup>
                      <strong>{field.name}</strong><br />
                      {field.farm_name || '—'}<br />
                      {field.crop ? `Crop: ${field.crop}` : ''}<br />
                      <span style={{ color: info.color }}>● {info.label}</span><br />
                      {atRisk && <span style={{ color: '#dc2626' }}>⚠ Within {ALERT_PROXIMITY_KM} km of active alert</span>}
                    </Popup>
                  </Marker>
                );
              })}

              {/* Alert pins */}
              {layers.alerts && alertsWithGeo.map((a) => (
                <Marker key={`a-${a.id}`} position={[a.lat, a.lng]} icon={pinIcon(SEV_COLOR[a.severity] || '#d97706')}>
                  <Popup>
                    <strong>{a.title}</strong><br />
                    <span style={{ textTransform: 'capitalize' }}>{a.severity}</span> · {a.category}<br />
                    {a.area}<br />
                    <em>Source: {a.source || '—'}</em>
                  </Popup>
                </Marker>
              ))}

              {/* Report pins */}
              {layers.reports && reportsWithGeo.map((r) => (
                <Marker key={`r-${r.id}`} position={[r.lat, r.lng]} icon={pinIcon('#0284c7')}>
                  <Popup>
                    <strong>{r.title}</strong><br />
                    {r.reference_number} · <span style={{ textTransform: 'capitalize' }}>{r.status}</span><br />
                    {r.location_text}
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>
        </Widget>

        {/* Side list */}
        <div className="space-y-4">
          <MapList title="Active alerts" icon={AlertTriangle} tone="text-orange-600" records={alertRecords} onPick={(a) => select('alerts', a, 13)} render={(a) => (
            <>
              <p className="font-medium text-sm truncate">{a.title}</p>
              <p className="text-xs text-muted-foreground capitalize">{a.severity} · {a.category}</p>
            </>
          )} badge={(a) => <span className="w-2.5 h-2.5 rounded-full" style={{ background: SEV_COLOR[a.severity] || '#d97706' }} />} />

          <MapList title="Fields" icon={Leaf} tone="text-emerald-600" records={fieldRecords} onPick={(f) => select('fields', f)} render={(f) => {
            const info = stageInfo(f.growth_stage);
            const atRisk = fieldsAtRisk.has(f.id);
            return (
              <>
                <p className="font-medium text-sm truncate flex items-center gap-1.5">
                  {f.name}
                  {atRisk && <ShieldAlert className="w-3 h-3 text-destructive shrink-0" />}
                </p>
                <p className="text-xs text-muted-foreground truncate">{f.crop || '—'} · <span style={{ color: info.color }}>{info.label}</span></p>
              </>
            );
          }} badge={(f) => <span className="w-2.5 h-2.5 rounded-full" style={{ background: stageInfo(f.growth_stage).color }} />} />

          <MapList title="Farms" icon={Sprout} tone="text-primary" records={farmRecords} onPick={(f) => select('farms', f)} render={(f) => (
            <>
              <p className="font-medium text-sm truncate">{f.name}</p>
              <p className="text-xs text-muted-foreground truncate">{f.location_text} · {f.crop_focus || '—'}</p>
            </>
          )} badge={() => <span className="w-2.5 h-2.5 rounded-full bg-primary" />} />

          <MapList title="Community reports" icon={Users} tone="text-sky-600" records={reportRecords} onPick={(r) => select('reports', r)} render={(r) => (
            <>
              <p className="font-medium text-sm truncate">{r.title}</p>
              <p className="text-xs text-muted-foreground">{r.reference_number} · {r.status}</p>
            </>
          )} badge={() => <span className="w-2.5 h-2.5 rounded-full bg-sky-500" />} />
        </div>
      </div>

      <MapStatus records={[farmRecords, fieldRecords, alertRecords, reportRecords]} />
    </div>
  );
}

function LayerToggle({ active, onClick, color, icon: Icon, label }) {
  return (
    <button
      onClick={onClick}
      aria-pressed={active}
      className={cn(
        'inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium transition-colors',
        active ? 'border-border bg-card text-foreground shadow-sm' : 'border-border bg-muted/40 text-muted-foreground'
      )}
    >
      <span className={cn('w-2 h-2 rounded-full', active ? color : 'bg-muted-foreground/40')} />
      {label}
    </button>
  );
}