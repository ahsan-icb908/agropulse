import { Dna, Atom, RefreshCw, Sprout, TrendingUp, Link2 } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import OrganizationLadder from '@/components/biology/OrganizationLadder';
import ProcessGrid from '@/components/biology/ProcessGrid';
import CycleGrid from '@/components/biology/CycleGrid';
import SoilAndWeb from '@/components/biology/SoilAndWeb';
import GrowthBiology from '@/components/biology/GrowthBiology';
import AppMapping from '@/components/biology/AppMapping';

const TABS = [
  { value: 'organisation', label: 'Organisation', icon: Sprout },
  { value: 'processes', label: 'Processes', icon: Atom },
  { value: 'cycles', label: 'Cycles', icon: RefreshCw },
  { value: 'soil', label: 'Soil & Food Web', icon: Sprout },
  { value: 'growth', label: 'Growth', icon: TrendingUp },
  { value: 'mapping', label: 'App Mapping', icon: Link2 },
];

export default function BiologyLab() {
  return (
    <div className="space-y-5">
      {/* Exhibition hero */}
      <div className="rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 via-primary/5 to-accent/10 p-6 sm:p-8">
        <Badge variant="secondary" className="gap-1.5 bg-primary/15 text-primary">
          <Dna className="w-3 h-3" /> Science exhibition module
        </Badge>
        <h1 className="font-heading text-2xl sm:text-4xl font-bold tracking-tight mt-3">
          The Living Farm
        </h1>
        <p className="text-sm sm:text-base text-muted-foreground mt-2 max-w-3xl leading-relaxed">
          AgroPulse OS is a biology project before it is a software project. A farm is not a field of
          plants — it is an agroecosystem where organisms, soil, water and climate exchange energy and
          matter under human management. This module explains that system from molecule to biosphere,
          and shows exactly which part of it each app module records.
        </p>
        <div className="flex flex-wrap gap-2 mt-4">
          <Badge variant="outline" className="text-[11px]">Energy flow</Badge>
          <Badge variant="outline" className="text-[11px]">Nutrient cycling</Badge>
          <Badge variant="outline" className="text-[11px]">Plant physiology</Badge>
          <Badge variant="outline" className="text-[11px]">Soil ecology</Badge>
          <Badge variant="outline" className="text-[11px]">Population dynamics</Badge>
          <Badge variant="outline" className="text-[11px]">Ecosystem services</Badge>
        </div>
      </div>

      <Tabs defaultValue="organisation" className="space-y-4">
        <div className="overflow-x-auto -mx-1 px-1 pb-1">
          <TabsList className="h-auto flex-wrap justify-start gap-1 bg-muted/70 p-1.5">
            {TABS.map((t) => (
              <TabsTrigger key={t.value} value={t.value} className="gap-1.5 px-3 py-2 text-xs sm:text-sm">
                <t.icon className="w-3.5 h-3.5" />
                {t.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        <TabsContent value="organisation"><OrganizationLadder /></TabsContent>
        <TabsContent value="processes"><ProcessGrid /></TabsContent>
        <TabsContent value="cycles"><CycleGrid /></TabsContent>
        <TabsContent value="soil"><SoilAndWeb /></TabsContent>
        <TabsContent value="growth"><GrowthBiology /></TabsContent>
        <TabsContent value="mapping"><AppMapping /></TabsContent>
      </Tabs>

      <p className="text-center text-[11px] text-muted-foreground/70 pt-1">
        Biological explanations are textbook principles. Figures recorded in the app come from your own
        farm records — measured and estimated values are always labelled separately.
      </p>
    </div>
  );
}