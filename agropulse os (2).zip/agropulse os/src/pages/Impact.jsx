import { useEffect, useState } from 'react';
import { Droplets, Leaf, HandCoins, Trash2, Info } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Badge } from '@/components/ui/badge';
import { useImpactSummary } from '@/hooks/useImpactSummary';
import { IMPACT_FORMULAS, IMPACT_CONSTANTS, formatLiters, formatKg, formatPkr } from '@/lib/impact/metrics';
import SavingForm from '@/components/impact/SavingForm';

const METRICS = [
  { key: 'water_liters', label: 'Water saved', unit: 'L', icon: Droplets, format: formatLiters },
  { key: 'fertilizer_kg', label: 'Fertilizer reduced', unit: 'kg', icon: Leaf, format: formatKg },
  { key: 'middleman_pkr', label: 'Middleman cost saved', unit: 'PKR', icon: HandCoins, format: formatPkr },
];

export default function Impact() {
  const { data, loading, reload } = useImpactSummary();
  const [savings, setSavings] = useState([]);

  async function loadSavings() {
    const res = await base44.entities.ImpactSaving.filter({}, { sort: '-created_date', limit: 50 });
    setSavings(res.items || []);
  }

  useEffect(() => { loadSavings(); }, []);

  async function remove(id) {
    await base44.entities.ImpactSaving.delete(id);
    loadSavings();
    reload();
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">SDG Impact</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Water, fertilizer and middleman costs saved — from your records, your own entries, and the whole platform.
        </p>
      </div>

      {loading ? (
        <Widget className="p-8 text-center text-sm text-muted-foreground">Calculating totals…</Widget>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {[
            { title: 'My farms', subtitle: 'Your records plus your own entries', bucket: data?.mine },
            { title: 'Whole platform', subtitle: 'All farms combined (totals only)', bucket: data?.platform },
          ].map((card) => (
            <Widget key={card.title}>
              <WidgetHeader title={card.title} subtitle={card.subtitle} />
              <WidgetBody className="space-y-3">
                {METRICS.map(({ key, label, unit, icon: Icon, format }) => (
                  <div key={key} className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2 text-sm">
                      <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
                        <Icon className="h-4 w-4" />
                      </span>
                      {label}
                    </div>
                    <div className="text-end">
                      <p className="font-heading text-lg font-semibold tabular-nums">
                        {format(card.bucket?.[key] || 0)} <span className="text-xs font-medium text-muted-foreground">{unit}</span>
                      </p>
                      <p className="text-[11px] text-muted-foreground">
                        records {format(card.bucket?.from_records?.[key] || 0)} · manual {format(card.bucket?.from_manual?.[key] || 0)}
                      </p>
                    </div>
                  </div>
                ))}
              </WidgetBody>
            </Widget>
          ))}
        </div>
      )}

      <Widget>
        <WidgetHeader
          title="How these numbers are calculated"
          subtitle="Record-based estimates plus what you enter yourself — never double counted"
          icon={Info}
        />
        <WidgetBody className="space-y-3">
          {IMPACT_FORMULAS.map((row) => (
            <div key={row.metric} className="rounded-lg border border-border/70 p-3">
              <p className="text-sm font-semibold">{row.metric}</p>
              <p className="mt-1 text-xs text-muted-foreground">{row.formula}</p>
              <p className="mt-1 text-[11px] text-muted-foreground">Source: {row.source}</p>
            </div>
          ))}
          <p className="text-[11px] text-muted-foreground">
            Assumptions: {IMPACT_CONSTANTS.waterLitersPerHectare.toLocaleString()} L water avoided per active hectare per
            season · 1 kg compost replaces {IMPACT_CONSTANTS.compostFertilizerFactor} kg chemical fertiliser ·{' '}
            {Math.round(IMPACT_CONSTANTS.commissionRate * 100)}% commission and arhat spread avoided on a direct sale.
            Record-based figures are estimates, not measured savings.
          </p>
        </WidgetBody>
      </Widget>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Widget>
          <WidgetHeader title="Record a saving" subtitle="Add what the records cannot see" />
          <WidgetBody>
            <SavingForm onSaved={() => { loadSavings(); reload(); }} />
          </WidgetBody>
        </Widget>

        <Widget>
          <WidgetHeader title="Your entries" subtitle={`${savings.length} recorded`} />
          <WidgetBody className="space-y-2">
            {savings.length === 0 ? (
              <p className="text-sm text-muted-foreground">No manual savings yet.</p>
            ) : (
              savings.map((entry) => (
                <div key={entry.id} className="flex items-start justify-between gap-3 rounded-lg border border-border/70 p-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{entry.note}</p>
                    <div className="mt-1 flex flex-wrap gap-1.5">
                      {entry.water_liters > 0 && <Badge variant="secondary" className="text-[11px]">{formatLiters(entry.water_liters)} L</Badge>}
                      {entry.fertilizer_kg > 0 && <Badge variant="secondary" className="text-[11px]">{formatKg(entry.fertilizer_kg)} kg</Badge>}
                      {entry.middleman_pkr > 0 && <Badge variant="secondary" className="text-[11px]">PKR {formatPkr(entry.middleman_pkr)}</Badge>}
                      <span className="text-[11px] text-muted-foreground">{entry.recorded_on}</span>
                    </div>
                  </div>
                  <button
                    onClick={() => remove(entry.id)}
                    aria-label="Delete entry"
                    className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))
            )}
          </WidgetBody>
        </Widget>
      </div>
    </div>
  );
}