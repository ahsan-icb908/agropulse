import { useState } from 'react';
import { Bell, Check, Loader2, BellOff } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { useCollection } from '@/hooks/useCollection';
import { cn } from '@/lib/utils';

const TYPE_TONE = {
  alert: 'text-orange-600 bg-orange-500/10',
  weather: 'text-sky-600 bg-sky-500/10',
  task: 'text-primary bg-primary/10',
  report: 'text-violet-600 bg-violet-500/10',
  system: 'text-muted-foreground bg-muted',
};

export default function Notifications() {
  const { t } = useI18n();
  const { data, loading, reload } = useCollection('Notification', { sort: '-created_date', limit: 100 });
  const [busy, setBusy] = useState(null);

  async function markRead(id) {
    setBusy(id);
    try {
      await base44.entities.Notification.update(id, { read: true });
      reload();
    } finally {
      setBusy(null);
    }
  }

  return (
    <div className="space-y-5 max-w-2xl">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">{t('nav.notifications')}</h1>
        <p className="text-sm text-muted-foreground mt-1">Unified notifications across farms, alerts, reports and system events.</p>
      </div>

      {loading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : data.length === 0 ? (
        <Widget className="p-10 text-center text-muted-foreground">
          <BellOff className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p className="text-sm">No notifications yet.</p>
        </Widget>
      ) : (
        <div className="space-y-2">
          {data.map((n) => (
            <Widget key={n.id} className={cn('p-3.5 flex items-start gap-3', !n.read && 'border-primary/30')}>
              <span className={cn('w-9 h-9 rounded-xl flex items-center justify-center shrink-0', TYPE_TONE[n.type] || TYPE_TONE.system)}>
                <Bell className="w-4 h-4" />
              </span>
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <p className="font-medium text-sm truncate">{n.title}</p>
                  {!n.read && <span className="w-2 h-2 rounded-full bg-primary shrink-0" />}
                </div>
                <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{n.body}</p>
              </div>
              {!n.read && (
                <Button variant="ghost" size="sm" className="gap-1 shrink-0" onClick={() => markRead(n.id)} disabled={busy === n.id}>
                  {busy === n.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />} Read
                </Button>
              )}
            </Widget>
          ))}
        </div>
      )}
    </div>
  );
}