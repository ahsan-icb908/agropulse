import { useState } from 'react';
import { Wheat } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import HarvestUploader from '@/components/harvest/HarvestUploader';
import RecentHarvests from '@/components/harvest/RecentHarvests';

export default function HarvestRecords() {
  const { lang } = useI18n();
  const [importKey, setImportKey] = useState(0);

  return (
    <div className="space-y-5">
      <div className="flex items-start gap-3">
        <span className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-primary/10 text-primary">
          <Wheat className="h-5 w-5" />
        </span>
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">
            {lang === 'ur' ? 'فصل ریکارڈ' : 'Harvest records'}
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {lang === 'ur'
              ? 'ایک ہی فائل سے سینکڑوں پرانے فصل ریکارڈ شامل کریں۔'
              : 'Add large amounts of historical harvest data at once from a spreadsheet.'}
          </p>
        </div>
      </div>

      <HarvestUploader lang={lang} onImported={() => setImportKey((k) => k + 1)} />
      <RecentHarvests reloadKey={importKey} lang={lang} />
    </div>
  );
}