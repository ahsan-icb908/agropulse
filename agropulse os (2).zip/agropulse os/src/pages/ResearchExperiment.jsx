import { useCallback, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Loader2 } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import EvidenceBadge from '@/components/research/EvidenceBadge';
import OverviewPanel from '@/components/research/OverviewPanel';
import TreatmentsPanel from '@/components/research/TreatmentsPanel';
import PlantsPanel from '@/components/research/PlantsPanel';
import ObservationsPanel from '@/components/research/ObservationsPanel';
import AnalysisPanel from '@/components/research/AnalysisPanel';
import CalculationsPanel from '@/components/research/CalculationsPanel';
import BiologyPanel from '@/components/research/BiologyPanel';
import ResearchReport from '@/components/research/ResearchReport';
import ExhibitionMode from '@/components/research/ExhibitionMode';
import ResearchAssistant from '@/components/research/ResearchAssistant';
import { loadExperimentBundle } from '@/lib/biology/researchStore';

const TABS = [
  'overview',
  'design',
  'plants',
  'observations',
  'analysis',
  'calculations',
  'biology',
  'report',
  'exhibition',
  'assistant',
];

export default function ResearchExperiment() {
  const { t } = useI18n();
  const { experimentId } = useParams();
  const [bundle, setBundle] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await loadExperimentBundle(experimentId);
      setBundle(data);
      setError('');
    } catch (e) {
      setBundle(null);
      setError(e?.message || 'not_found');
    } finally {
      setLoading(false);
    }
  }, [experimentId]);

  useEffect(() => {
    load();
  }, [load]);

  // A detail page that has finished loading without an item is a real 404.
  useEffect(() => {
    if (loading || bundle) return undefined;
    const meta = document.createElement('meta');
    meta.name = 'prerender-status-code';
    meta.content = '404';
    document.head.appendChild(meta);
    return () => {
      document.head.removeChild(meta);
    };
  }, [loading, bundle]);

  if (loading) {
    return (
      <div className="flex justify-center py-20">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!bundle) {
    return (
      <div className="space-y-3 py-10 text-center">
        <p className="text-sm text-muted-foreground">{t('research.notFound')}</p>
        {error && error !== 'not_found' && <p className="text-xs text-muted-foreground">{error}</p>}
        <Link to="/research" className="text-sm text-primary hover:underline">
          {t('research.title')}
        </Link>
      </div>
    );
  }

  const ctx = { ...bundle, reload: load };
  const isDemo = Boolean(bundle.experiment.is_demo);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <Link to="/research" className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground">
            <ArrowLeft className="h-3 w-3 flip-x" />
            {t('research.title')}
          </Link>
          <h1 className="mt-1 font-heading text-xl font-bold leading-snug tracking-tight">
            {bundle.experiment.title}
          </h1>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <Badge variant="outline" className="text-[10px]">
              {t(`research.status.${bundle.experiment.status || 'planning'}`)}
            </Badge>
            <EvidenceBadge type={isDemo ? 'demonstration' : 'real'} />
            <span className="text-[11px] text-muted-foreground">
              {bundle.treatments.length} {t('research.field.treatment')} • {bundle.plants.length}{' '}
              {t('research.field.plant')} • {bundle.observations.length} {t('research.observationsCount')}
            </span>
          </div>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <div className="overflow-x-auto pb-1 print:hidden">
          <TabsList className="h-auto flex-wrap justify-start gap-1 bg-muted/70 p-1.5">
            {TABS.map((tab) => (
              <TabsTrigger key={tab} value={tab} className="px-3 py-2 text-xs sm:text-sm">
                {t(`research.tab.${tab}`)}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        <TabsContent value="overview">
          <OverviewPanel ctx={ctx} />
        </TabsContent>
        <TabsContent value="design">
          <TreatmentsPanel ctx={ctx} />
        </TabsContent>
        <TabsContent value="plants">
          <PlantsPanel ctx={ctx} />
        </TabsContent>
        <TabsContent value="observations">
          <ObservationsPanel ctx={ctx} />
        </TabsContent>
        <TabsContent value="analysis">
          <AnalysisPanel ctx={ctx} />
        </TabsContent>
        <TabsContent value="calculations">
          <CalculationsPanel ctx={ctx} />
        </TabsContent>
        <TabsContent value="biology">
          <BiologyPanel ctx={ctx} />
        </TabsContent>
        <TabsContent value="report">
          <ResearchReport ctx={ctx} />
        </TabsContent>
        <TabsContent value="exhibition">
          <ExhibitionMode ctx={ctx} />
        </TabsContent>
        <TabsContent value="assistant">
          <ResearchAssistant ctx={ctx} />
        </TabsContent>
      </Tabs>
    </div>
  );
}