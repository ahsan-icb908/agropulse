import { useState } from 'react';
import { Sprout, Plus, MapPin, Trash2, Loader2, Layers, CalendarRange, ChevronRight } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCollection } from '@/hooks/useCollection';
import GrowthStageBadge, { GROWTH_STAGES, stageInfo, stageProgress } from '@/components/fields/GrowthStageBadge';
import FieldDetailDialog from '@/components/fields/FieldDetailDialog';
import GrowthTimeline from '@/components/fields/GrowthTimeline';

export default function Fields() {
  const { t } = useI18n();
  const { data: fields, loading, reload } = useCollection('Field', { sort: '-created_date', limit: 200 });
  const { data: farms } = useCollection('Farm', { sort: '-created_date', limit: 100 });
  const { data: seasons, reload: reloadSeasons } = useCollection('CropSeason', { sort: '-created_date', limit: 300 });
  const [open, setOpen] = useState(false);
  const [detailId, setDetailId] = useState(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ farm_id: '', name: '', crop: '', area_hectares: '', lat: '', lng: '', growth_stage: 'land_prep' });
  const [err, setErr] = useState('');
  const [view, setView] = useState('cards');

  const detailField = detailId ? fields.find((f) => f.id === detailId) : null;
  const seasonsFor = (fieldId) => seasons.filter((s) => s.field_id === fieldId);
  const activeSeasonFor = (fieldId) => seasons.find((s) => s.field_id === fieldId && s.status === 'active');

  async function save() {
    if (!form.farm_id) return setErr('Select a farm.');
    if (!form.name) return setErr('Field name is required.');
    setSaving(true);
    setErr('');
    try {
      const farm = farms.find((f) => f.id === form.farm_id);
      await base44.entities.Field.create({
        farm_id: form.farm_id,
        farm_name: farm?.name || '',
        name: form.name,
        crop: form.crop || undefined,
        area_hectares: form.area_hectares ? Number(form.area_hectares) : undefined,
        lat: form.lat ? Number(form.lat) : undefined,
        lng: form.lng ? Number(form.lng) : undefined,
        growth_stage: form.growth_stage,
        status: 'active',
      });
      setForm({ farm_id: '', name: '', crop: '', area_hectares: '', lat: '', lng: '', growth_stage: 'land_prep' });
      setOpen(false);
      reload();
    } catch (e) {
      setErr(e?.message || 'Could not save field.');
    } finally {
      setSaving(false);
    }
  }

  async function remove(id) {
    if (!confirm('Delete this field?')) return;
    await base44.entities.Field.delete(id);
    reload();
  }

  // A manual stage change updates the field and, when a season is running,
  // is appended to that season's dated history.
  async function recordStage(field, stage, note = '') {
    await base44.entities.Field.update(field.id, { growth_stage: stage });
    const season = activeSeasonFor(field.id);
    if (season) {
      await base44.entities.CropSeason.update(season.id, {
        current_stage: stage,
        stage_history: [...(season.stage_history || []), { stage, at: new Date().toISOString(), note }],
      });
      reloadSeasons();
    }
    reload();
  }

  async function createSeason(field, data) {
    const startStage = field.growth_stage || 'land_prep';
    await base44.entities.CropSeason.create({
      field_id: field.id,
      field_name: field.name,
      crop: data.crop || field.crop || undefined,
      season_label: data.season_label,
      sowing_date: data.sowing_date || undefined,
      current_stage: startStage,
      status: 'active',
      stage_history: [{ stage: startStage, at: new Date().toISOString(), note: 'Season started' }],
    });
    reloadSeasons();
  }

  async function seasonRecord(season, stage, note) {
    await base44.entities.CropSeason.update(season.id, {
      current_stage: stage,
      stage_history: [...(season.stage_history || []), { stage, at: new Date().toISOString(), note }],
    });
    if (season.status === 'active') {
      await base44.entities.Field.update(season.field_id, { growth_stage: stage });
      reload();
    }
    reloadSeasons();
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">Fields</h1>
          <p className="text-sm text-muted-foreground mt-1">Track every field's crop and growth stage through the season.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus className="w-4 h-4" /> Add field</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add a field</DialogTitle>
            </DialogHeader>
            <div className="grid gap-3 py-2">
              <div>
                <Label>Farm *</Label>
                <Select value={form.farm_id} onValueChange={(v) => setForm({ ...form, farm_id: v })}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select farm" /></SelectTrigger>
                  <SelectContent>
                    {farms.map((f) => <SelectItem key={f.id} value={f.id}>{f.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div><Label>Name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1" placeholder="North plot" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Crop</Label><Input value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} className="mt-1" placeholder="Wheat" /></div>
                <div><Label>Area (ha)</Label><Input value={form.area_hectares} onChange={(e) => setForm({ ...form, area_hectares: e.target.value })} className="mt-1" placeholder="5.0" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Latitude</Label><Input value={form.lat} onChange={(e) => setForm({ ...form, lat: e.target.value })} className="mt-1" placeholder="31.4504" /></div>
                <div><Label>Longitude</Label><Input value={form.lng} onChange={(e) => setForm({ ...form, lng: e.target.value })} className="mt-1" placeholder="73.135" /></div>
              </div>
              <div>
                <Label>Growth stage</Label>
                <Select value={form.growth_stage} onValueChange={(v) => setForm({ ...form, growth_stage: v })}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {GROWTH_STAGES.map((s) => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              {err && <p className="text-sm text-destructive">{err}</p>}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save} disabled={saving} className="gap-2">{saving && <Loader2 className="w-4 h-4 animate-spin" />} Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {!loading && fields.length > 0 && (
        <div className="flex w-fit gap-1 rounded-lg border border-border p-1">
          {[
            { key: 'cards', label: 'Cards' },
            { key: 'timeline', label: 'Timeline' },
          ].map((opt) => (
            <button
              key={opt.key}
              onClick={() => setView(opt.key)}
              className={`rounded-md px-3 py-1 text-xs font-medium transition-colors ${
                view === opt.key ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:bg-muted'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>
      )}

      {loading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : fields.length === 0 ? (
        <Widget className="p-10 text-center text-muted-foreground">
          <Layers className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p className="text-sm">No fields yet. Add your first field to start tracking growth stages.</p>
        </Widget>
      ) : view === 'timeline' ? (
        <GrowthTimeline fields={fields} seasons={seasons} />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {fields.map((field) => (
            <FieldCard
              key={field.id}
              field={field}
              activeSeason={activeSeasonFor(field.id)}
              seasonCount={seasonsFor(field.id).length}
              onStageChange={(s) => recordStage(field, s)}
              onOpen={() => setDetailId(field.id)}
              onDelete={() => remove(field.id)}
            />
          ))}
        </div>
      )}

      <FieldDetailDialog
        field={detailField}
        seasons={detailField ? seasonsFor(detailField.id) : []}
        onCreateSeason={(data) => createSeason(detailField, data)}
        onRecordStage={seasonRecord}
        onClose={() => setDetailId(null)}
      />
    </div>
  );
}

function FieldCard({ field, activeSeason, seasonCount, onStageChange, onOpen, onDelete }) {
  const [updating, setUpdating] = useState(false);
  const info = stageInfo(field.growth_stage);
  const progress = stageProgress(field.growth_stage);
  const currentStep = info.step;
  const canAdvance = currentStep < GROWTH_STAGES.length - 1;

  async function advance() {
    if (!canAdvance) return;
    setUpdating(true);
    try {
      await onStageChange(GROWTH_STAGES[currentStep + 1].key);
    } finally {
      setUpdating(false);
    }
  }

  return (
    <Widget className="p-4 group">
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0"><Sprout className="w-5 h-5" /></span>
          <div className="min-w-0">
            <p className="font-heading font-semibold truncate">{field.name}</p>
            <p className="text-xs text-muted-foreground truncate">{field.farm_name || '—'}{field.crop ? ` · ${field.crop}` : ''}</p>
          </div>
        </div>
        <button onClick={onDelete} className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive shrink-0"><Trash2 className="w-4 h-4" /></button>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <GrowthStageBadge stage={field.growth_stage} />
        {activeSeason && (
          <Badge variant="secondary" className="text-xs gap-1">
            <CalendarRange className="w-3 h-3" /> {activeSeason.season_label}
          </Badge>
        )}
        {field.area_hectares && <Badge variant="outline" className="text-xs">{field.area_hectares} ha</Badge>}
        {field.lat && field.lng && <Badge variant="outline" className="text-xs gap-1"><MapPin className="w-3 h-3" /> Geo-located</Badge>}
      </div>

      {/* Growth stage progress tracker */}
      <div className="mt-4">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs text-muted-foreground">Growth progress</span>
          <span className="text-xs font-medium">{progress}%</span>
        </div>
        <div className="h-2 rounded-full bg-muted overflow-hidden">
          <div className="h-full rounded-full transition-all duration-300" style={{ width: `${progress}%`, background: info.color }} />
        </div>
        {/* Stage stepper */}
        <div className="flex items-center gap-0.5 mt-2 overflow-x-auto scrollbar-thin pb-1">
          {GROWTH_STAGES.map((s, i) => (
            <div key={s.key} className="flex items-center shrink-0">
              <span
                className={`w-1.5 h-1.5 rounded-full ${i <= currentStep ? '' : 'bg-muted-foreground/30'}`}
                style={i <= currentStep ? { background: s.color } : {}}
                title={s.label}
              />
              {i < GROWTH_STAGES.length - 1 && <span className={`w-3 h-px ${i < currentStep ? 'bg-foreground/30' : 'bg-muted-foreground/20'}`} />}
            </div>
          ))}
        </div>
      </div>

      {/* Stage controls */}
      <div className="mt-3 flex items-center gap-2">
        <Select value={field.growth_stage} onValueChange={onStageChange} disabled={updating}>
          <SelectTrigger className="h-8 text-xs flex-1"><SelectValue /></SelectTrigger>
          <SelectContent>
            {GROWTH_STAGES.map((s) => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}
          </SelectContent>
        </Select>
        {canAdvance && (
          <Button variant="outline" size="sm" onClick={advance} disabled={updating} className="gap-1 shrink-0">
            {updating ? <Loader2 className="w-3 h-3 animate-spin" /> : <ChevronRight className="w-3 h-3" />}
            Advance
          </Button>
        )}
      </div>

      <Button variant="ghost" size="sm" onClick={onOpen} className="mt-2 w-full gap-1.5 text-xs justify-center border border-dashed border-border h-8">
        <CalendarRange className="w-3.5 h-3.5" />
        Season tracker{seasonCount > 0 ? ` · ${seasonCount} season${seasonCount > 1 ? 's' : ''}` : ''}
      </Button>
    </Widget>
  );
}