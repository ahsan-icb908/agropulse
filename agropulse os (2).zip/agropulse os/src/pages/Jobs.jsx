import { useState } from 'react';
import { Briefcase, Plus, Trash2, Loader2, MapPin, Phone, BadgeCheck, Calendar } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCollection } from '@/hooks/useCollection';

const CATEGORIES = [
  { key: 'harvest', label: 'Harvest' }, { key: 'sowing', label: 'Sowing' }, { key: 'irrigation', label: 'Irrigation' },
  { key: 'general', label: 'General' }, { key: 'equipment', label: 'Equipment' },
];

export default function Jobs() {
  const { data, loading, reload } = useCollection('Job', { sort: '-created_date', limit: 100 });
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ title: '', farm_name: '', location_text: '', category: 'general', wage: '', wage_unit: 'per_day', start_date: '', duration: '', positions: '1', description: '', contact: '', fair_wage_certified: true });

  async function save() {
    setSaving(true);
    try {
      await base44.entities.Job.create({ ...form, wage: Number(form.wage) || 0, positions: parseInt(form.positions) || 1 });
      setForm({ title: '', farm_name: '', location_text: '', category: 'general', wage: '', wage_unit: 'per_day', start_date: '', duration: '', positions: '1', description: '', contact: '', fair_wage_certified: true });
      setOpen(false); reload();
    } finally { setSaving(false); }
  }
  async function remove(id) { await base44.entities.Job.delete(id); reload(); }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">Job Board</h1>
          <p className="text-sm text-muted-foreground mt-1">Seasonal farm jobs with fair-wage standards and safety guidelines.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="gap-2"><Plus className="w-4 h-4" /> Post job</Button></DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>Post a job</DialogTitle></DialogHeader>
            <div className="grid gap-3 py-2 max-h-[60vh] overflow-y-auto">
              <div><Label>Title *</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="mt-1" placeholder="Wheat harvest workers" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Farm</Label><Input value={form.farm_name} onChange={(e) => setForm({ ...form, farm_name: e.target.value })} className="mt-1" /></div>
                <div><Label>Category</Label><Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{CATEGORIES.map((c) => <SelectItem key={c.key} value={c.key}>{c.label}</SelectItem>)}</SelectContent></Select></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Wage (PKR) *</Label><Input type="number" value={form.wage} onChange={(e) => setForm({ ...form, wage: e.target.value })} className="mt-1" placeholder="1500" /></div>
                <div><Label>Wage unit</Label><Select value={form.wage_unit} onValueChange={(v) => setForm({ ...form, wage_unit: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['per_day', 'per_week', 'per_month', 'per_season'].map((u) => <SelectItem key={u} value={u}>{u.replace('_', '/')}</SelectItem>)}</SelectContent></Select></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Start date</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} className="mt-1" /></div>
                <div><Label>Positions</Label><Input type="number" value={form.positions} onChange={(e) => setForm({ ...form, positions: e.target.value })} className="mt-1" /></div>
              </div>
              <div><Label>Duration</Label><Input value={form.duration} onChange={(e) => setForm({ ...form, duration: e.target.value })} className="mt-1" placeholder="2 weeks" /></div>
              <div><Label>Location</Label><Input value={form.location_text} onChange={(e) => setForm({ ...form, location_text: e.target.value })} className="mt-1" /></div>
              <div><Label>Contact</Label><Input value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} className="mt-1" /></div>
              <div><Label>Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="mt-1" rows={2} /></div>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.fair_wage_certified} onChange={(e) => setForm({ ...form, fair_wage_certified: e.target.checked })} /> Fair-wage certified</label>
            </div>
            <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} disabled={saving} className="gap-2">{saving && <Loader2 className="w-4 h-4 animate-spin" />} Post</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        : data.length === 0 ? <Widget className="p-10 text-center text-muted-foreground"><Briefcase className="w-10 h-10 mx-auto mb-3 opacity-40" /><p className="text-sm">No jobs posted yet.</p></Widget>
        : <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">{data.map((j) => (
          <Widget key={j.id} className="p-4 group">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0"><Briefcase className="w-5 h-5" /></span>
                <div className="min-w-0">
                  <p className="font-heading font-semibold truncate">{j.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{j.farm_name || '—'} · {j.category}</p>
                </div>
              </div>
              <button onClick={() => remove(j.id)} className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive shrink-0"><Trash2 className="w-4 h-4" /></button>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Badge className="bg-primary text-primary-foreground">PKR {j.wage?.toLocaleString()} {j.wage_unit?.replace('_', '/')}</Badge>
              {j.fair_wage_certified && <Badge variant="secondary" className="gap-1 bg-emerald-500/10 text-emerald-700"><BadgeCheck className="w-3 h-3" /> Fair wage</Badge>}
              {j.positions && <Badge variant="outline">{j.positions} position{j.positions > 1 ? 's' : ''}</Badge>}
            </div>
            <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
              {j.location_text && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {j.location_text}</span>}
              {j.start_date && <span className="flex items-center gap-1"><Calendar className="w-3 h-3" /> {j.start_date}</span>}
              {j.duration && <span>{j.duration}</span>}
            </div>
            {j.contact && <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1"><Phone className="w-3 h-3" /> {j.contact}</p>}
          </Widget>
        ))}</div>}
    </div>
  );
}