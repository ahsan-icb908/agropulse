import { useI18n } from '@/i18n/LanguageContext';
import { useCollection } from '@/hooks/useCollection';
import AgriBotChat from '@/components/assistant/AgriBotChat';

export default function Assistant() {
  const { t } = useI18n();
  const { data: farms } = useCollection('Farm', { limit: 20, fields: ['name', 'crop_focus', 'location_text'] });
  const { data: alerts } = useCollection('Alert', { query: { status: 'active' }, limit: 10, fields: ['title', 'severity'] });

  const context = `${farms.length} farms (${farms.map((f) => f.name).join(', ') || 'none yet'}). Active alerts: ${
    alerts.map((a) => a.title).join('; ') || 'none'
  }.`;

  return (
    <div className="flex h-full flex-col space-y-4">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">{t('nav.assistant')}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Ask about your farms, crops, weather and risks — type or dictate in English, Urdu or Roman Urdu.
        </p>
      </div>
      <div className="min-h-[60vh] flex-1">
        <AgriBotChat context={context} />
      </div>
    </div>
  );
}