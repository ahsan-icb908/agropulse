import { useState } from 'react';
import { Zap, Plus, Trash2, Loader2, MapPin, Phone } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCollection } from '@/hooks/useCollection';

const TYPES = [
  { key: 'solar_pump', label: 'Solar Pump' }, { key: 'cold_storage', label: 'Cold Storage' },
  { key: 'tractor', label: 'Tractor' }, { key: 'thresher', label: 'Thresher' },
  { key: 'sprayer', label: 'Sprayer' }, { key: 'tiller', label: 'Tiller' }, { key: 'other', label: 'Other' },
];

export default function EquipmentRental() {
  const { data, loading, reload } = useCollection('Equipment', { sort: '-created_date', limit: 100 });
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', type: 'solar_pump', daily_rate: '', location_text: '', owner_contact: '', description: '', available: true });

  async function save() {
    setSaving(true);
    try {
      await base44.entities.Equipment.create({ ...form, daily_rate: Number(form.daily_rate) || 0 });
      setForm({ name: '', type: 'solar_pump', daily_rate: '', location_text: '', owner_contact: '', description: '', available: true });
      setOpen(false); reload();
    } finally { setSaving(false); }
  }
  async function remove(id) { await base44.entities.Equipment.delete(id); reload(); }
  async function toggle(id, val) { await base44.entities.Equipment.update(id, { available: !val }); reload(); }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">Equipment Rental</h1>
          <p className="text-sm text-muted-foreground mt-1">Peer-to-peer sharing of solar pumps, cold storage, and clean-tech tools.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="gap-2"><Plus className="w-4 h-4" /> List equipment</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>List equipment for rent</DialogTitle></DialogHeader>
            <div className="grid gap-3 py-2">
              <div><Label>Name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1" placeholder="5HP Solar Pump" /></div>
              <div><Label>Type</Label><Select value={form.type} onValueChange={(v) => setForm({ ...form, type: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{TYPES.map((t) => <SelectItem key={t.key} value={t.key}>{t.label}</SelectItem>)}</SelectContent></Select></div>
              <div><Label>Daily rate (PKR) *</Label><Input type="number" value={form.daily_rate} onChange={(e) => setForm({ ...form, daily_rate: e.target.value })} className="mt-1" placeholder="500" /></div>
              <div><Label>Location</Label><Input value={form.location_text} onChange={(e) => setForm({ ...form, location_text: e.target.value })} className="mt-1" /></div>
              <div><Label>Contact</Label><Input value={form.owner_contact} onChange={(e) => setForm({ ...form, owner_contact: e.target.value })} className="mt-1" /></div>
              <div><Label>Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="mt-1" rows={2} /></div>
            </div>
            <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} disabled={saving} className="gap-2">{saving && <Loader2 className="w-4 h-4 animate-spin" />} List</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        : data.length === 0 ? <Widget className="p-10 text-center text-muted-foreground"><Zap className="w-10 h-10 mx-auto mb-3 opacity-40" /><p className="text-sm">No equipment listed yet. Share your solar pump or cold storage with nearby farmers.</p></Widget>
        : <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">{data.map((e) => (
          <Widget key={e.id} className="p-4 group">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center shrink-0"><Zap className="w-5 h-5" /></span>
                <div className="min-w-0">
                  <p className="font-heading font-semibold truncate">{e.name}</p>
                  <p className="text-xs text-muted-foreground">{TYPES.find((t) => t.key === e.type)?.label || e.type}</p>
                </div>
              </div>
              <button onClick={() => remove(e.id)} className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive shrink-0"><Trash2 className="w-4 h-4" /></button>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Badge className="bg-primary text-primary-foreground">PKR {e.daily_rate?.toLocaleString()}/day</Badge>
              <button onClick={() => toggle(e.id, e.available)}><Badge variant={e.available ? 'secondary' : 'outline'} className={e.available ? 'bg-emerald-500/10 text-emerald-700' : ''}>{e.available ? 'Available' : 'Rented'}</Badge></button>
            </div>
            {e.description && <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{e.description}</p>}
            <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
              {e.location_text && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {e.location_text}</span>}
              {e.owner_contact && <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {e.owner_contact}</span>}
            </div>
          </Widget>
        ))}</div>}
    </div>
  );
}