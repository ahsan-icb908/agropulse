import { useState } from 'react';
import { Recycle, Plus, Trash2, Loader2, FlaskConical, Calendar } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCollection } from '@/hooks/useCollection';

const SOURCES = [
  { key: 'crop_residue', label: 'Crop Residue' }, { key: 'manure', label: 'Manure' },
  { key: 'kitchen_waste', label: 'Kitchen Waste' }, { key: 'green_waste', label: 'Green Waste' },
  { key: 'mixed', label: 'Mixed' },
];
const STATUS_STYLES = {
  preparing: 'bg-muted text-muted-foreground', composting: 'bg-amber-500/10 text-amber-600',
  ready: 'bg-emerald-500/10 text-emerald-700', used: 'bg-sky-500/10 text-sky-700',
};
const STAGES = ['preparing', 'composting', 'ready', 'used'];

export default function Composting() {
  const { data, loading, reload } = useCollection('CompostBatch', { sort: '-created_date', limit: 100 });
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ batch_name: '', source_material: 'mixed', volume_kg: '', start_date: '', expected_ready_date: '', nitrogen_content: '', carbon_ratio: '', notes: '' });

  async function save() {
    setSaving(true);
    try {
      await base44.entities.CompostBatch.create({
        ...form, volume_kg: Number(form.volume_kg) || 0, nitrogen_content: Number(form.nitrogen_content) || 0,
        carbon_ratio: Number(form.carbon_ratio) || 0, status: 'preparing',
      });
      setForm({ batch_name: '', source_material: 'mixed', volume_kg: '', start_date: '', expected_ready_date: '', nitrogen_content: '', carbon_ratio: '', notes: '' });
      setOpen(false); reload();
    } finally { setSaving(false); }
  }
  async function remove(id) { await base44.entities.CompostBatch.delete(id); reload(); }
  async function setStage(id, status) { await base44.entities.CompostBatch.update(id, { status }); reload(); }

  const totalVolume = data.reduce((s, b) => s + (b.volume_kg || 0), 0);
  const readyCount = data.filter((b) => b.status === 'ready').length;

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">Composting</h1>
          <p className="text-sm text-muted-foreground mt-1">Turn crop residue and waste into bio-fertilizer. Track every batch.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="gap-2"><Plus className="w-4 h-4" /> New batch</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Start compost batch</DialogTitle></DialogHeader>
            <div className="grid gap-3 py-2">
              <div><Label>Batch name *</Label><Input value={form.batch_name} onChange={(e) => setForm({ ...form, batch_name: e.target.value })} className="mt-1" placeholder="Batch #1 — October" /></div>
              <div><Label>Source material</Label><Select value={form.source_material} onValueChange={(v) => setForm({ ...form, source_material: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{SOURCES.map((s) => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}</SelectContent></Select></div>
              <div><Label>Volume (kg)</Label><Input type="number" value={form.volume_kg} onChange={(e) => setForm({ ...form, volume_kg: e.target.value })} className="mt-1" placeholder="50" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Start date</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} className="mt-1" /></div>
                <div><Label>Expected ready</Label><Input type="date" value={form.expected_ready_date} onChange={(e) => setForm({ ...form, expected_ready_date: e.target.value })} className="mt-1" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Nitrogen (%)</Label><Input type="number" value={form.nitrogen_content} onChange={(e) => setForm({ ...form, nitrogen_content: e.target.value })} className="mt-1" placeholder="1.5" /></div>
                <div><Label>C:N ratio</Label><Input type="number" value={form.carbon_ratio} onChange={(e) => setForm({ ...form, carbon_ratio: e.target.value })} className="mt-1" placeholder="30" /></div>
              </div>
              <div><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="mt-1" rows={2} /></div>
            </div>
            <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} disabled={saving} className="gap-2">{saving && <Loader2 className="w-4 h-4 animate-spin" />} Start</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {data.length > 0 && (
        <div className="grid grid-cols-3 gap-4">
          <Widget className="p-4"><p className="text-xs text-muted-foreground">Total material</p><p className="font-heading text-xl font-bold mt-1">{totalVolume.toLocaleString()} kg</p></Widget>
          <Widget className="p-4"><p className="text-xs text-muted-foreground">Active batches</p><p className="font-heading text-xl font-bold mt-1">{data.filter((b) => ['preparing', 'composting'].includes(b.status)).length}</p></Widget>
          <Widget className="p-4"><p className="text-xs text-muted-foreground">Ready to use</p><p className="font-heading text-xl font-bold mt-1">{readyCount}</p></Widget>
        </div>
      )}

      {loading ? <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        : data.length === 0 ? <Widget className="p-10 text-center text-muted-foreground"><Recycle className="w-10 h-10 mx-auto mb-3 opacity-40" /><p className="text-sm">No batches yet. Start your first compost batch to turn waste into bio-fertilizer.</p></Widget>
        : <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">{data.map((b) => (
          <Widget key={b.id} className="p-4 group">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-600 flex items-center justify-center shrink-0"><Recycle className="w-5 h-5" /></span>
                <div className="min-w-0">
                  <p className="font-heading font-semibold truncate">{b.batch_name}</p>
                  <p className="text-xs text-muted-foreground truncate">{SOURCES.find((s) => s.key === b.source_material)?.label || b.source_material} · {b.volume_kg} kg</p>
                </div>
              </div>
              <button onClick={() => remove(b.id)} className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive shrink-0"><Trash2 className="w-4 h-4" /></button>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Select value={b.status} onValueChange={(v) => setStage(b.id, v)}>
                <SelectTrigger className="h-7 w-auto text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{STAGES.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
              {b.nitrogen_content > 0 && <Badge variant="outline" className="gap-1"><FlaskConical className="w-3 h-3" /> N {b.nitrogen_content}%</Badge>}
              {b.carbon_ratio > 0 && <Badge variant="outline">C:N {b.carbon_ratio}</Badge>}
            </div>
            {(b.start_date || b.expected_ready_date) && (
              <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1"><Calendar className="w-3 h-3" /> {b.start_date} → {b.expected_ready_date || '—'}</p>
            )}
            {b.notes && <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{b.notes}</p>}
          </Widget>
        ))}</div>}
    </div>
  );
}