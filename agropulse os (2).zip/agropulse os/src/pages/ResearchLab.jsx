import LabHome from '@/components/research/LabHome';

export default function ResearchLab() {
  return <LabHome />;
}