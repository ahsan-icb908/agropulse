import { useNavigate } from 'react-router-dom';
import {
  AlertTriangle,
  CheckSquare,
  Droplets,
  Leaf,
  CloudSun,
  Sparkles,
  MapPin,
  Plus,
  ScanLine,
  Bell,
  Activity,
  ArrowRight,
  Target,
  Dna,
  FlaskConical,
} from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Stagger, StaggerItem } from '@/components/common/motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import { SDG_CATEGORIES, SDGS, SDG_FEATURED, goalsFor } from '@/components/sdgs/sdgData';

// DEMONSTRATION DATA — clearly labeled. Replaced by live entity data in the next milestone.
const SAMPLE = {
  location: 'Faisalabad, Punjab',
  stats: { alerts: 2, tasks: 7, water: '4,200 L', health: 86 },
  weather: {
    temp: 31,
    condition: 'Partly cloudy',
    humidity: 64,
    wind: 12,
    rainfall: 0,
    forecast: [
      { day: 'Mon', hi: 33, lo: 22, icon: 'sun' },
      { day: 'Tue', hi: 34, lo: 23, icon: 'sun' },
      { day: 'Wed', hi: 30, lo: 21, icon: 'cloud' },
      { day: 'Thu', hi: 28, lo: 20, icon: 'rain' },
      { day: 'Fri', hi: 29, lo: 20, icon: 'cloud' },
      { day: 'Sat', hi: 32, lo: 22, icon: 'sun' },
      { day: 'Sun', hi: 33, lo: 23, icon: 'sun' },
    ],
  },
  alerts: [
    { id: 1, title: 'Heavy rainfall warning', cat: 'Heavy rainfall', sev: 'severe', area: 'Faisalabad & surroundings', time: '2h ago' },
    { id: 2, title: 'Heatwave advisory', cat: 'Heatwave', sev: 'moderate', area: 'Central Punjab', time: '5h ago' },
  ],
  reports: [
    { id: 'CR-1042', title: 'Water leakage on main canal road', status: 'In Progress', cat: 'Water leakage' },
    { id: 'CR-1039', title: 'Waste accumulation near field 3', status: 'Submitted', cat: 'Waste' },
  ],
  tasks: [
    { id: 1, title: 'Irrigate Field 2 (Wheat)', due: 'Today, 4:00 PM', farm: 'Green Acres' },
    { id: 2, title: 'Apply fertilizer — Maize', due: 'Tomorrow', farm: 'Riverside' },
    { id: 3, title: 'Soil sampling — Field 1', due: 'Sat', farm: 'Green Acres' },
  ],
  activity: [
    { id: 1, text: 'Crop scan completed on Field 2 — Wheat', time: '1h ago', type: 'scan' },
    { id: 2, text: 'Civic report CR-1042 moved to In Progress', time: '3h ago', type: 'report' },
    { id: 3, text: 'Alert acknowledged: Heavy rainfall warning', time: '5h ago', type: 'alert' },
    { id: 4, text: 'Irrigation logged: 1,200 L on Field 1', time: 'Yesterday', type: 'farm' },
  ],
  aiInsight:
    'Soil moisture in Field 2 is trending low and rainfall is expected Thursday. Consider irrigating today and delaying Thursday’s cycle to conserve water. Wheat is in tillering stage — monitor for leaf rust given current humidity.',
};

const SEV_STYLE = {
  extreme: 'bg-red-500/15 text-red-600 border-red-500/30',
  severe: 'bg-orange-500/15 text-orange-600 border-orange-500/30',
  moderate: 'bg-amber-500/15 text-amber-600 border-amber-500/30',
  minor: 'bg-sky-500/15 text-sky-600 border-sky-500/30',
};

function SectionTitle({ title, hint }) {
  return (
    <div className="flex items-baseline justify-between gap-3 pt-1">
      <h2 className="font-heading font-semibold text-sm tracking-tight">{title}</h2>
      {hint && <span className="text-xs text-muted-foreground">{hint}</span>}
    </div>
  );
}

function StatCard({ icon: Icon, label, value, tone, to }) {
  const navigate = useNavigate();
  return (
    <StaggerItem>
      <Widget
        className="p-4 sm:p-5 cursor-pointer hover:-translate-y-0.5 transition-transform"
        onClick={() => to && navigate(to)}
      >
        <div className="flex items-center justify-between">
          <span className={cn('w-10 h-10 rounded-xl flex items-center justify-center', tone)}>
            <Icon className="w-5 h-5" />
          </span>
        </div>
        <p className="mt-3 text-2xl font-heading font-bold tracking-tight">{value}</p>
        <p className="text-xs text-muted-foreground mt-0.5">{label}</p>
      </Widget>
    </StaggerItem>
  );
}

export default function Home() {
  const { t } = useI18n();
  const navigate = useNavigate();

  const quickActions = [
    { label: t('common.reportIssue'), icon: Plus, to: '/community?new=1' },
    { label: t('nav.cropscan'), icon: ScanLine, to: '/crop-scan' },
    { label: t('nav.assistant'), icon: Sparkles, to: '/assistant' },
    { label: t('nav.map'), icon: MapPin, to: '/map' },
  ];

  const categories = SDG_CATEGORIES.filter((c) => c.key !== 'all').map((c) => ({ ...c, count: goalsFor(c.key).length }));
  const featured = SDG_FEATURED.map((n) => SDGS.find((g) => g.n === n)).filter(Boolean);

  return (
    <div className="space-y-5">
      {/* Welcome header */}
      <div className="flex flex-col sm:flex-row sm:items-end sm:justify-between gap-3">
        <div>
          <h1 className="font-heading text-2xl sm:text-3xl font-bold tracking-tight">
            {t('home.welcome')}, Ahsan 👋
          </h1>
          <p className="text-sm text-muted-foreground mt-1 flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5" />
            {SAMPLE.location}
            <span className="mx-1.5 opacity-40">•</span>
            <span className="inline-flex items-center gap-1 text-success">
              <span className="w-1.5 h-1.5 rounded-full bg-success" /> {t('common.online')}
            </span>
          </p>
        </div>
        <div className="text-xs text-muted-foreground">
          {t('common.lastUpdated')}: just now
        </div>
      </div>

      {/* Quick actions */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {quickActions.map((a) => (
          <Button
            key={a.label}
            variant="outline"
            className="h-auto py-3 justify-start gap-2.5 rounded-xl border-border/70 hover:border-primary/40 hover:bg-primary/5"
            onClick={() => navigate(a.to)}
          >
            <span className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center">
              <a.icon className="w-4 h-4" />
            </span>
            <span className="text-sm font-medium">{a.label}</span>
          </Button>
        ))}
      </div>

      {/* Biology Research Lab — the exhibition-facing module */}
      <Widget className="border-primary/25 bg-gradient-to-br from-primary/10 via-primary/5 to-accent/10 p-4 sm:p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex min-w-0 items-start gap-3">
            <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary">
              <FlaskConical className="h-5 w-5" />
            </span>
            <div className="min-w-0">
              <p className="font-heading text-sm font-semibold">{t('research.title')}</p>
              <p className="mt-0.5 text-xs leading-relaxed text-muted-foreground">
                {t('research.dashboardHint')}
              </p>
            </div>
          </div>
          <Button className="shrink-0 gap-2" onClick={() => navigate('/research')}>
            <FlaskConical className="h-4 w-4" />
            {t('research.openLab')}
          </Button>
        </div>
      </Widget>

      {/* Stat cards */}
      <Stagger className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard icon={AlertTriangle} label={t('home.activeAlerts')} value={SAMPLE.stats.alerts} tone="bg-orange-500/15 text-orange-600" to="/weather" />
        <StatCard icon={CheckSquare} label={t('home.openTasks')} value={SAMPLE.stats.tasks} tone="bg-sky-500/15 text-sky-600" to="/farms" />
        <StatCard icon={Droplets} label={t('home.waterUsage')} value={SAMPLE.stats.water} tone="bg-cyan-500/15 text-cyan-600" to="/analytics" />
        <StatCard icon={Leaf} label={t('home.cropHealth')} value={`${SAMPLE.stats.health}%`} tone="bg-primary/15 text-primary" to="/fields" />
      </Stagger>

      {/* Conditions & advisories */}
      <SectionTitle title="Conditions & advisories" hint="Weather, hazards and AI guidance" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <StaggerItem>
          <Widget>
            <WidgetHeader title={t('home.weather')} subtitle={SAMPLE.location} icon={CloudSun} />
            <WidgetBody>
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-sky-400/20 to-primary/10 flex items-center justify-center">
                  <CloudSun className="w-8 h-8 text-sky-500" />
                </div>
                <div>
                  <p className="text-4xl font-heading font-bold">{SAMPLE.weather.temp}°</p>
                  <p className="text-sm text-muted-foreground">{SAMPLE.weather.condition}</p>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-2 mt-4 text-center text-xs">
                <div className="rounded-lg bg-muted/50 py-2">
                  <Droplets className="w-3.5 h-3.5 mx-auto text-cyan-500" />
                  <p className="mt-1 font-semibold">{SAMPLE.weather.humidity}%</p>
                  <p className="text-muted-foreground">Humidity</p>
                </div>
                <div className="rounded-lg bg-muted/50 py-2">
                  <Activity className="w-3.5 h-3.5 mx-auto text-slate-400" />
                  <p className="mt-1 font-semibold">{SAMPLE.weather.wind} km/h</p>
                  <p className="text-muted-foreground">Wind</p>
                </div>
                <div className="rounded-lg bg-muted/50 py-2">
                  <CloudSun className="w-3.5 h-3.5 mx-auto text-sky-400" />
                  <p className="mt-1 font-semibold">{SAMPLE.weather.rainfall} mm</p>
                  <p className="text-muted-foreground">Rain</p>
                </div>
              </div>
              <div className="flex justify-between mt-4 pt-3 border-t border-border">
                {SAMPLE.weather.forecast.map((f) => (
                  <div key={f.day} className="text-center">
                    <p className="text-[10px] text-muted-foreground">{f.day}</p>
                    <CloudSun className="w-4 h-4 mx-auto my-1 text-sky-400" />
                    <p className="text-[11px] font-semibold">{f.hi}°</p>
                    <p className="text-[10px] text-muted-foreground">{f.lo}°</p>
                  </div>
                ))}
              </div>
            </WidgetBody>
          </Widget>
        </StaggerItem>

        <StaggerItem>
          <Widget>
            <WidgetHeader
              title={t('home.activeAlerts')}
              subtitle="Environmental hazards affecting your area"
              icon={AlertTriangle}
              action={
                <Button variant="ghost" size="sm" className="text-xs" onClick={() => navigate('/weather')}>
                  {t('common.viewAll')}
                </Button>
              }
            />
            <WidgetBody className="space-y-3">
              {SAMPLE.alerts.map((a) => (
                <div key={a.id} className="rounded-xl border border-border p-3 hover:border-primary/30 transition-colors">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-medium text-sm">{a.title}</p>
                    <Badge variant="outline" className={cn('text-[10px] capitalize', SEV_STYLE[a.sev])}>
                      {t(`alert.severity.${a.sev}`)}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{a.cat} • {a.area}</p>
                  <p className="text-[11px] text-muted-foreground/70 mt-1">{a.time}</p>
                </div>
              ))}
            </WidgetBody>
          </Widget>
        </StaggerItem>
      </div>

      {/* AI insight — full width so the guidance is readable, not squeezed */}
      <StaggerItem>
        <Widget className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
          <WidgetHeader title={t('home.aiInsight')} subtitle="Field conditions and crop development" icon={Sparkles} />
          <WidgetBody>
            <p className="text-sm leading-relaxed text-foreground/90 max-w-3xl">{SAMPLE.aiInsight}</p>
            <div className="flex flex-wrap items-center gap-2 mt-3">
              <Badge variant="secondary" className="text-[10px] gap-1">
                <Sparkles className="w-3 h-3" /> AI Generated
              </Badge>
              <Button variant="ghost" size="sm" className="ms-auto text-xs gap-1" onClick={() => navigate('/assistant')}>
                Ask more <ArrowRight className="w-3 h-3 flip-x" />
              </Button>
            </div>
            <p className="text-[10px] text-muted-foreground/70 mt-2">{t('home.aiDisclaimer')}</p>
          </WidgetBody>
        </Widget>
      </StaggerItem>

      {/* Work & community */}
      <SectionTitle title="Work & community" hint="Your tasks and neighbourhood reports" />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <StaggerItem>
          <Widget>
            <WidgetHeader title={t('home.upcomingTasks')} icon={CheckSquare} action={<Button variant="ghost" size="sm" className="text-xs" onClick={() => navigate('/farms')}>{t('common.viewAll')}</Button>} />
            <WidgetBody className="space-y-2.5">
              {SAMPLE.tasks.map((task) => (
                <div key={task.id} className="flex items-center gap-3 rounded-lg p-2 hover:bg-muted/50 transition-colors">
                  <span className="w-2 h-2 rounded-full bg-primary shrink-0" />
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{task.title}</p>
                    <p className="text-xs text-muted-foreground">{task.farm} • {task.due}</p>
                  </div>
                </div>
              ))}
            </WidgetBody>
          </Widget>
        </StaggerItem>

        <StaggerItem>
          <Widget>
            <WidgetHeader title={t('home.recentReports')} icon={Bell} action={<Button variant="ghost" size="sm" className="text-xs" onClick={() => navigate('/community')}>{t('common.viewAll')}</Button>} />
            <WidgetBody className="space-y-3">
              {SAMPLE.reports.map((r) => (
                <div key={r.id} className="rounded-xl border border-border p-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-medium text-sm truncate">{r.title}</p>
                    <Badge variant="outline" className="text-[10px] shrink-0">{r.status}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{r.id} • {r.cat}</p>
                </div>
              ))}
            </WidgetBody>
          </Widget>
        </StaggerItem>
      </div>

      {/* Sustainability tracking */}
      <SectionTitle title="Sustainability tracking" hint="17 goals, grouped into five themes" />
      <StaggerItem>
        <Widget>
          <WidgetHeader
            title={t('home.sdgSnapshot')}
            subtitle="Every module maps to a goal — open the explorer for the full indicator matrix"
            icon={Target}
            action={
              <Button variant="outline" size="sm" className="text-xs" onClick={() => navigate('/impact')}>
                Open explorer <ArrowRight className="w-3 h-3 flip-x" />
              </Button>
            }
          />
          <WidgetBody className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
              {categories.map((c) => (
                <button
                  key={c.key}
                  onClick={() => navigate('/impact')}
                  className="rounded-xl border border-border/70 p-3.5 text-start hover:border-primary/40 transition-colors"
                >
                  <span className="inline-flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: c.tint }} />
                    <span className="font-heading font-semibold text-sm">{c.label}</span>
                  </span>
                  <p className="text-[11px] text-muted-foreground mt-1">{c.hint}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">{c.count} goals mapped</p>
                </button>
              ))}
            </div>

            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
              {featured.map((g) => (
                <button
                  key={g.n}
                  onClick={() => navigate('/impact')}
                  className="rounded-xl border border-border/70 p-3.5 text-start hover:border-primary/40 transition-colors"
                >
                  <span className="w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs font-bold" style={{ background: g.color }}>
                    {g.n}
                  </span>
                  <p className="font-medium text-xs mt-2.5 leading-snug">{g.name}</p>
                  <p className="text-[10px] text-muted-foreground mt-1 leading-snug">{g.feature}</p>
                </button>
              ))}
            </div>

            <div className="flex flex-col sm:flex-row sm:items-center gap-3 rounded-xl bg-muted/50 p-3.5">
              <p className="text-[11px] text-muted-foreground leading-relaxed flex-1">
                Indicator values are computed from your own farm records. Anything that cannot be measured is
                shown as “no data” — this is not an official UN SDG score.
              </p>
              <Button variant="outline" size="sm" className="gap-1.5 shrink-0" onClick={() => navigate('/biology')}>
                <Dna className="w-3.5 h-3.5" /> Biology Lab
              </Button>
            </div>
          </WidgetBody>
        </Widget>
      </StaggerItem>

      {/* Activity timeline */}
      <SectionTitle title={t('home.activity')} hint="Latest events across the platform" />
      <StaggerItem>
        <Widget>
          <WidgetBody className="pt-5">
            <ol className="relative space-y-4 ps-6">
              <span className="absolute start-[7px] top-1 bottom-1 w-px bg-border" />
              {SAMPLE.activity.map((a) => (
                <li key={a.id} className="relative">
                  <span className="absolute -start-[18px] top-1.5 w-3 h-3 rounded-full bg-primary ring-4 ring-primary/10" />
                  <p className="text-sm">{a.text}</p>
                  <p className="text-[11px] text-muted-foreground">{a.time}</p>
                </li>
              ))}
            </ol>
          </WidgetBody>
        </Widget>
      </StaggerItem>

      <p className="text-center text-[11px] text-muted-foreground/60 pt-1">
        Demonstration data — live records replace this once data sources are connected.
      </p>
    </div>
  );
}