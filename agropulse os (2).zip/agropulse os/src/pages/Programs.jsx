import { Link } from 'react-router-dom';
import { Store, ShieldCheck, GraduationCap, Users, Droplets, Zap, Briefcase, ScanLine, Accessibility, Truck, Recycle, CloudSun, Waves, Layers, FileText, BarChart3, ArrowRight } from 'lucide-react';
import { Widget } from '@/components/common/Widget';
import { Badge } from '@/components/ui/badge';

const FEATURES = [
  { icon: Store, title: 'Farmer-to-Buyer Marketplace', desc: 'Direct listings, transparent pricing, and local mandi rate feeds.', to: '/programs/marketplace', sdg: 2 },
  { icon: ShieldCheck, title: 'Agro-Safety & Pesticide Advisory', desc: 'Eco-friendly dosage calculators and chemical safety guides.', to: '/programs/pesticide-advisory', sdg: 3 },
  { icon: GraduationCap, title: 'Knowledge Hub', desc: 'Voice-guided tutorials and step-by-step disease identification.', to: '/programs/knowledge-hub', sdg: 4 },
  { icon: Users, title: 'Women Agro-Entrepreneur Directory', desc: 'Micro-grants, vendor badges, and peer network forums.', to: '/programs/directory', sdg: 5 },
  { icon: Droplets, title: 'Smart Irrigation Manager', desc: 'Crop-water calculators using weather data to prevent runoff.', to: '/programs/irrigation', sdg: 6 },
  { icon: Zap, title: 'Clean Tech Equipment Rental', desc: 'Peer-to-peer solar pumps, cold storage, and renewable tools.', to: '/programs/equipment', sdg: 7 },
  { icon: Briefcase, title: 'Fair Labor & Wage Job Board', desc: 'Seasonal jobs with fair-wage standards and safety guidelines.', to: '/programs/jobs', sdg: 8 },
  { icon: ScanLine, title: 'AI Disease Diagnosis', desc: 'Offline-first AI image detection for crop diseases.', to: '/crop-scan', sdg: 9 },
  { icon: Accessibility, title: 'Accessibility & Low-Bandwidth', desc: 'Optimized for 2G/3G networks, basic phones, and screen readers.', to: '/settings', sdg: 10 },
  { icon: Truck, title: 'Urban-Periurban Produce Links', desc: 'Hyper-local farm-to-table routes supplying urban food deserts.', to: '/programs/marketplace', sdg: 11 },
  { icon: Recycle, title: 'Composting & Waste Reduction', desc: 'Surplus redistribution and crop-residue-to-bio-fertilizer tracking.', to: '/programs/composting', sdg: 12 },
  { icon: CloudSun, title: 'Extreme Weather Alerts', desc: 'Push alerts for weather shifts with crop-specific recovery steps.', to: '/weather', sdg: 13 },
  { icon: Waves, title: 'Nitrogen Balance Module', desc: 'Soil-nitrogen tools to stop fertilizer leaching into waterways.', to: '/programs/nitrogen-balance', sdg: 14 },
  { icon: Layers, title: 'Soil Health Tracker', desc: 'Crop rotation planners, soil-testing loggers, and bio-fertilizer recipes.', to: '/fields', sdg: 15 },
  { icon: FileText, title: 'Land Rights & Contract Registry', desc: 'Transparent contract templates to protect tenant farmers.', to: '/programs/contracts', sdg: 16 },
  { icon: BarChart3, title: 'Open SDG Analytics Dashboard', desc: 'Real-time open data sharing with NGOs, government, and researchers.', to: '/analytics', sdg: 17 },
];

export default function Programs() {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">Programs</h1>
        <p className="text-sm text-muted-foreground mt-1">All 16 SDG-linked features. Each tool serves smallholder farmers directly — no middleman, no gatekeeping.</p>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {FEATURES.map((f) => (
          <Link key={f.title} to={f.to}>
            <Widget className="p-5 h-full hover:-translate-y-0.5 transition-transform">
              <div className="flex items-start gap-3">
                <span className="w-11 h-11 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0"><f.icon className="w-5 h-5" /></span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-heading font-semibold text-sm">{f.title}</p>
                    <Badge variant="secondary" className="text-[9px] bg-primary/10 text-primary shrink-0">SDG {f.sdg}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1 leading-relaxed">{f.desc}</p>
                  <span className="inline-flex items-center gap-1 text-xs text-primary mt-2">Open <ArrowRight className="w-3 h-3 flip-x" /></span>
                </div>
              </div>
            </Widget>
          </Link>
        ))}
      </div>
    </div>
  );
}