import { useState } from 'react';
import { Sprout, Plus, MapPin, Trash2, Loader2, Layers } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { useCollection } from '@/hooks/useCollection';
import { useCount } from '@/hooks/useCollection';

export default function Farms() {
  const { t } = useI18n();
  const { data: farms, loading, reload } = useCollection('Farm', { sort: '-created_date', limit: 100 });
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', location_text: '', lat: '', lng: '', area_hectares: '', crop_focus: '', notes: '' });
  const [err, setErr] = useState('');

  async function save() {
    if (!form.name) return setErr('Farm name is required.');
    setSaving(true);
    setErr('');
    try {
      await base44.entities.Farm.create({
        name: form.name,
        location_text: form.location_text,
        lat: form.lat ? Number(form.lat) : undefined,
        lng: form.lng ? Number(form.lng) : undefined,
        area_hectares: form.area_hectares ? Number(form.area_hectares) : undefined,
        crop_focus: form.crop_focus,
        notes: form.notes,
        status: 'active',
      });
      setForm({ name: '', location_text: '', lat: '', lng: '', area_hectares: '', crop_focus: '', notes: '' });
      setOpen(false);
      reload();
    } catch (e) {
      setErr(e?.message || 'Could not save farm.');
    } finally {
      setSaving(false);
    }
  }

  async function remove(id) {
    if (!confirm('Delete this farm and its linked records?')) return;
    await base44.entities.Farm.delete(id);
    reload();
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">{t('nav.farms')}</h1>
          <p className="text-sm text-muted-foreground mt-1">Manage your farms, fields and boundaries.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button className="gap-2"><Plus className="w-4 h-4" /> Add farm</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add a farm</DialogTitle>
            </DialogHeader>
            <div className="grid gap-3 py-2">
              <div><Label>Name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1" placeholder="Green Acres" /></div>
              <div><Label>Location</Label><Input value={form.location_text} onChange={(e) => setForm({ ...form, location_text: e.target.value })} className="mt-1" placeholder="Faisalabad, Punjab" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Latitude</Label><Input value={form.lat} onChange={(e) => setForm({ ...form, lat: e.target.value })} className="mt-1" placeholder="31.4504" /></div>
                <div><Label>Longitude</Label><Input value={form.lng} onChange={(e) => setForm({ ...form, lng: e.target.value })} className="mt-1" placeholder="73.135" /></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Area (ha)</Label><Input value={form.area_hectares} onChange={(e) => setForm({ ...form, area_hectares: e.target.value })} className="mt-1" placeholder="12.5" /></div>
                <div><Label>Crop focus</Label><Input value={form.crop_focus} onChange={(e) => setForm({ ...form, crop_focus: e.target.value })} className="mt-1" placeholder="Wheat" /></div>
              </div>
              <div><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="mt-1" rows={2} /></div>
              {err && <p className="text-sm text-destructive">{err}</p>}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={save} disabled={saving} className="gap-2">{saving && <Loader2 className="w-4 h-4 animate-spin" />} Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : farms.length === 0 ? (
        <Widget className="p-10 text-center text-muted-foreground">
          <Sprout className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p className="text-sm">No farms yet. Add your first farm to get started.</p>
        </Widget>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {farms.map((f) => (
            <FarmCard key={f.id} farm={f} onDelete={() => remove(f.id)} />
          ))}
        </div>
      )}
    </div>
  );
}

function FarmCard({ farm, onDelete }) {
  const { count: fields } = useCount('Field', { farm_id: farm.id });
  const { count: tasks } = useCount('Task', { farm_id: farm.id, status: 'pending' });
  return (
    <Widget className="p-4 group">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2.5">
          <span className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><Sprout className="w-5 h-5" /></span>
          <div>
            <p className="font-heading font-semibold">{farm.name}</p>
            <p className="text-xs text-muted-foreground flex items-center gap-1"><MapPin className="w-3 h-3" />{farm.location_text || '—'}</p>
          </div>
        </div>
        <button onClick={onDelete} className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive"><Trash2 className="w-4 h-4" /></button>
      </div>
      <div className="flex flex-wrap gap-2 mt-3">
        <Badge variant="secondary" className="gap-1 text-xs"><Layers className="w-3 h-3" /> {fields ?? 0} fields</Badge>
        <Badge variant="secondary" className="text-xs">{tasks ?? 0} open tasks</Badge>
        {farm.crop_focus && <Badge variant="outline" className="text-xs">{farm.crop_focus}</Badge>}
        {farm.area_hectares && <Badge variant="outline" className="text-xs">{farm.area_hectares} ha</Badge>}
      </div>
    </Widget>
  );
}