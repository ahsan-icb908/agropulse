import { useState } from 'react';
import { BookOpen, Volume2, Video, Bug, Droplets, Sprout, Recycle, CloudSun, FlaskConical, Square } from 'lucide-react';
import { Widget } from '@/components/common/Widget';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useSpeech } from '@/hooks/useSpeech';
import { useI18n } from '@/i18n/LanguageContext';

const TUTORIALS = [
  {
    icon: Bug, category: 'Disease ID', type: 'guide', title: 'Identifying Common Wheat Diseases',
    desc: 'Step-by-step visual guide to rust, smut, and blight in wheat crops.',
    content: 'Yellow rust appears as yellow-orange stripes on leaves, most visible in cool humid weather (15-20°C). Brown rust forms reddish-brown pustules in warmer conditions. Smut replaces grain heads with black powdery masses. For each: inspect the flag leaf at tillering. If rust covers more than 5% of the leaf area, apply a fungicide immediately. Remove and burn smutted heads. Rotate to a non-cereal crop next season. Plant resistant varieties like Inqlab-91 or Faisalabad-2008.',
  },
  {
    icon: Droplets, category: 'Water', type: 'audio', title: 'Efficient Irrigation Techniques',
    desc: 'Voice-guided tutorial on drip, furrow, and sprinkler irrigation methods.',
    content: 'Drip irrigation delivers water directly to the root zone, saving 40-60% of water compared to flood irrigation. Install drip lines along each crop row with emitters every 30cm. Run the system for 2-4 hours every 2-3 days. For furrow irrigation, keep furrows short (under 100m) to ensure even distribution. Avoid irrigating during the hottest part of the day — early morning (before 8 AM) is ideal. Check soil moisture by digging 15cm deep; if the soil holds together when squeezed, it is adequately moist.',
  },
  {
    icon: Sprout, category: 'Soil', type: 'guide', title: 'Soil Testing and pH Management',
    desc: 'How to test your soil and adjust pH for optimal crop growth.',
    content: 'Collect 5-6 samples from different parts of the field at 15cm depth. Mix them together and test with a pH kit or send to a lab. Ideal pH for most crops is 6.0-7.0. If pH is below 5.5 (acidic), apply agricultural lime (1-2 tons/ha). If pH is above 8.5 (alkaline), apply gypsum (500 kg/ha) and add organic matter. Test soil every 2-3 years. Also check nitrogen, phosphorus, and potassium levels to plan fertilizer application.',
  },
  {
    icon: Recycle, category: 'Composting', type: 'video', title: 'Making Bio-Fertilizer from Crop Residue',
    desc: 'Video tutorial on converting farm waste into nutrient-rich compost.',
    content: 'Build a compost pile 1.5m wide and 1m high. Layer crop residue (straw, stalks) with manure in a 3:1 ratio. Keep the pile moist — like a wrung-out sponge. Turn the pile every 2 weeks to aerate. The compost will be ready in 2-3 months when it is dark, crumbly, and smells earthy. A C:N ratio of 25-30:1 is ideal. Add the finished compost to your field at 5-10 tons/ha before sowing to improve soil structure and reduce the need for synthetic fertilizer.',
  },
  {
    icon: CloudSun, category: 'Weather', type: 'guide', title: 'Frost and Heatwave Recovery',
    desc: 'What to do when extreme weather damages your crops.',
    content: 'Frost: If frost is forecast, irrigate the field the evening before — wet soil retains heat. For young crops, cover with plastic sheets or straw. After frost damage, wait 5-7 days before assessing — plants may recover. Apply a light nitrogen dose (20 kg/ha) to stimulate new growth. Heatwave: Irrigate early morning to reduce stress. Apply mulch to keep soil cool. If leaves are scorched, do not remove them — they still provide shade. Harvest earlier than planned if the crop is near maturity to avoid further loss.',
  },
  {
    icon: FlaskConical, category: 'Pest Control', type: 'audio', title: 'Integrated Pest Management (IPM)',
    desc: 'A holistic approach combining biological, cultural, and chemical controls.',
    content: 'IPM reduces pesticide use by combining multiple strategies. 1) Monitor pest populations with pheromone traps — only spray when thresholds are exceeded. 2) Use biological controls: release ladybugs for aphids, use Trichogramma cards for bollworm. 3) Practice crop rotation to break pest cycles. 4) Plant trap crops (marigold, sunflower) around the field edge. 5) Use chemical pesticides only as a last resort, choosing the least toxic option. Always follow the label dosage and observe pre-harvest intervals.',
  },
  {
    icon: Sprout, category: 'Farming', type: 'guide', title: 'Crop Rotation Planning',
    desc: 'Plan your rotation to improve soil health and break pest cycles.',
    content: 'A good rotation alternates crop families: cereal → legume → cereal → oilseed. Example: Wheat (Rabi) → Rice or Cotton (Kharif) → Wheat → Mung bean. Legumes fix 50-100 kg/ha of atmospheric nitrogen, reducing fertilizer needs for the next cereal crop. Rotation breaks disease and pest cycles by removing the host plant for a season. Deep-rooted crops (maize, cotton) break compacted soil layers. Plan 3-4 years ahead and keep records of what was planted where.',
  },
  {
    icon: Bug, category: 'Disease ID', type: 'video', title: 'Cotton Pest Identification',
    desc: 'Visual guide to identifying mealybug, whitefly, and bollworm in cotton.',
    content: 'Mealybug: White, cottony masses on stems and leaf undersides. Treat with neem oil (5 ml/L) or release Cryptolaemus beetles. Whitefly: Tiny white flies that scatter when disturbed. They cause leaf curling and transmit viruses. Use yellow sticky traps (5/ha) and spray with imidacloprid only if populations exceed 5 per leaf. Bollworm: Check for square and boll damage. Use pheromone traps to monitor. Spray Bt or NPV at the larval stage. Avoid broad-spectrum pesticides that kill beneficial insects.',
  },
];

const TYPE_ICON = { guide: BookOpen, audio: Volume2, video: Video };

export default function KnowledgeHub() {
  const [active, setActive] = useState(null);
  const [filter, setFilter] = useState('all');
  const { speak, stop, speaking, supported } = useSpeech();
  const { lang } = useI18n();

  const categories = ['all', ...Array.from(new Set(TUTORIALS.map((t) => t.category)))];
  const filtered = filter === 'all' ? TUTORIALS : TUTORIALS.filter((t) => t.category === filter);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">Knowledge Hub</h1>
        <p className="text-sm text-muted-foreground mt-1">Voice-guided tutorials, disease identification guides, and video modules for all literacy levels.</p>
      </div>

      <div className="flex flex-wrap gap-2">
        {categories.map((c) => (
          <button key={c} onClick={() => setFilter(c)} className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${filter === c ? 'border-border bg-card text-foreground shadow-sm' : 'border-border bg-muted/40 text-muted-foreground'}`}>{c === 'all' ? 'All topics' : c}</button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map((t, i) => {
          const TypeIcon = TYPE_ICON[t.type];
          return (
            <button key={i} onClick={() => setActive(t)} className="text-start">
              <Widget className="p-5 h-full hover:-translate-y-0.5 transition-transform">
                <div className="flex items-center justify-between mb-3">
                  <span className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center"><t.icon className="w-5 h-5" /></span>
                  <Badge variant="secondary" className="gap-1 text-[10px]"><TypeIcon className="w-3 h-3" /> {t.type}</Badge>
                </div>
                <p className="font-heading font-semibold text-sm">{t.title}</p>
                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{t.desc}</p>
                <span className="text-xs text-primary mt-2 inline-block">Read guide →</span>
              </Widget>
            </button>
          );
        })}
      </div>

      <Dialog open={!!active} onOpenChange={() => setActive(null)}>
        <DialogContent className="max-w-lg">
          {active && (
            <>
              <DialogHeader>
                <DialogTitle className="flex items-center gap-2.5">
                  <span className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center"><active.icon className="w-4 h-4" /></span>
                  {active.title}
                </DialogTitle>
              </DialogHeader>
              <div className="space-y-3 py-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary" className="text-[10px]">{active.category}</Badge>
                    <Badge variant="outline" className="text-[10px] gap-1">{(() => { const TypeIcon = TYPE_ICON[active.type]; return <><TypeIcon className="w-3 h-3" /> {active.type}</>; })()}</Badge>
                  </div>
                  {supported && (
                    <Button size="sm" variant="outline" onClick={() => (speaking ? stop() : speak(active.content, lang))} className="gap-1.5 h-7">
                      {speaking ? <><Square className="w-3.5 h-3.5" /> Stop</> : <><Volume2 className="w-3.5 h-3.5" /> Listen</>}
                    </Button>
                  )}
                </div>
                <p className="text-sm leading-relaxed">{active.content}</p>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}