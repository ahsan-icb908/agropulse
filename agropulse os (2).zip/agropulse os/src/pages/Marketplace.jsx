import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Store, Plus, Trash2, Loader2, MapPin, Phone, Truck, HandCoins } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCollection } from '@/hooks/useCollection';
import MandiRates from '@/components/marketplace/MandiRates';

const CATEGORIES = [
  { key: 'grain', label: 'Grain' }, { key: 'vegetable', label: 'Vegetable' }, { key: 'fruit', label: 'Fruit' },
  { key: 'dairy', label: 'Dairy' }, { key: 'livestock', label: 'Livestock' }, { key: 'other', label: 'Other' },
];

export default function Marketplace() {
  const { data, loading, reload } = useCollection('Listing', { sort: '-created_date', limit: 100 });
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [filter, setFilter] = useState('all');
  const [form, setForm] = useState({ title: '', crop: '', category: 'grain', quantity: '', quantity_unit: 'kg', price: '', price_unit: 'per_kg', farm_name: '', location_text: '', seller_contact: '', description: '', is_urban_link: false });

  async function save() {
    setSaving(true);
    try {
      await base44.entities.Listing.create({
        ...form,
        quantity: Number(form.quantity) || 0,
        price: Number(form.price) || 0,
      });
      setForm({ title: '', crop: '', category: 'grain', quantity: '', quantity_unit: 'kg', price: '', price_unit: 'per_kg', farm_name: '', location_text: '', seller_contact: '', description: '', is_urban_link: false });
      setOpen(false);
      reload();
    } finally { setSaving(false); }
  }

  async function remove(id) { await base44.entities.Listing.delete(id); reload(); }

  const filtered = filter === 'all' ? data : data.filter((l) => l.category === filter);

  return (
    <div className="space-y-5">
      <MandiRates />
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">Marketplace</h1>
          <p className="text-sm text-muted-foreground mt-1">Direct farmer-to-buyer listings. No middleman commissions.</p>
        </div>
        <div className="flex items-center gap-2">
        <Button asChild variant="outline" className="gap-2">
          <Link to="/mandi-connect"><HandCoins className="w-4 h-4" /> Mandi Connect</Link>
        </Button>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="gap-2"><Plus className="w-4 h-4" /> New listing</Button></DialogTrigger>
          <DialogContent className="max-w-lg">
            <DialogHeader><DialogTitle>New produce listing</DialogTitle></DialogHeader>
            <div className="grid gap-3 py-2 max-h-[60vh] overflow-y-auto">
              <div><Label>Title *</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="mt-1" placeholder="Fresh wheat harvest" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Crop *</Label><Input value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} className="mt-1" placeholder="Wheat" /></div>
                <div><Label>Category</Label><Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{CATEGORIES.map((c) => <SelectItem key={c.key} value={c.key}>{c.label}</SelectItem>)}</SelectContent></Select></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Quantity *</Label><Input type="number" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} className="mt-1" placeholder="500" /></div>
                <div><Label>Unit</Label><Select value={form.quantity_unit} onValueChange={(v) => setForm({ ...form, quantity_unit: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['kg', 'tons', 'maunds', 'dozen', 'bag'].map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent></Select></div>
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Price *</Label><Input type="number" value={form.price} onChange={(e) => setForm({ ...form, price: e.target.value })} className="mt-1" placeholder="2200" /></div>
                <div><Label>Price unit</Label><Select value={form.price_unit} onValueChange={(v) => setForm({ ...form, price_unit: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['per_kg', 'per_dozen', 'per_bag', 'per_maund', 'total'].map((u) => <SelectItem key={u} value={u}>{u.replace('_', '/')}</SelectItem>)}</SelectContent></Select></div>
              </div>
              <div><Label>Farm name</Label><Input value={form.farm_name} onChange={(e) => setForm({ ...form, farm_name: e.target.value })} className="mt-1" /></div>
              <div><Label>Location</Label><Input value={form.location_text} onChange={(e) => setForm({ ...form, location_text: e.target.value })} className="mt-1" placeholder="Faisalabad" /></div>
              <div><Label>Contact</Label><Input value={form.seller_contact} onChange={(e) => setForm({ ...form, seller_contact: e.target.value })} className="mt-1" placeholder="0300-1234567" /></div>
              <div><Label>Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="mt-1" rows={2} /></div>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.is_urban_link} onChange={(e) => setForm({ ...form, is_urban_link: e.target.checked })} /> Urban farm-to-table link</label>
            </div>
            <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} disabled={saving} className="gap-2">{saving && <Loader2 className="w-4 h-4 animate-spin" />} Publish</Button></DialogFooter>
          </DialogContent>
        </Dialog>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <FilterChip active={filter === 'all'} onClick={() => setFilter('all')} label="All" />
        {CATEGORIES.map((c) => <FilterChip key={c.key} active={filter === c.key} onClick={() => setFilter(c.key)} label={c.label} />)}
      </div>

      {loading ? <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        : filtered.length === 0 ? <Widget className="p-10 text-center text-muted-foreground"><Store className="w-10 h-10 mx-auto mb-3 opacity-40" /><p className="text-sm">No listings yet. Publish your first produce to reach buyers directly.</p></Widget>
        : <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">{filtered.map((l) => <ListingCard key={l.id} listing={l} onDelete={() => remove(l.id)} />)}</div>}
    </div>
  );
}

function FilterChip({ active, onClick, label }) {
  return <button onClick={onClick} className={`rounded-full border px-3 py-1.5 text-xs font-medium transition-colors ${active ? 'border-border bg-card text-foreground shadow-sm' : 'border-border bg-muted/40 text-muted-foreground'}`}>{label}</button>;
}

function ListingCard({ listing, onDelete }) {
  return (
    <Widget className="p-4 group">
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-2.5 min-w-0">
          <span className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0"><Store className="w-5 h-5" /></span>
          <div className="min-w-0">
            <p className="font-heading font-semibold truncate">{listing.title}</p>
            <p className="text-xs text-muted-foreground truncate">{listing.crop} · {listing.quantity} {listing.quantity_unit}</p>
          </div>
        </div>
        <button onClick={onDelete} className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive shrink-0"><Trash2 className="w-4 h-4" /></button>
      </div>
      <div className="mt-3 flex flex-wrap items-center gap-2">
        <Badge className="bg-primary text-primary-foreground">PKR {listing.price?.toLocaleString()} {listing.price_unit?.replace('_', '/')}</Badge>
        {listing.is_urban_link && <Badge variant="secondary" className="gap-1 bg-sky-500/10 text-sky-700"><Truck className="w-3 h-3" /> Urban link</Badge>}
        {listing.location_text && <Badge variant="outline" className="gap-1"><MapPin className="w-3 h-3" /> {listing.location_text}</Badge>}
      </div>
      {listing.description && <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{listing.description}</p>}
      {listing.seller_contact && <p className="text-xs text-muted-foreground mt-2 flex items-center gap-1"><Phone className="w-3 h-3" /> {listing.seller_contact}</p>}
    </Widget>
  );
}