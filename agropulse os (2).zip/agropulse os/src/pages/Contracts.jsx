import { useState } from 'react';
import { FileText, Plus, Trash2, Loader2, Scale, Copy, Check } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCollection } from '@/hooks/useCollection';

const STATUS_STYLES = {
  draft: 'bg-muted text-muted-foreground', active: 'bg-emerald-500/10 text-emerald-700',
  completed: 'bg-sky-500/10 text-sky-700', disputed: 'bg-destructive/10 text-destructive',
};

const FAIR_TEMPLATE = `This tenancy agreement is made between {landlord} (Landlord) and {tenant} (Tenant) for {area} {unit} of agricultural land located at the stated address.

1. TENANCY PERIOD: From {start} to {end}.
2. RENT: PKR {rent} {rent_unit}, payable as agreed by both parties.
3. FAIR USE: The Tenant has the right to choose crops and farming methods. The Landlord shall not interfere with day-to-day operations.
4. COST SHARING: Seeds, fertilizer, and water costs are borne by the Tenant unless otherwise agreed in writing.
5. DISPUTE RESOLUTION: Any dispute shall first be referred to the local agricultural committee before any legal action.
6. TERMINATION: Either party may terminate with 30 days written notice. The Tenant has the right to harvest any standing crop.
7. RENEWAL: The Tenant has the first right of refusal for the next season under the same or renegotiated terms.

Both parties acknowledge they have read and understood this agreement.`;

export default function Contracts() {
  const { data, loading, reload } = useCollection('Contract', { sort: '-created_date', limit: 100 });
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ title: '', tenant_name: '', landlord_name: '', land_area: '', area_unit: 'acres', start_date: '', end_date: '', rent_amount: '', rent_unit: 'per_season', terms: '', notes: '' });
  const [templateOpen, setTemplateOpen] = useState(false);
  const [copied, setCopied] = useState(false);

  async function save() {
    setSaving(true);
    try {
      await base44.entities.Contract.create({ ...form, land_area: Number(form.land_area) || 0, rent_amount: Number(form.rent_amount) || 0, status: 'draft' });
      setForm({ title: '', tenant_name: '', landlord_name: '', land_area: '', area_unit: 'acres', start_date: '', end_date: '', rent_amount: '', rent_unit: 'per_season', terms: '', notes: '' });
      setOpen(false); reload();
    } finally { setSaving(false); }
  }
  async function remove(id) { await base44.entities.Contract.delete(id); reload(); }
  async function setStatus(id, status) { await base44.entities.Contract.update(id, { status }); reload(); }

  function generateTemplate() {
    const text = FAIR_TEMPLATE
      .replace('{landlord}', form.landlord_name || '[Landlord]')
      .replace('{tenant}', form.tenant_name || '[Tenant]')
      .replace('{area}', form.land_area || '[Area]')
      .replace('{unit}', form.area_unit)
      .replace('{start}', form.start_date || '[Start date]')
      .replace('{end}', form.end_date || '[End date]')
      .replace('{rent}', form.rent_amount || '[Amount]')
      .replace('{rent_unit}', form.rent_unit.replace('_', ' '));
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">Contract Registry</h1>
          <p className="text-sm text-muted-foreground mt-1">Transparent, fair contract templates to protect tenant farmers from exploitation.</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="gap-2" onClick={() => setTemplateOpen(true)}><Scale className="w-4 h-4" /> Template</Button>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild><Button className="gap-2"><Plus className="w-4 h-4" /> New contract</Button></DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader><DialogTitle>New tenancy contract</DialogTitle></DialogHeader>
              <div className="grid gap-3 py-2 max-h-[60vh] overflow-y-auto">
                <div><Label>Title *</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="mt-1" placeholder="2025 Rabi tenancy" /></div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Tenant name *</Label><Input value={form.tenant_name} onChange={(e) => setForm({ ...form, tenant_name: e.target.value })} className="mt-1" /></div>
                  <div><Label>Landlord name</Label><Input value={form.landlord_name} onChange={(e) => setForm({ ...form, landlord_name: e.target.value })} className="mt-1" /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Land area</Label><Input type="number" value={form.land_area} onChange={(e) => setForm({ ...form, land_area: e.target.value })} className="mt-1" /></div>
                  <div><Label>Unit</Label><Select value={form.area_unit} onValueChange={(v) => setForm({ ...form, area_unit: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['acres', 'hectares', 'kanal', 'marla'].map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent></Select></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Start date</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} className="mt-1" /></div>
                  <div><Label>End date</Label><Input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} className="mt-1" /></div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><Label>Rent (PKR)</Label><Input type="number" value={form.rent_amount} onChange={(e) => setForm({ ...form, rent_amount: e.target.value })} className="mt-1" /></div>
                  <div><Label>Rent unit</Label><Select value={form.rent_unit} onValueChange={(v) => setForm({ ...form, rent_unit: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['per_season', 'per_year', 'per_month'].map((u) => <SelectItem key={u} value={u}>{u.replace('_', '/')}</SelectItem>)}</SelectContent></Select></div>
                </div>
                <div><Label>Terms</Label><Textarea value={form.terms} onChange={(e) => setForm({ ...form, terms: e.target.value })} className="mt-1" rows={3} /></div>
              </div>
              <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} disabled={saving} className="gap-2">{saving && <Loader2 className="w-4 h-4 animate-spin" />} Save</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Dialog open={templateOpen} onOpenChange={setTemplateOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Fair Contract Template</DialogTitle></DialogHeader>
          <p className="text-sm text-muted-foreground mb-3">Fill in the form fields, then copy the standard fair-tenancy template below. Both parties should sign two printed copies.</p>
          <div className="grid gap-3 mb-3">
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Tenant</Label><Input value={form.tenant_name} onChange={(e) => setForm({ ...form, tenant_name: e.target.value })} className="mt-1" /></div>
              <div><Label>Landlord</Label><Input value={form.landlord_name} onChange={(e) => setForm({ ...form, landlord_name: e.target.value })} className="mt-1" /></div>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div><Label>Area</Label><Input value={form.land_area} onChange={(e) => setForm({ ...form, land_area: e.target.value })} className="mt-1" /></div>
              <div><Label>Start</Label><Input type="date" value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} className="mt-1" /></div>
              <div><Label>End</Label><Input type="date" value={form.end_date} onChange={(e) => setForm({ ...form, end_date: e.target.value })} className="mt-1" /></div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div><Label>Rent (PKR)</Label><Input value={form.rent_amount} onChange={(e) => setForm({ ...form, rent_amount: e.target.value })} className="mt-1" /></div>
              <div><Label>Rent unit</Label><Select value={form.rent_unit} onValueChange={(v) => setForm({ ...form, rent_unit: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['per_season', 'per_year', 'per_month'].map((u) => <SelectItem key={u} value={u}>{u.replace('_', '/')}</SelectItem>)}</SelectContent></Select></div>
            </div>
          </div>
          <pre className="text-xs bg-muted rounded-lg p-3 whitespace-pre-wrap font-mono max-h-48 overflow-y-auto">{FAIR_TEMPLATE.replace('{landlord}', form.landlord_name || '[Landlord]').replace('{tenant}', form.tenant_name || '[Tenant]').replace('{area}', form.land_area || '[Area]').replace('{unit}', form.area_unit).replace('{start}', form.start_date || '[Start]').replace('{end}', form.end_date || '[End]').replace('{rent}', form.rent_amount || '[Amount]').replace('{rent_unit}', form.rent_unit.replace('_', ' '))}</pre>
          <Button onClick={generateTemplate} className="gap-2 w-full">{copied ? <><Check className="w-4 h-4" /> Copied!</> : <><Copy className="w-4 h-4" /> Copy template</>}</Button>
        </DialogContent>
      </Dialog>

      {loading ? <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        : data.length === 0 ? <Widget className="p-10 text-center text-muted-foreground"><FileText className="w-10 h-10 mx-auto mb-3 opacity-40" /><p className="text-sm">No contracts yet. Create one or generate a fair template.</p></Widget>
        : <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">{data.map((c) => (
          <Widget key={c.id} className="p-4 group">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-10 h-10 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0"><FileText className="w-5 h-5" /></span>
                <div className="min-w-0">
                  <p className="font-heading font-semibold truncate">{c.title}</p>
                  <p className="text-xs text-muted-foreground truncate">{c.tenant_name} ↔ {c.landlord_name || '—'}</p>
                </div>
              </div>
              <button onClick={() => remove(c.id)} className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive shrink-0"><Trash2 className="w-4 h-4" /></button>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <Select value={c.status} onValueChange={(v) => setStatus(c.id, v)}>
                <SelectTrigger className="h-7 w-auto text-xs"><SelectValue /></SelectTrigger>
                <SelectContent>{['draft', 'active', 'completed', 'disputed'].map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
              {c.land_area && <Badge variant="outline">{c.land_area} {c.area_unit}</Badge>}
              {c.rent_amount && <Badge variant="outline">PKR {c.rent_amount?.toLocaleString()} {c.rent_unit?.replace('_', '/')}</Badge>}
            </div>
            {(c.start_date || c.end_date) && <p className="text-xs text-muted-foreground mt-2">{c.start_date} → {c.end_date}</p>}
            {c.terms && <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{c.terms}</p>}
          </Widget>
        ))}</div>}
    </div>
  );
}