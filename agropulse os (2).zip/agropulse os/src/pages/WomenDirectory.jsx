import { useState } from 'react';
import { Users, Plus, Trash2, Loader2, MapPin, Phone, BadgeCheck, HeartHandshake } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCollection } from '@/hooks/useCollection';

const CATEGORIES = [
  { key: 'farming', label: 'Farming' }, { key: 'processing', label: 'Processing' }, { key: 'dairy', label: 'Dairy' },
  { key: 'handicraft', label: 'Handicraft' }, { key: 'services', label: 'Services' }, { key: 'other', label: 'Other' },
];
const GRANT_STYLES = {
  none: 'bg-muted text-muted-foreground', applied: 'bg-amber-500/10 text-amber-600',
  approved: 'bg-emerald-500/10 text-emerald-700', rejected: 'bg-destructive/10 text-destructive',
};

export default function WomenDirectory() {
  const { data, loading, reload } = useCollection('Entrepreneur', { sort: '-created_date', limit: 100 });
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: '', business_name: '', category: 'farming', location_text: '', description: '', contact: '', badge_verified: false, micro_grant_status: 'none' });

  async function save() {
    setSaving(true);
    try {
      await base44.entities.Entrepreneur.create({ ...form });
      setForm({ name: '', business_name: '', category: 'farming', location_text: '', description: '', contact: '', badge_verified: false, micro_grant_status: 'none' });
      setOpen(false); reload();
    } finally { setSaving(false); }
  }
  async function remove(id) { await base44.entities.Entrepreneur.delete(id); reload(); }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">Women Entrepreneurs</h1>
          <p className="text-sm text-muted-foreground mt-1">A directory of women-led agro-businesses with vendor badges and micro-grant support.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="gap-2"><Plus className="w-4 h-4" /> Add profile</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Add entrepreneur profile</DialogTitle></DialogHeader>
            <div className="grid gap-3 py-2">
              <div><Label>Name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="mt-1" /></div>
              <div><Label>Business name *</Label><Input value={form.business_name} onChange={(e) => setForm({ ...form, business_name: e.target.value })} className="mt-1" /></div>
              <div><Label>Category</Label><Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{CATEGORIES.map((c) => <SelectItem key={c.key} value={c.key}>{c.label}</SelectItem>)}</SelectContent></Select></div>
              <div><Label>Location</Label><Input value={form.location_text} onChange={(e) => setForm({ ...form, location_text: e.target.value })} className="mt-1" /></div>
              <div><Label>Contact</Label><Input value={form.contact} onChange={(e) => setForm({ ...form, contact: e.target.value })} className="mt-1" /></div>
              <div><Label>Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="mt-1" rows={2} /></div>
              <div><Label>Micro-grant status</Label><Select value={form.micro_grant_status} onValueChange={(v) => setForm({ ...form, micro_grant_status: v })}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{['none', 'applied', 'approved', 'rejected'].map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></div>
              <label className="flex items-center gap-2 text-sm"><input type="checkbox" checked={form.badge_verified} onChange={(e) => setForm({ ...form, badge_verified: e.target.checked })} /> Verified vendor badge</label>
            </div>
            <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save} disabled={saving} className="gap-2">{saving && <Loader2 className="w-4 h-4 animate-spin" />} Save</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
        : data.length === 0 ? <Widget className="p-10 text-center text-muted-foreground"><Users className="w-10 h-10 mx-auto mb-3 opacity-40" /><p className="text-sm">No profiles yet. Add the first woman-led business to the directory.</p></Widget>
        : <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">{data.map((e) => (
          <Widget key={e.id} className="p-4 group">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-10 h-10 rounded-xl bg-pink-500/10 text-pink-600 flex items-center justify-center shrink-0"><HeartHandshake className="w-5 h-5" /></span>
                <div className="min-w-0">
                  <p className="font-heading font-semibold truncate">{e.business_name}</p>
                  <p className="text-xs text-muted-foreground truncate">{e.name} · {CATEGORIES.find((c) => c.key === e.category)?.label || e.category}</p>
                </div>
              </div>
              <button onClick={() => remove(e.id)} className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 rounded-lg hover:bg-destructive/10 text-muted-foreground hover:text-destructive shrink-0"><Trash2 className="w-4 h-4" /></button>
            </div>
            <div className="mt-3 flex flex-wrap items-center gap-2">
              {e.badge_verified && <Badge variant="secondary" className="gap-1 bg-emerald-500/10 text-emerald-700"><BadgeCheck className="w-3 h-3" /> Verified</Badge>}
              {e.micro_grant_status !== 'none' && <Badge variant="secondary" className={GRANT_STYLES[e.micro_grant_status]}>Grant: {e.micro_grant_status}</Badge>}
            </div>
            {e.description && <p className="text-xs text-muted-foreground mt-2 line-clamp-2">{e.description}</p>}
            <div className="mt-2 flex flex-wrap gap-3 text-xs text-muted-foreground">
              {e.location_text && <span className="flex items-center gap-1"><MapPin className="w-3 h-3" /> {e.location_text}</span>}
              {e.contact && <span className="flex items-center gap-1"><Phone className="w-3 h-3" /> {e.contact}</span>}
            </div>
          </Widget>
        ))}</div>}
    </div>
  );
}