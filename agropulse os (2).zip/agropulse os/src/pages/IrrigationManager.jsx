import { useState } from 'react';
import { Droplets, Calculator, Calendar, CloudSun } from 'lucide-react';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const CROPS = {
  wheat: { label: 'Wheat', kc: { land_prep: 0.4, sown: 0.4, germination: 0.4, tillering: 0.7, vegetative: 1.15, flowering: 1.15, grain_filling: 1.0, mature: 0.4, harvested: 0.3 }, season: 'Rabi (winter)' },
  rice: { label: 'Rice', kc: { land_prep: 1.1, sown: 1.1, germination: 1.1, tillering: 1.2, vegetative: 1.2, flowering: 1.2, grain_filling: 1.1, mature: 0.6, harvested: 0.3 }, season: 'Kharif (summer)' },
  cotton: { label: 'Cotton', kc: { land_prep: 0.4, sown: 0.4, germination: 0.4, tillering: 0.6, vegetative: 1.0, flowering: 1.15, grain_filling: 1.0, mature: 0.7, harvested: 0.4 }, season: 'Kharif (summer)' },
  maize: { label: 'Maize', kc: { land_prep: 0.3, sown: 0.3, germination: 0.3, tillering: 0.5, vegetative: 1.0, flowering: 1.2, grain_filling: 0.9, mature: 0.5, harvested: 0.3 }, season: 'Both' },
  sugarcane: { label: 'Sugarcane', kc: { land_prep: 0.4, sown: 0.4, germination: 0.5, tillering: 0.8, vegetative: 1.2, flowering: 1.25, grain_filling: 1.2, mature: 0.6, harvested: 0.5 }, season: 'Year-round' },
  vegetables: { label: 'Vegetables', kc: { land_prep: 0.3, sown: 0.3, germination: 0.3, tillering: 0.5, vegetative: 0.8, flowering: 1.0, grain_filling: 0.9, mature: 0.7, harvested: 0.5 }, season: 'Both' },
};

const STAGES = [
  { key: 'land_prep', label: 'Land Prep' }, { key: 'sown', label: 'Sown' }, { key: 'germination', label: 'Germination' },
  { key: 'tillering', label: 'Tillering' }, { key: 'vegetative', label: 'Vegetative' }, { key: 'flowering', label: 'Flowering' },
  { key: 'grain_filling', label: 'Grain Filling' }, { key: 'mature', label: 'Mature' }, { key: 'harvested', label: 'Harvested' },
];

export default function IrrigationManager() {
  const [crop, setCrop] = useState('wheat');
  const [stage, setStage] = useState('vegetative');
  const [area, setArea] = useState('');
  const [season, setSeason] = useState('summer');

  const cropData = CROPS[crop];
  const kc = cropData.kc[stage] || 0.5;
  const eto = season === 'summer' ? 5.0 : 3.0; // mm/day reference ET
  const etc = eto * kc; // crop evapotranspiration mm/day
  const areaNum = parseFloat(area) || 0;
  const dailyWaterM3 = (etc * areaNum * 10).toFixed(1); // mm × ha × 10 = m³
  const weeklyWaterM3 = (etc * areaNum * 10 * 7).toFixed(0);
  const dailyWaterLiters = (etc * areaNum * 10000).toFixed(0);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">Irrigation Manager</h1>
        <p className="text-sm text-muted-foreground mt-1">Crop-water requirement calculators using weather data to prevent groundwater depletion and chemical runoff.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Widget>
          <WidgetHeader title="Calculator" icon={Calculator} />
          <WidgetBody className="space-y-4">
            <div><Label>Crop</Label><Select value={crop} onValueChange={setCrop}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{Object.entries(CROPS).map(([k, c]) => <SelectItem key={k} value={k}>{c.label}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Growth stage</Label><Select value={stage} onValueChange={setStage}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{STAGES.map((s) => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Area (hectares)</Label><Input type="number" value={area} onChange={(e) => setArea(e.target.value)} className="mt-1" placeholder="5" /></div>
            <div><Label>Season</Label><Select value={season} onValueChange={setSeason}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent><SelectItem value="summer">Summer (Kharif)</SelectItem><SelectItem value="winter">Winter (Rabi)</SelectItem></SelectContent></Select></div>
          </WidgetBody>
        </Widget>

        <Widget>
          <WidgetHeader title="Water Requirement" icon={Droplets} />
          <WidgetBody className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-lg bg-sky-500/5 border border-sky-500/20 p-3">
                <p className="text-xs text-muted-foreground">Daily need</p>
                <p className="font-heading text-xl font-bold mt-0.5">{areaNum > 0 ? dailyWaterM3 : '—'} <span className="text-xs font-normal">m³/day</span></p>
                <p className="text-[11px] text-muted-foreground mt-0.5">{areaNum > 0 ? `${dailyWaterLiters} L/day` : ''}</p>
              </div>
              <div className="rounded-lg bg-sky-500/5 border border-sky-500/20 p-3">
                <p className="text-xs text-muted-foreground">Weekly need</p>
                <p className="font-heading text-xl font-bold mt-0.5">{areaNum > 0 ? weeklyWaterM3 : '—'} <span className="text-xs font-normal">m³/week</span></p>
              </div>
            </div>
            <div className="rounded-lg border border-border p-3 space-y-1.5">
              <div className="flex justify-between text-xs"><span className="text-muted-foreground">Crop coefficient (Kc)</span><span className="font-medium">{kc.toFixed(2)}</span></div>
              <div className="flex justify-between text-xs"><span className="text-muted-foreground">Reference ET (ETo)</span><span className="font-medium">{eto} mm/day</span></div>
              <div className="flex justify-between text-xs"><span className="text-muted-foreground">Crop ET (ETc)</span><span className="font-medium">{etc.toFixed(1)} mm/day</span></div>
            </div>
            <div className="rounded-lg bg-primary/5 p-3">
              <p className="text-xs font-medium flex items-center gap-1.5"><Calendar className="w-3.5 h-3.5 text-primary" /> Irrigation Schedule</p>
              <p className="text-xs text-muted-foreground mt-1">{etc > 4 ? 'Water daily or every 2 days. Peak demand stage.' : etc > 2 ? 'Water every 3-4 days. Moderate demand.' : 'Water weekly. Low demand stage.'}</p>
            </div>
          </WidgetBody>
        </Widget>
      </div>

      <Widget>
        <WidgetHeader title="Runoff Prevention Tips" icon={CloudSun} />
        <WidgetBody>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { t: 'Water early morning', d: 'Irrigate before 8 AM to reduce evaporation losses by up to 30%.' },
              { t: 'Use drip irrigation', d: 'Delivers water directly to roots, saving 40-60% vs flood irrigation.' },
              { t: 'Mulch the soil', d: 'Organic mulch reduces evaporation and prevents fertilizer runoff.' },
              { t: 'Split fertilizer doses', d: 'Apply fertilizer in 2-3 splits to match crop uptake and reduce leaching.' },
              { t: 'Monitor soil moisture', d: 'Check soil moisture before watering. Over-irrigation causes nutrient runoff.' },
              { t: 'Contour farming', d: 'Plant along contours on slopes to slow runoff and improve water infiltration.' },
            ].map((tip) => (
              <div key={tip.t} className="rounded-lg border border-border p-3">
                <p className="text-sm font-medium">{tip.t}</p>
                <p className="text-xs text-muted-foreground mt-1">{tip.d}</p>
              </div>
            ))}
          </div>
        </WidgetBody>
      </Widget>
    </div>
  );
}