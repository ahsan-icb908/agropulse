import React, { useState } from 'react';
import { Download, FileText } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { DOCS_META, DOCS_BLOCKS } from '@/components/docs/docsContent';
import { buildDocsPdf } from '@/lib/docs/buildDocsPdf';

export default function Documentation() {
  const [busy, setBusy] = useState(false);

  const download = () => {
    setBusy(true);
    try {
      buildDocsPdf();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="mx-auto max-w-3xl space-y-6 pb-10">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <FileText className="h-4 w-4" aria-hidden="true" />
            Documentation
          </div>
          <h1 className="mt-1 font-heading text-2xl font-semibold tracking-tight">
            {DOCS_META.title}
          </h1>
          <p className="text-sm text-muted-foreground">
            {DOCS_META.subtitle} · Version {DOCS_META.version}
          </p>
        </div>
        <Button onClick={download} disabled={busy}>
          <Download className="mr-2 h-4 w-4" aria-hidden="true" />
          {busy ? 'Preparing…' : 'Download PDF'}
        </Button>
      </header>

      <article className="space-y-4 rounded-xl border border-border bg-card p-5 text-sm leading-relaxed text-foreground sm:p-7">
        {DOCS_BLOCKS.map((block, index) => {
          if (block.type === 'section') {
            return (
              <h2
                key={index}
                className="pt-2 font-heading text-base font-semibold tracking-tight first:pt-0"
              >
                {block.text}
              </h2>
            );
          }
          if (block.type === 'sub') {
            return (
              <h3 key={index} className="pt-1 font-medium text-foreground">
                {block.text}
              </h3>
            );
          }
          if (block.type === 'para') {
            return <p key={index}>{block.text}</p>;
          }
          if (block.type === 'note') {
            return (
              <aside
                key={index}
                className="rounded-lg border border-border bg-muted/50 p-3 text-xs italic text-muted-foreground"
              >
                {block.text}
              </aside>
            );
          }
          return (
            <ul key={index} className="list-disc space-y-1.5 pl-5 marker:text-muted-foreground">
              {block.items.map((item, i) => (
                <li key={i}>{item}</li>
              ))}
            </ul>
          );
        })}
      </article>
    </div>
  );
}