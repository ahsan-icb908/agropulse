import { useMemo, useState } from 'react';
import { Search, Youtube } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useI18n } from '@/i18n/LanguageContext';
import VideoCard from '@/components/agrovids/VideoCard';
import VideoPlayerDialog from '@/components/agrovids/VideoPlayerDialog';
import { AGRO_VIDEOS, VIDEO_CATEGORIES } from '@/components/agrovids/videos';

const PAGE_SIZE = 24;

export default function AgroVids() {
  const { t } = useI18n();
  const [category, setCategory] = useState('all');
  const [query, setQuery] = useState('');
  const [visible, setVisible] = useState(PAGE_SIZE);
  const [playing, setPlaying] = useState(null);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    return AGRO_VIDEOS.filter(
      (v) =>
        (category === 'all' || v.category === category) &&
        (!q || v.title.toLowerCase().includes(q))
    );
  }, [category, query]);

  const shown = filtered.slice(0, visible);

  const selectCategory = (value) => {
    setCategory(value);
    setVisible(PAGE_SIZE);
  };

  return (
    <div className="space-y-5">
      <header className="flex items-start gap-3">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
          <Youtube className="h-6 w-6" />
        </span>
        <div className="min-w-0">
          <h1 className="font-heading text-2xl font-bold tracking-tight">{t('videos.title')}</h1>
          <p className="text-sm text-muted-foreground">{t('videos.subtitle')}</p>
        </div>
      </header>

      <div className="relative max-w-md">
        <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setVisible(PAGE_SIZE);
          }}
          placeholder={t('videos.search')}
          className="pl-9"
        />
      </div>

      <Tabs value={category} onValueChange={selectCategory}>
        <TabsList className="flex h-auto w-full flex-wrap justify-start gap-1">
          {VIDEO_CATEGORIES.map((c) => (
            <TabsTrigger key={c.key} value={c.key} className="text-xs sm:text-sm">
              {t(c.labelKey)}
            </TabsTrigger>
          ))}
        </TabsList>
      </Tabs>

      {shown.length > 0 ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {shown.map((video) => (
            <VideoCard key={video.id} video={video} onPlay={setPlaying} />
          ))}
        </div>
      ) : (
        <p className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">
          {t('videos.empty')}
        </p>
      )}

      {filtered.length > 0 && (
        <div className="flex flex-col items-center gap-3 pt-1">
          <p className="text-xs text-muted-foreground">
            {shown.length} / {filtered.length} {t('videos.count')}
          </p>
          {shown.length < filtered.length && (
            <Button variant="outline" onClick={() => setVisible((n) => n + PAGE_SIZE)}>
              {t('videos.loadMore')}
            </Button>
          )}
        </div>
      )}

      <VideoPlayerDialog video={playing} onClose={() => setPlaying(null)} />
    </div>
  );
}