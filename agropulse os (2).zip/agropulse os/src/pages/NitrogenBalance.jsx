import { useState } from 'react';
import { Waves, Calculator, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const FERTILIZERS = {
  urea: { label: 'Urea', nPct: 0.46 },
  dap: { label: 'DAP (18-46-0)', nPct: 0.18 },
  can: { label: 'CAN', nPct: 0.26 },
  npk: { label: 'NPK 15-15-15', nPct: 0.15 },
};
const CROPS = {
  wheat: { label: 'Wheat', uptake: 120 },
  rice: { label: 'Rice', uptake: 150 },
  cotton: { label: 'Cotton', uptake: 180 },
  maize: { label: 'Maize', uptake: 170 },
  sugarcane: { label: 'Sugarcane', uptake: 200 },
  vegetables: { label: 'Vegetables', uptake: 100 },
};

export default function NitrogenBalance() {
  const [fertilizer, setFertilizer] = useState('urea');
  const [amount, setAmount] = useState('');
  const [crop, setCrop] = useState('wheat');
  const [area, setArea] = useState('');

  const fert = FERTILIZERS[fertilizer];
  const cropData = CROPS[crop];
  const amountNum = parseFloat(amount) || 0;
  const areaNum = parseFloat(area) || 0;

  const nAppliedPerHa = amountNum * fert.nPct; // kg N/ha from one application
  const totalNApplied = nAppliedPerHa * areaNum; // total kg N
  const cropUptake = cropData.uptake; // kg N/ha needed by crop
  const balance = nAppliedPerHa - cropUptake; // surplus/deficit per ha
  const totalBalance = balance * areaNum;

  let riskLevel, riskColor, riskAdvice;
  if (balance > 50) { riskLevel = 'High leaching risk'; riskColor = 'bg-destructive/10 text-destructive'; riskAdvice = 'Excess nitrogen will leach into groundwater and nearby waterways. Reduce application or split into 3+ doses.'; }
  else if (balance > 20) { riskLevel = 'Moderate risk'; riskColor = 'bg-amber-500/10 text-amber-600'; riskAdvice = 'Some surplus nitrogen. Consider splitting into 2 applications to match crop uptake better.'; }
  else if (balance > -20) { riskLevel = 'Balanced'; riskColor = 'bg-emerald-500/10 text-emerald-700'; riskAdvice = 'Nitrogen application closely matches crop demand. Good management.'; }
  else { riskLevel = 'Deficit'; riskColor = 'bg-sky-500/10 text-sky-600'; riskAdvice = 'Crop needs more nitrogen than applied. Consider increasing the dose or adding organic matter.'; }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">Nitrogen Balance</h1>
        <p className="text-sm text-muted-foreground mt-1">Soil-nitrogen balance tools to stop fertilizer leaching into local waterways and aquatic ecosystems.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <Widget>
          <WidgetHeader title="Calculator" icon={Calculator} />
          <WidgetBody className="space-y-4">
            <div><Label>Fertilizer</Label><Select value={fertilizer} onValueChange={setFertilizer}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{Object.entries(FERTILIZERS).map(([k, f]) => <SelectItem key={k} value={k}>{f.label}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Amount applied (kg/ha)</Label><Input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} className="mt-1" placeholder="100" /></div>
            <div><Label>Crop</Label><Select value={crop} onValueChange={setCrop}><SelectTrigger className="mt-1"><SelectValue /></SelectTrigger><SelectContent>{Object.entries(CROPS).map(([k, c]) => <SelectItem key={k} value={k}>{c.label}</SelectItem>)}</SelectContent></Select></div>
            <div><Label>Area (hectares)</Label><Input type="number" value={area} onChange={(e) => setArea(e.target.value)} className="mt-1" placeholder="5" /></div>
          </WidgetBody>
        </Widget>

        <Widget>
          <WidgetHeader title="Nitrogen Balance" icon={Waves} />
          <WidgetBody className="space-y-4">
            {amountNum > 0 ? (
              <>
                <div className={`rounded-lg p-3 ${riskColor}`}>
                  <p className="text-sm font-semibold flex items-center gap-1.5">
                    {balance > 50 ? <AlertTriangle className="w-4 h-4" /> : <CheckCircle2 className="w-4 h-4" />}
                    {riskLevel}
                  </p>
                  <p className="text-xs mt-1.5 leading-relaxed opacity-80">{riskAdvice}</p>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">N applied</p><p className="font-heading text-lg font-bold mt-0.5">{nAppliedPerHa.toFixed(1)} <span className="text-xs font-normal">kg/ha</span></p></div>
                  <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Crop need</p><p className="font-heading text-lg font-bold mt-0.5">{cropUptake} <span className="text-xs font-normal">kg/ha</span></p></div>
                  <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Balance</p><p className={`font-heading text-lg font-bold mt-0.5 ${balance > 50 ? 'text-destructive' : balance > 0 ? 'text-amber-600' : 'text-sky-600'}`}>{balance > 0 ? '+' : ''}{balance.toFixed(1)}</p></div>
                  {areaNum > 0 && <div className="rounded-lg border border-border p-3"><p className="text-xs text-muted-foreground">Total N</p><p className="font-heading text-lg font-bold mt-0.5">{totalNApplied.toFixed(0)} <span className="text-xs font-normal">kg</span></p></div>}
                </div>
              </>
            ) : (
              <p className="text-sm text-muted-foreground py-8 text-center">Enter the amount applied to calculate the nitrogen balance.</p>
            )}
          </WidgetBody>
        </Widget>
      </div>

      <Widget>
        <WidgetHeader title="Preventing Fertilizer Leaching" />
        <WidgetBody>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {[
              { t: 'Split applications', d: 'Apply nitrogen in 3-4 doses across the season rather than all at once. Crop uptake is gradual.' },
              { t: 'Use slow-release urea', d: 'Coated urea releases nitrogen over 40-60 days, matching crop demand and reducing leaching by 30%.' },
              { t: 'Incorporate into soil', d: 'Mix fertilizer into the top 5cm of soil instead of surface broadcasting. Reduces volatilization and runoff.' },
              { t: 'Add organic matter', d: 'Compost and manure improve soil structure and nutrient retention capacity.' },
              { t: 'Plant cover crops', d: 'Legumes (clover, vetch) fix atmospheric nitrogen and reduce the need for synthetic fertilizer.' },
              { t: 'Buffer zones', d: 'Maintain 10m vegetated buffer strips along waterways to intercept runoff.' },
            ].map((tip) => (
              <div key={tip.t} className="rounded-lg border border-border p-3">
                <p className="text-sm font-medium">{tip.t}</p>
                <p className="text-xs text-muted-foreground mt-1">{tip.d}</p>
              </div>
            ))}
          </div>
        </WidgetBody>
      </Widget>
    </div>
  );
}