import { Link } from 'react-router-dom';
import { HandCoins, ArrowRight, Store, Loader2, Trash2, MapPin } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useCollection } from '@/hooks/useCollection';
import MandiEstimator from '@/components/mandi/MandiEstimator';

export default function MandiConnect() {
  const { data, loading, reload } = useCollection('Listing', { sort: '-created_date', limit: 100 });
  const mine = data.filter((listing) => listing.listed_via === 'mandi_connect');

  async function remove(id) {
    await base44.entities.Listing.delete(id);
    reload();
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-medium uppercase tracking-wide text-muted-foreground">
            <HandCoins className="h-4 w-4" aria-hidden="true" />
            Live Mandi Connect · SDG 8 &amp; 10
          </div>
          <h1 className="mt-1 font-heading text-2xl font-bold tracking-tight">Sell direct, price fairly</h1>
          <p className="mt-1 max-w-2xl text-sm text-muted-foreground">
            Check a Pakistan-wide benchmark and your chosen mandi side by side, add a fair profit margin, then publish
            straight to buyers with no middleman.
          </p>
        </div>
        <Button asChild variant="outline" className="gap-2">
          <Link to="/programs/marketplace">
            Marketplace
            <ArrowRight className="h-4 w-4" />
          </Link>
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-5">
        <Widget className="xl:col-span-3">
          <WidgetHeader
            title="Fair price estimator"
            subtitle="Estimates only — not a verified live mandi feed"
            icon={HandCoins}
          />
          <WidgetBody>
            <MandiEstimator onPublished={reload} />
          </WidgetBody>
        </Widget>

        <Widget className="xl:col-span-2">
          <WidgetHeader title="Your Mandi Connect listings" subtitle={`${mine.length} published`} icon={Store} />
          <WidgetBody className="space-y-2">
            {loading ? (
              <div className="flex justify-center py-6"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
            ) : mine.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                Nothing published yet. Get a fair price estimate, then publish your first listing.
              </p>
            ) : (
              mine.map((listing) => (
                <div key={listing.id} className="rounded-lg border border-border/70 p-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold">{listing.crop}</p>
                      <p className="text-xs text-muted-foreground">
                        {listing.quantity} {listing.quantity_unit} · PKR {listing.price?.toLocaleString()}/kg
                      </p>
                    </div>
                    <button
                      onClick={() => remove(listing.id)}
                      aria-label="Delete listing"
                      className="rounded-lg p-1.5 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                  <div className="mt-2 flex flex-wrap items-center gap-1.5">
                    <Badge variant="secondary" className="text-[11px]">{listing.status}</Badge>
                    {listing.mandi && (
                      <Badge variant="outline" className="gap-1 text-[11px]">
                        <MapPin className="h-3 w-3" /> {listing.mandi}
                      </Badge>
                    )}
                    {listing.estimate_fair_margin ? (
                      <Badge variant="outline" className="text-[11px]">margin {listing.estimate_fair_margin}%</Badge>
                    ) : null}
                  </div>
                </div>
              ))
            )}
          </WidgetBody>
        </Widget>
      </div>
    </div>
  );
}