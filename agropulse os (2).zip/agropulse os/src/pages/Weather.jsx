import { useState } from 'react';
import { CloudSun, Droplets, Wind, CloudRain, Loader2, AlertTriangle, Search, Thermometer } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useCollection } from '@/hooks/useCollection';
import { cn } from '@/lib/utils';

const SEV_STYLE = {
  extreme: 'bg-red-500/15 text-red-600 border-red-500/30',
  severe: 'bg-orange-500/15 text-orange-600 border-orange-500/30',
  moderate: 'bg-amber-500/15 text-amber-600 border-amber-500/30',
  minor: 'bg-sky-500/15 text-sky-600 border-sky-500/30',
};

export default function Weather() {
  const { t } = useI18n();
  const [location, setLocation] = useState('Faisalabad, Pakistan');
  const [weather, setWeather] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { data: alerts } = useCollection('Alert', { query: { status: 'active' }, sort: '-created_date', limit: 50 });

  async function fetchWeather(loc) {
    const q = loc || location;
    if (!q) return;
    setLoading(true);
    setError('');
    setWeather(null);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Provide the current weather and a brief 3-day outlook for "${q}". Return ONLY JSON: { "location": string, "temperature_c": number, "condition": string, "humidity_percent": number, "wind_kmh": number, "rainfall_mm": number, "forecast": [{"day": string, "hi_c": number, "lo_c": number, "condition": string}], "source_note": string }. Use real current data from web search.`,
        add_context_from_internet: true,
        model: 'gemini_3_flash',
        response_json_schema: {
          type: 'object',
          properties: {
            location: { type: 'string' },
            temperature_c: { type: 'number' },
            condition: { type: 'string' },
            humidity_percent: { type: 'number' },
            wind_kmh: { type: 'number' },
            rainfall_mm: { type: 'number' },
            forecast: { type: 'array', items: { type: 'object', properties: { day: { type: 'string' }, hi_c: { type: 'number' }, lo_c: { type: 'number' }, condition: { type: 'string' } } } },
            source_note: { type: 'string' },
          },
        },
      });
      setWeather(typeof res === 'string' ? safeParse(res) : res);
    } catch (e) {
      setError(e?.message || 'Could not fetch weather.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">{t('nav.weather')}</h1>
        <p className="text-sm text-muted-foreground mt-1">Live weather (web-sourced) and active hazard alerts for your area.</p>
      </div>

      <div className="flex gap-2 max-w-md">
        <Input value={location} onChange={(e) => setLocation(e.target.value)} placeholder="City or area" onKeyDown={(e) => e.key === 'Enter' && fetchWeather()} />
        <Button onClick={() => fetchWeather()} disabled={loading} className="gap-2">
          {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Search className="w-4 h-4" />} Get
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        <Widget className="lg:col-span-2">
          <WidgetHeader title="Current conditions" subtitle={weather?.location || location} icon={CloudSun} />
          <WidgetBody>
            {loading && <div className="flex justify-center py-12"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>}
            {error && <p className="text-sm text-destructive py-8 text-center">{error}</p>}
            {!loading && !weather && !error && (
              <p className="text-sm text-muted-foreground py-12 text-center">Enter a location and tap Get.</p>
            )}
            {weather && (
              <div>
                <div className="flex items-center gap-5">
                  <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-sky-400/20 to-primary/10 flex items-center justify-center">
                    <Thermometer className="w-9 h-9 text-sky-500" />
                  </div>
                  <div>
                    <p className="text-5xl font-heading font-bold">{Math.round(weather.temperature_c)}°C</p>
                    <p className="text-sm text-muted-foreground">{weather.condition}</p>
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3 mt-5">
                  <Metric icon={Droplets} label="Humidity" value={`${weather.humidity_percent ?? '—'}%`} />
                  <Metric icon={Wind} label="Wind" value={`${weather.wind_kmh ?? '—'} km/h`} />
                  <Metric icon={CloudRain} label="Rain" value={`${weather.rainfall_mm ?? '—'} mm`} />
                </div>
                {weather.forecast?.length > 0 && (
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 mt-5 pt-4 border-t border-border">
                    {weather.forecast.map((f, i) => (
                      <div key={i} className="text-center rounded-lg bg-muted/40 py-2">
                        <p className="text-[10px] text-muted-foreground">{f.day}</p>
                        <CloudSun className="w-4 h-4 mx-auto my-1 text-sky-400" />
                        <p className="text-xs font-semibold">{f.hi_c}°</p>
                        <p className="text-[10px] text-muted-foreground">{f.lo_c}°</p>
                      </div>
                    ))}
                  </div>
                )}
                <p className="text-[11px] text-muted-foreground/70 mt-3">{weather.source_note || 'Web-sourced via AI — verify for critical decisions.'}</p>
              </div>
            )}
          </WidgetBody>
        </Widget>

        {/* Integrated alerts */}
        <Widget>
          <WidgetHeader title="Active hazard alerts" icon={AlertTriangle} />
          <WidgetBody className="space-y-3">
            {alerts.length === 0 ? (
              <p className="text-sm text-muted-foreground py-8 text-center">No active alerts.</p>
            ) : (
              alerts.map((a) => (
                <div key={a.id} className="rounded-xl border border-border p-3">
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-medium text-sm">{a.title}</p>
                    <Badge variant="outline" className={cn('text-[10px] capitalize', SEV_STYLE[a.severity])}>{t(`alert.severity.${a.severity}`)}</Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{a.category?.replace('_', ' ')} • {a.area || '—'}</p>
                  {a.source && <p className="text-[11px] text-muted-foreground/70 mt-1">Source: {a.source}</p>}
                </div>
              ))
            )}
          </WidgetBody>
        </Widget>
      </div>
    </div>
  );
}

function Metric({ icon: Icon, label, value }) {
  return (
    <div className="rounded-lg bg-muted/50 py-3 text-center">
      <Icon className="w-4 h-4 mx-auto text-muted-foreground" />
      <p className="mt-1 font-semibold text-sm">{value}</p>
      <p className="text-[11px] text-muted-foreground">{label}</p>
    </div>
  );
}

function safeParse(s) {
  try { return JSON.parse(s); } catch { return null; }
}