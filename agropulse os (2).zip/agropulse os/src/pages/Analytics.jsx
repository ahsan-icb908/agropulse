import { useEffect, useState } from 'react';
import { BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Loader2, BarChart3, TrendingUp, Scale } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';

const SEV_COLORS = { minor: '#0284c7', moderate: '#d97706', severe: '#ea580c', extreme: '#dc2626' };
const STATUS_COLORS = ['#16a34a', '#0284c7', '#d97706', '#ea580c', '#7c3aed', '#94a3b8'];
const YIELD_COLORS = ['#16a34a', '#0284c7', '#d97706', '#ea580c', '#7c3aed', '#84cc16', '#06b6d4', '#f97316'];

export default function Analytics() {
  const { t } = useI18n();
  const [alertsBySev, setAlertsBySev] = useState([]);
  const [reportsByStatus, setReportsByStatus] = useState([]);
  const [tasksByStatus, setTasksByStatus] = useState([]);
  const [yieldBySeason, setYieldBySeason] = useState([]);
  const [yieldByCrop, setYieldByCrop] = useState([]);
  const [totalYield, setTotalYield] = useState(0);
  const [totalArea, setTotalArea] = useState(0);
  const [harvestCount, setHarvestCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [a, r, tk, ys, yc] = await Promise.all([
          base44.entities.Alert.aggregate({ groupBy: 'severity' }).catch(() => ({ rows: [] })),
          base44.entities.CivicReport.aggregate({ groupBy: 'status' }).catch(() => ({ rows: [] })),
          base44.entities.Task.aggregate({ groupBy: 'status' }).catch(() => ({ rows: [] })),
          base44.entities.Harvest.aggregate({ groupBy: 'season', sum: ['yield_amount', 'area_hectares'], sort: 'season' }).catch(() => ({ rows: [] })),
          base44.entities.Harvest.aggregate({ groupBy: 'crop', sum: 'yield_amount', sort: '-sum_yield_amount' }).catch(() => ({ rows: [] })),
        ]);
        setAlertsBySev((a.rows || []).map((x) => ({ name: x.severity, value: x.count })));
        setReportsByStatus((r.rows || []).map((x) => ({ name: x.status, value: x.count })));
        setTasksByStatus((tk.rows || []).map((x) => ({ name: x.status, value: x.count })));
        const seasonRows = ys.rows || [];
        setYieldBySeason(seasonRows.map((x) => ({ name: x.season || 'Unknown', yield: x.sum_yield_amount || 0, area: x.sum_area_hectares || 0, count: x.count })));
        setYieldByCrop((yc.rows || []).map((x) => ({ name: x.crop || 'Unknown', value: x.sum_yield_amount || 0 })));
        setTotalYield(seasonRows.reduce((sum, x) => sum + (x.sum_yield_amount || 0), 0));
        setTotalArea(seasonRows.reduce((sum, x) => sum + (x.sum_area_hectares || 0), 0));
        setHarvestCount(seasonRows.reduce((sum, x) => sum + (x.count || 0), 0));
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const yieldPerHa = totalArea > 0 ? (totalYield / totalArea).toFixed(1) : '—';

  return (
    <div className="space-y-5">
      <div>
        <h1 className="font-heading text-2xl font-bold tracking-tight">{t('nav.analytics')}</h1>
        <p className="text-sm text-muted-foreground mt-1">Insights computed from your actual records.</p>
      </div>

      {loading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : (
        <>
          {/* Yield summary */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            <Widget className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground"><Scale className="w-4 h-4" /><span className="text-xs font-medium">Total yield</span></div>
              <p className="font-heading text-2xl font-bold mt-2">{totalYield.toLocaleString()} <span className="text-sm font-normal text-muted-foreground">kg</span></p>
            </Widget>
            <Widget className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground"><TrendingUp className="w-4 h-4" /><span className="text-xs font-medium">Yield / hectare</span></div>
              <p className="font-heading text-2xl font-bold mt-2">{yieldPerHa} <span className="text-sm font-normal text-muted-foreground">kg/ha</span></p>
            </Widget>
            <Widget className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground"><BarChart3 className="w-4 h-4" /><span className="text-xs font-medium">Harvests logged</span></div>
              <p className="font-heading text-2xl font-bold mt-2">{harvestCount}</p>
            </Widget>
            <Widget className="p-4">
              <div className="flex items-center gap-2 text-muted-foreground"><TrendingUp className="w-4 h-4" /><span className="text-xs font-medium">Area harvested</span></div>
              <p className="font-heading text-2xl font-bold mt-2">{totalArea.toLocaleString()} <span className="text-sm font-normal text-muted-foreground">ha</span></p>
            </Widget>
          </div>

          {/* Yield charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <Widget>
              <WidgetHeader title="Yield by season" icon={TrendingUp} />
              <WidgetBody>
                <ChartEmpty data={yieldBySeason} label="No harvest data yet. Log harvests from your fields to see yield trends." />
                {yieldBySeason.length > 0 && (
                  <ResponsiveContainer width="100%" height={240}>
                    <BarChart data={yieldBySeason}>
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                      <YAxis tick={{ fontSize: 11 }} />
                      <Tooltip formatter={(v) => `${v.toLocaleString()} kg`} />
                      <Bar dataKey="yield" fill="#16a34a" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </WidgetBody>
            </Widget>

            <Widget>
              <WidgetHeader title="Yield by crop" icon={BarChart3} />
              <WidgetBody>
                <ChartEmpty data={yieldByCrop} label="No harvest data yet. Log harvests from your fields to see yield by crop." />
                {yieldByCrop.length > 0 && (
                  <ResponsiveContainer width="100%" height={240}>
                    <PieChart>
                      <Pie data={yieldByCrop} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={{ fontSize: 11 }}>
                        {yieldByCrop.map((_, i) => <Cell key={i} fill={YIELD_COLORS[i % YIELD_COLORS.length]} />)}
                      </Pie>
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                      <Tooltip formatter={(v) => `${v.toLocaleString()} kg`} />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </WidgetBody>
            </Widget>
          </div>

          {/* Existing analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <Widget>
              <WidgetHeader title="Alerts by severity" icon={BarChart3} />
              <WidgetBody>
                <ChartEmpty data={alertsBySev} />
                {alertsBySev.length > 0 && (
                  <ResponsiveContainer width="100%" height={240}>
                    <BarChart data={alertsBySev}>
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="value" radius={[6, 6, 0, 0]}>
                        {alertsBySev.map((e, i) => <Cell key={i} fill={SEV_COLORS[e.name] || '#16a34a'} />)}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </WidgetBody>
            </Widget>

            <Widget>
              <WidgetHeader title="Civic reports by status" icon={BarChart3} />
              <WidgetBody>
                <ChartEmpty data={reportsByStatus} />
                {reportsByStatus.length > 0 && (
                  <ResponsiveContainer width="100%" height={240}>
                    <PieChart>
                      <Pie data={reportsByStatus} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={80} label={{ fontSize: 11 }}>
                        {reportsByStatus.map((_, i) => <Cell key={i} fill={STATUS_COLORS[i % STATUS_COLORS.length]} />)}
                      </Pie>
                      <Legend wrapperStyle={{ fontSize: 11 }} />
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                )}
              </WidgetBody>
            </Widget>

            <Widget>
              <WidgetHeader title="Tasks by status" icon={BarChart3} />
              <WidgetBody>
                <ChartEmpty data={tasksByStatus} />
                {tasksByStatus.length > 0 && (
                  <ResponsiveContainer width="100%" height={240}>
                    <BarChart data={tasksByStatus}>
                      <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                      <YAxis allowDecimals={false} tick={{ fontSize: 11 }} />
                      <Tooltip />
                      <Bar dataKey="value" fill="#16a34a" radius={[6, 6, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                )}
              </WidgetBody>
            </Widget>
          </div>
        </>
      )}
    </div>
  );
}

function ChartEmpty({ data, label }) {
  if (data.length > 0) return null;
  return <p className="text-sm text-muted-foreground py-16 text-center">{label || 'No data yet.'}</p>;
}