import { useState } from 'react';
import { Users, Plus, MapPin, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from '@/components/ui/dialog';
import { useCollection } from '@/hooks/useCollection';
import { cn } from '@/lib/utils';

const CATEGORIES = [
  { value: 'water_leakage', label: 'Water leakage' },
  { value: 'drainage_sewage', label: 'Drainage / sewage' },
  { value: 'flooded_roads', label: 'Flooded roads' },
  { value: 'waste', label: 'Waste accumulation' },
  { value: 'infrastructure', label: 'Damaged infrastructure' },
  { value: 'unsafe_environment', label: 'Unsafe environment' },
  { value: 'pollution', label: 'Pollution' },
  { value: 'agri_water_access', label: 'Agricultural water access' },
  { value: 'sanitation', label: 'Sanitation' },
  { value: 'other', label: 'Other' },
];

const URGENCY = ['low', 'medium', 'high', 'critical'];
const STATUS_TONE = {
  submitted: 'bg-sky-500/15 text-sky-600',
  under_review: 'bg-amber-500/15 text-amber-600',
  assigned: 'bg-violet-500/15 text-violet-600',
  in_progress: 'bg-orange-500/15 text-orange-600',
  resolved: 'bg-success/15 text-success',
  rejected: 'bg-muted text-muted-foreground',
  duplicate: 'bg-muted text-muted-foreground',
};

export default function Community() {
  const { t } = useI18n();
  const { data: reports, loading, reload } = useCollection('CivicReport', { sort: '-created_date', limit: 100 });
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState('');
  const [form, setForm] = useState({ title: '', category: 'water_leakage', description: '', location_text: '', lat: '', lng: '', urgency: 'medium' });
  const [photo, setPhoto] = useState(null);

  async function submit() {
    if (!form.title || !form.category) return setErr('Title and category are required.');
    setSaving(true);
    setErr('');
    try {
      let image_uri;
      if (photo) {
        const up = await base44.integrations.Core.UploadPrivateFile({ file: photo });
        image_uri = up.file_uri;
      }
      const ref = 'CR-' + Math.random().toString(36).slice(2, 7).toUpperCase();
      await base44.entities.CivicReport.create({
        reference_number: ref,
        title: form.title,
        category: form.category,
        description: form.description,
        location_text: form.location_text,
        lat: form.lat ? Number(form.lat) : undefined,
        lng: form.lng ? Number(form.lng) : undefined,
        urgency: form.urgency,
        image_uri,
        status: 'submitted',
        is_public: true,
        status_history: [{ status: 'submitted', at: new Date().toISOString() }],
      });
      setForm({ title: '', category: 'water_leakage', description: '', location_text: '', lat: '', lng: '', urgency: 'medium' });
      setPhoto(null);
      setOpen(false);
      reload();
    } catch (e) {
      setErr(e?.message || 'Could not submit report.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight">{t('nav.community')}</h1>
          <p className="text-sm text-muted-foreground mt-1">Report and track community issues. Integrated with the map and activity feed.</p>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button className="gap-2"><Plus className="w-4 h-4" /> {t('common.reportIssue')}</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Report an issue</DialogTitle></DialogHeader>
            <div className="grid gap-3 py-2 max-h-[70vh] overflow-y-auto">
              <div><Label>Title *</Label><Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="mt-1" placeholder="Water leakage on main road" /></div>
              <div>
                <Label>Category</Label>
                <Select value={form.category} onValueChange={(v) => setForm({ ...form, category: v })}>
                  <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                  <SelectContent>{CATEGORIES.map((c) => <SelectItem key={c.value} value={c.value}>{c.label}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div><Label>Description</Label><Textarea value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="mt-1" rows={3} /></div>
              <div><Label>Location</Label><Input value={form.location_text} onChange={(e) => setForm({ ...form, location_text: e.target.value })} className="mt-1" placeholder="Near field 3, Faisalabad" /></div>
              <div className="grid grid-cols-2 gap-3">
                <div><Label>Latitude</Label><Input value={form.lat} onChange={(e) => setForm({ ...form, lat: e.target.value })} className="mt-1" /></div>
                <div><Label>Longitude</Label><Input value={form.lng} onChange={(e) => setForm({ ...form, lng: e.target.value })} className="mt-1" /></div>
              </div>
              <div>
                <Label>Urgency</Label>
                <Select value={form.urgency} onValueChange={(v) => setForm({ ...form, urgency: v })}>
                  <SelectTrigger className="mt-1 capitalize"><SelectValue /></SelectTrigger>
                  <SelectContent>{URGENCY.map((u) => <SelectItem key={u} value={u} className="capitalize">{u}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div>
                <Label>Evidence photo (stored privately)</Label>
                <Input type="file" accept="image/*" onChange={(e) => setPhoto(e.target.files?.[0])} className="mt-1" />
              </div>
              {err && <p className="text-sm text-destructive">{err}</p>}
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
              <Button onClick={submit} disabled={saving} className="gap-2">{saving && <Loader2 className="w-4 h-4 animate-spin" />} {t('common.submit')}</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-muted-foreground" /></div>
      ) : reports.length === 0 ? (
        <Widget className="p-10 text-center text-muted-foreground">
          <Users className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p className="text-sm">No reports yet. Submit the first community issue.</p>
        </Widget>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {reports.map((r) => (
            <Widget key={r.id} className="p-4">
              <div className="flex items-center justify-between gap-2">
                <Badge variant="outline" className="text-[10px] font-mono">{r.reference_number}</Badge>
                <Badge className={cn('text-[10px] capitalize', STATUS_TONE[r.status] || 'bg-muted')}>{r.status?.replace('_', ' ')}</Badge>
              </div>
              <p className="font-medium text-sm mt-2">{r.title}</p>
              <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{r.description || '—'}</p>
              <div className="flex items-center gap-1 text-xs text-muted-foreground mt-2">
                <MapPin className="w-3 h-3" /> {r.location_text || '—'}
                <span className="mx-1 opacity-40">•</span>
                <span className="capitalize">{r.urgency}</span>
              </div>
            </Widget>
          ))}
        </div>
      )}
    </div>
  );
}