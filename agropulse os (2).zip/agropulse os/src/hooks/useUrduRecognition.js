import { useCallback, useEffect, useRef, useState } from 'react';

// Speech recognition (Web Speech API). Urdu uses ur-PK; Roman Urdu uses a
// Pakistani English locale so speech stays in Latin script.
// Falls back cleanly when the browser has no SpeechRecognition support.
export function useUrduRecognition() {
  const [supported, setSupported] = useState(false);
  const [listening, setListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState(null);
  const recRef = useRef(null);
  const finalRef = useRef(null);

  useEffect(() => {
    setSupported(Boolean(window.SpeechRecognition || window.webkitSpeechRecognition));
    return () => {
      if (recRef.current) recRef.current.abort();
    };
  }, []);

  const start = useCallback((onFinal, lang = 'ur-PK') => {
    const Recognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!Recognition) {
      setError('unsupported');
      return;
    }
    finalRef.current = onFinal;
    const rec = new Recognition();
    rec.lang = lang;
    rec.interimResults = true;
    rec.continuous = false;
    rec.maxAlternatives = 1;
    rec.onstart = () => {
      setListening(true);
      setError(null);
      setTranscript('');
    };
    rec.onresult = (event) => {
      let text = '';
      for (let i = 0; i < event.results.length; i += 1) text += event.results[i][0].transcript;
      setTranscript(text.trim());
      const last = event.results[event.results.length - 1];
      if (last?.isFinal && finalRef.current) finalRef.current(text.trim());
    };
    rec.onerror = (event) => {
      setError(event.error === 'not-allowed' ? 'mic_denied' : event.error);
      setListening(false);
    };
    rec.onend = () => setListening(false);
    recRef.current = rec;
    try {
      rec.start();
    } catch {
      setError('start_failed');
    }
  }, []);

  const stop = useCallback(() => {
    if (recRef.current) recRef.current.stop();
  }, []);

  const reset = useCallback(() => {
    setTranscript('');
    setError(null);
  }, []);

  return { supported, listening, transcript, error, start, stop, reset };
}