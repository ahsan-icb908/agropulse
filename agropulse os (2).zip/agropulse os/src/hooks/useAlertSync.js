import { useEffect, useRef } from 'react';
import { base44 } from '@/api/base44Client';

// Client-side alert → notification sync. Polls for new active alerts and
// creates in-app Notification records so the user is aware of new hazards.
// True native push requires a mobile build with push credentials.
const LAST_SEEN_KEY = 'agropulse.lastAlertSeen';
const POLL_MS = 60_000;

export function useAlertSync() {
  const initialized = useRef(false);

  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    // On first ever run, stamp "now" so pre-existing alerts don't flood notifications.
    if (!localStorage.getItem(LAST_SEEN_KEY)) {
      localStorage.setItem(LAST_SEEN_KEY, new Date().toISOString());
      return;
    }

    let active = true;

    const check = async () => {
      try {
        const lastSeen = localStorage.getItem(LAST_SEEN_KEY);
        const { items } = await base44.entities.Alert.filter(
          { created_date: { $gt: lastSeen }, status: 'active' },
          { sort: '-created_date', limit: 10 }
        );
        if (!active || items.length === 0) return;

        await base44.entities.Notification.bulkCreate(
          items.map((a) => ({
            type: 'alert',
            title: `${a.title}`,
            body: `${a.severity} ${a.category} alert — view on map`,
            read: false,
            link: '/map',
            source: 'alert-sync',
          }))
        );
        localStorage.setItem(LAST_SEEN_KEY, items[0].created_date);
      } catch {
        // Non-critical: silent fail
      }
    };

    check();
    const interval = setInterval(check, POLL_MS);
    return () => {
      active = false;
      clearInterval(interval);
    };
  }, []);
}