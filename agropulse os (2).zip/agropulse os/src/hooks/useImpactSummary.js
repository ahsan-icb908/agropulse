import { useCallback, useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';

// Personal + platform SDG impact totals, computed server-side from records.
export function useImpactSummary() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    try {
      const res = await base44.functions.invoke('impactSummary', {});
      setData(res.data?.mine ? res.data : null);
    } catch {
      setData(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    const onFocus = () => load();
    window.addEventListener('focus', onFocus);
    return () => window.removeEventListener('focus', onFocus);
  }, [load]);

  return { data, loading, reload: load };
}