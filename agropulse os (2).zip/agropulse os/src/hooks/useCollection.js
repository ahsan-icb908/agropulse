import { useCallback, useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';

// Lightweight entity fetcher. Always uses the page form (options object)
// and reads .items. `reload` re-runs the query.
export function useCollection(entityName, { query, sort, limit = 50, fields } = {}) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [tick, setTick] = useState(0);

  const queryKey = JSON.stringify(query || {});

  useEffect(() => {
    let active = true;
    setLoading(true);
    base44.entities[entityName]
      .filter(query || {}, { sort, limit, fields })
      .then((res) => {
        if (!active) return;
        setData(res.items || []);
        setError(null);
      })
      .catch((e) => {
        if (!active) return;
        setError(e?.message || 'Failed to load');
        setData([]);
      })
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [entityName, queryKey, sort, limit, JSON.stringify(fields), tick]);

  const reload = useCallback(() => setTick((k) => k + 1), []);
  return { data, loading, error, reload };
}

export function useCount(entityName, query = {}) {
  const [count, setCount] = useState(null);
  const [loading, setLoading] = useState(true);
  const queryKey = JSON.stringify(query);

  useEffect(() => {
    let active = true;
    base44.entities[entityName]
      .count(query)
      .then((c) => active && setCount(c))
      .catch(() => active && setCount(0))
      .finally(() => active && setLoading(false));
    return () => {
      active = false;
    };
  }, [entityName, queryKey]);

  return { count, loading };
}