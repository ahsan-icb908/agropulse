import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { SDG_ACTIVITY } from '@/components/sdgs/sdgData';

const MAUND_TO_TONNE = 0.0373242;

// Harvest units are mixed, so convert before summing.
function toTonnes(amount, unit) {
  const n = Number(amount) || 0;
  if (unit === 'tons') return n;
  if (unit === 'maunds') return n * MAUND_TO_TONNE;
  return n / 1000;
}

const mean = (vals) => (vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : null);

// Collects every SDG-relevant number in one pass instead of one query per row.
export function useSdgMetrics() {
  const [state, setState] = useState({ loading: true, counts: {}, values: {} });

  useEffect(() => {
    let active = true;
    const count = (name, q = {}) => base44.entities[name].count(q);

    (async () => {
      const [
        reports, resolved, jobs, equipment, entrepreneurs, listings, alerts, analyses,
        compost, contracts, farms, fields, tasks, harvestCount, harvestPage, fieldPage, compostPage,
      ] = await Promise.all([
        count('CivicReport'), count('CivicReport', { status: 'resolved' }),
        count('Job'), count('Equipment'), count('Entrepreneur'), count('Listing'), count('Alert'),
        count('CropAnalysis'), count('CompostBatch'), count('Contract'), count('Farm'), count('Field'),
        count('Task'), count('Harvest'),
        base44.entities.Harvest.filter({}, { limit: 500 }),
        base44.entities.Field.filter({}, { limit: 200 }),
        base44.entities.CompostBatch.filter({}, { limit: 500 }),
      ]);

      const harvests = harvestPage.items || [];
      const fieldItems = fieldPage.items || [];

      const totalTonnes = harvests.reduce((s, h) => s + toTonnes(h.yield_amount, h.yield_unit), 0);
      const harvestedArea = harvests.reduce((s, h) => s + (Number(h.area_hectares) || 0), 0);
      const yieldPerHa = harvestedArea > 0 ? totalTonnes / harvestedArea : null;

      const phVals = fieldItems.map((f) => Number(f.soil_ph)).filter((v) => Number.isFinite(v) && v > 0);
      const moistVals = fieldItems.map((f) => Number(f.soil_moisture)).filter((v) => Number.isFinite(v) && v > 0);
      const phAvg = mean(phVals);
      const moistAvg = mean(moistVals);

      const compostKg = (compostPage.items || []).reduce((s, b) => s + (Number(b.volume_kg) || 0), 0);
      const openReports = Math.max((reports || 0) - (resolved || 0), 0);

      const counts = {
        CivicReport: reports, ReportsResolved: resolved, ReportsOpen: openReports,
        Job: jobs, Equipment: equipment, Entrepreneur: entrepreneurs, Listing: listings,
        Alert: alerts, CropAnalysis: analyses, CompostBatch: compost, Contract: contracts,
        Farm: farms, Field: fields, Task: tasks, Harvest: harvestCount,
        FieldPh: phVals.length, FieldMoisture: moistVals.length,
      };

      // Only values genuinely computed from stored records appear here.
      const values = {
        '2|Total yield (tons)': totalTonnes > 0 ? { text: `${totalTonnes.toFixed(1)} t` } : null,
        '2|Yield per hectare': yieldPerHa ? { text: `${yieldPerHa.toFixed(2)} t/ha` } : null,
        '11|Open community reports': { text: String(openReports) },
        '11|Resolved reports': { text: String(resolved || 0) },
        '12|Waste tracked (kg)': compostKg > 0 ? { text: `${compostKg.toLocaleString()} kg` } : null,
        '15|Soil pH avg': phAvg ? { text: phAvg.toFixed(2) } : null,
        '15|Soil moisture avg': moistAvg ? { text: `${moistAvg.toFixed(0)}%` } : null,
        '16|Reports submitted': { text: String(reports || 0) },
        '16|Reports resolved': { text: String(resolved || 0) },
      };

      if (!active) return;
      setState({ loading: false, counts, values });
    })();

    return () => { active = false; };
  }, []);

  const valueOf = (goalN, indicator) => {
    if (state.loading) return null;
    return state.values[`${goalN}|${indicator}`] || null;
  };

  const activityOf = (goalN) =>
    (SDG_ACTIVITY[goalN] || []).map((a) => ({ label: a.label, count: state.counts[a.e] ?? 0 }));

  return { loading: state.loading, valueOf, activityOf };
}