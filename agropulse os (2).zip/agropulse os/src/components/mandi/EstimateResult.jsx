import { Info, RefreshCw } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

// Displays a mandi price estimate. Estimates are always labelled as such.
export default function EstimateResult({ estimate, lang }) {
  const urdu = lang === 'ur';
  const retrieved = estimate.retrieved_at ? new Date(estimate.retrieved_at) : null;

  return (
    <div className="space-y-3 rounded-xl border border-primary/20 bg-primary/5 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="text-xs uppercase tracking-wide text-muted-foreground">
            Suggested direct selling price
          </p>
          <p className="font-heading text-2xl font-bold">
            PKR {estimate.suggested_price_per_kg?.toLocaleString()}
            <span className="text-sm font-medium text-muted-foreground"> /kg</span>
          </p>
        </div>
        <Badge variant="secondary" className="gap-1 bg-primary/10 text-primary">
          Fair margin {estimate.fair_margin_percent}%
        </Badge>
      </div>

      <div className="grid grid-cols-2 gap-2 text-sm">
        <div className="rounded-lg bg-card p-2.5">
          <p className="text-[11px] text-muted-foreground">Pakistan-wide benchmark</p>
          <p className="font-semibold tabular-nums">PKR {estimate.benchmark_price_per_kg?.toLocaleString()}/kg</p>
        </div>
        <div className="rounded-lg bg-card p-2.5">
          <p className="text-[11px] text-muted-foreground">{estimate.mandi} mandi</p>
          <p className="font-semibold tabular-nums">PKR {estimate.mandi_price_per_kg?.toLocaleString()}/kg</p>
        </div>
        <div className="rounded-lg bg-card p-2.5">
          <p className="text-[11px] text-muted-foreground">Suggested range</p>
          <p className="font-semibold tabular-nums">
            {estimate.range_low_per_kg?.toLocaleString()} – {estimate.range_high_per_kg?.toLocaleString()}
          </p>
        </div>
        <div className="rounded-lg bg-card p-2.5">
          <p className="text-[11px] text-muted-foreground">Your quantity</p>
          <p className="font-semibold tabular-nums">{estimate.quantity_kg?.toLocaleString()} kg</p>
        </div>
      </div>

      {(estimate.notes_ur || estimate.notes_en) && (
        <p className={cn('text-sm text-foreground/90', urdu && 'font-urdu text-end')} dir={urdu ? 'rtl' : 'ltr'}>
          {urdu ? estimate.notes_ur || estimate.notes_en : estimate.notes_en || estimate.notes_ur}
        </p>
      )}

      {estimate.assumptions?.length > 0 && (
        <ul className="list-disc space-y-1 ps-4 text-xs text-muted-foreground">
          {estimate.assumptions.map((item) => <li key={item}>{item}</li>)}
        </ul>
      )}

      <div className="flex items-start gap-1.5 text-[11px] text-muted-foreground">
        <Info className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
        <span>
          {estimate.price_basis && `${estimate.price_basis}. `}
          Estimate only — not a verified live mandi feed.
          {retrieved && (
            <span className="inline-flex items-center gap-1"> Retrieved {retrieved.toLocaleString()}<RefreshCw className="h-3 w-3" aria-hidden="true" /></span>
          )}
        </span>
      </div>
    </div>
  );
}