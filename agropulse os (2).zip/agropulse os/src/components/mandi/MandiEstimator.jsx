import { useState } from 'react';
import { Loader2, Sparkles, Store, AlertTriangle } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/components/ui/use-toast';
import { useI18n } from '@/i18n/LanguageContext';
import EstimateResult from '@/components/mandi/EstimateResult';

const CROPS = ['Wheat', 'Basmati Rice', 'Maize', 'Sugarcane', 'Cotton', 'Tomato', 'Potato', 'Onion', 'Chickpea', 'Mustard'];
const MANDIS = ['Lahore', 'Faisalabad', 'Multan', 'Sargodha', 'Karachi', 'Hyderabad', 'Peshawar', 'Quetta', 'Islamabad', 'Bahawalpur', 'Gujranwala', 'Sahiwal'];
const UNITS = ['kg', 'maunds', 'tons', 'bag'];

const EMPTY = { crop: '', quantity: '', quantity_unit: 'maunds', location: '', mandi: '', farm_name: '', seller_contact: '' };

export default function MandiEstimator({ onPublished }) {
  const { lang } = useI18n();
  const { toast } = useToast();
  const [form, setForm] = useState(EMPTY);
  const [estimate, setEstimate] = useState(null);
  const [message, setMessage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [publishing, setPublishing] = useState(false);
  const [price, setPrice] = useState('');

  const set = (key, value) => setForm((prev) => ({ ...prev, [key]: value }));

  async function getEstimate() {
    if (!form.crop.trim()) {
      setMessage('Choose or type a crop first.');
      return;
    }
    setLoading(true);
    setMessage(null);
    setEstimate(null);
    try {
      const res = await base44.functions.invoke('mandiEstimate', {
        crop: form.crop.trim(),
        quantity: Number(form.quantity) || 0,
        quantity_unit: form.quantity_unit,
        location: form.location.trim(),
        mandi: form.mandi.trim(),
      });
      const data = res.data || {};
      if (data.status === 'ok') {
        setEstimate(data);
        setPrice(String(data.suggested_price_per_kg));
      } else {
        setMessage(data.message || 'The estimate is unavailable right now. Try again in a moment.');
      }
    } catch {
      setMessage('The estimate could not be fetched. Check your connection and try again.');
    } finally {
      setLoading(false);
    }
  }

  async function publish() {
    const perKg = Number(price) || 0;
    if (!perKg || !estimate) return;
    setPublishing(true);
    try {
      const qty = Number(form.quantity) || 0;
      await base44.entities.Listing.create({
        title: `${estimate.crop} — ${qty} ${form.quantity_unit} (direct)`,
        crop: estimate.crop,
        category: 'grain',
        quantity: qty,
        quantity_unit: form.quantity_unit,
        price: perKg,
        price_unit: 'per_kg',
        farm_name: form.farm_name.trim(),
        location_text: form.location.trim() || estimate.mandi,
        seller_contact: form.seller_contact.trim(),
        description: `Direct farm sale. Mandi estimate: PKR ${estimate.mandi_price_per_kg}/kg at ${estimate.mandi}, fair margin ${estimate.fair_margin_percent}%.`,
        status: 'active',
        mandi: estimate.mandi,
        listed_via: 'mandi_connect',
        estimate_benchmark_price: estimate.benchmark_price_per_kg,
        estimate_mandi_price: estimate.mandi_price_per_kg,
        estimate_fair_margin: estimate.fair_margin_percent,
        estimate_suggested_price: estimate.suggested_price_per_kg,
        estimate_retrieved_at: estimate.retrieved_at,
        estimate_source: estimate.source,
      });
      toast({ title: 'Listing published', description: 'Buyers can now find it in the marketplace.' });
      setEstimate(null);
      setForm(EMPTY);
      setPrice('');
      onPublished?.();
    } finally {
      setPublishing(false);
    }
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div>
          <Label htmlFor="mandi-crop">Crop *</Label>
          <Input
            id="mandi-crop"
            list="mandi-crops"
            value={form.crop}
            onChange={(e) => set('crop', e.target.value)}
            placeholder="Wheat"
            className="mt-1"
          />
          <datalist id="mandi-crops">{CROPS.map((c) => <option key={c} value={c} />)}</datalist>
        </div>
        <div>
          <Label htmlFor="mandi-name">Mandi</Label>
          <Input
            id="mandi-name"
            list="mandi-list"
            value={form.mandi}
            onChange={(e) => set('mandi', e.target.value)}
            placeholder="Faisalabad (leave empty for Pakistan-wide)"
            className="mt-1"
          />
          <datalist id="mandi-list">{MANDIS.map((m) => <option key={m} value={m} />)}</datalist>
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div>
            <Label htmlFor="mandi-qty">Quantity</Label>
            <Input
              id="mandi-qty"
              type="number"
              inputMode="decimal"
              value={form.quantity}
              onChange={(e) => set('quantity', e.target.value)}
              className="mt-1"
            />
          </div>
          <div>
            <Label htmlFor="mandi-unit">Unit</Label>
            <Select value={form.quantity_unit} onValueChange={(v) => set('quantity_unit', v)}>
              <SelectTrigger id="mandi-unit" className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>{UNITS.map((u) => <SelectItem key={u} value={u}>{u}</SelectItem>)}</SelectContent>
            </Select>
          </div>
        </div>
        <div>
          <Label htmlFor="mandi-loc">Village / district</Label>
          <Input
            id="mandi-loc"
            value={form.location}
            onChange={(e) => set('location', e.target.value)}
            placeholder="Chak 45, Faisalabad"
            className="mt-1"
          />
        </div>
      </div>

      <Button onClick={getEstimate} disabled={loading} className="w-full gap-2 sm:w-auto">
        {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
        {loading ? 'Checking the market…' : 'Get fair price'}
      </Button>

      {message && (
        <div className="flex items-start gap-2 rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 text-xs text-amber-800">
          <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" aria-hidden="true" />
          {message}
        </div>
      )}

      {estimate && (
        <div className="space-y-3">
          <EstimateResult estimate={estimate} lang={lang} />
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <Label htmlFor="mandi-farm">Farm name</Label>
              <Input id="mandi-farm" value={form.farm_name} onChange={(e) => set('farm_name', e.target.value)} className="mt-1" />
            </div>
            <div>
              <Label htmlFor="mandi-contact">Contact number</Label>
              <Input id="mandi-contact" value={form.seller_contact} onChange={(e) => set('seller_contact', e.target.value)} placeholder="0300-1234567" className="mt-1" />
            </div>
            <div>
              <Label htmlFor="mandi-price">Your price (PKR per kg)</Label>
              <Input id="mandi-price" type="number" value={price} onChange={(e) => setPrice(e.target.value)} className="mt-1" />
            </div>
            <div className="flex items-end">
              <Button onClick={publish} disabled={publishing || !Number(price)} className="w-full gap-2">
                {publishing ? <Loader2 className="h-4 w-4 animate-spin" /> : <Store className="h-4 w-4" />}
                Publish listing
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}