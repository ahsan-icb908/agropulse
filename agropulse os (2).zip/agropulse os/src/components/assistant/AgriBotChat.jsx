import { useRef, useState } from 'react';
import { Sparkles, Send, Loader2, User, Bot, Mic, Square } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { useUrduRecognition } from '@/hooks/useUrduRecognition';
import { useI18n } from '@/i18n/LanguageContext';
import { cn } from '@/lib/utils';

const SUGGESTIONS = [
  'When should I irrigate my wheat this week?',
  'What does leaf rust look like and how do I prevent it?',
  'سوئی بارش کے بعد فصل کی دیکھ بھال کیسے کریں؟',
  'Summarize my farm tasks and risks.',
];

const DICT_LANGS = [
  { value: 'ur-PK', label: 'اردو' },
  { value: 'en-PK', label: 'Roman Urdu' },
];

// AgriBot chat with hands-free dictation (Web Speech API).
// Urdu uses ur-PK; Roman Urdu uses en-PK recognition and stays in Latin script.
export default function AgriBotChat({ context = '' }) {
  const { lang } = useI18n();
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content:
        'Salam! I am your AgroPulse assistant. Ask me about irrigation, crop disease, weather risks, or your farm records — in English, Urdu or Roman Urdu.',
    },
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [dictLang, setDictLang] = useState('ur-PK');
  const recognition = useUrduRecognition();
  const inputRef = useRef(null);

  async function send(text) {
    const message = (text || input).trim();
    if (!message || busy) return;
    setInput('');
    const next = [...messages, { role: 'user', content: message }];
    setMessages(next);
    setBusy(true);
    try {
      const res = await base44.functions.invoke('agriChat', {
        message,
        context,
        history: next.slice(-6),
      });
      const data = res.data || {};
      const answer =
        data.status === 'ok'
          ? data.answer
          : data.message || 'Sorry, I could not get a response right now.';
      setMessages([...next, { role: 'assistant', content: answer }]);
    } catch (e) {
      setMessages([...next, { role: 'assistant', content: 'Sorry, I could not get a response right now. (' + (e?.message || 'error') + ')' }]);
    } finally {
      setBusy(false);
    }
  }

  function toggleDictation() {
    if (recognition.listening) {
      recognition.stop();
      return;
    }
    recognition.start(
      (text) => {
        setInput((prev) => (prev ? `${prev} ${text}` : text));
        inputRef.current?.focus();
      },
      dictLang
    );
  }

  return (
    <div className="flex h-full flex-col overflow-hidden rounded-2xl border border-border/70 bg-card shadow-sm">
      <div className="flex-1 space-y-4 overflow-y-auto scrollbar-thin p-4">
        {messages.map((m, i) => (
          <div key={i} className={`flex gap-3 ${m.role === 'user' ? 'flex-row-reverse' : ''}`}>
            <span
              className={`flex h-8 w-8 shrink-0 items-center justify-center rounded-full ${
                m.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-primary/10 text-primary'
              }`}
            >
              {m.role === 'user' ? <User className="h-4 w-4" /> : <Bot className="h-4 w-4" />}
            </span>
            <div
              className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
                m.role === 'user' ? 'bg-primary text-primary-foreground' : 'bg-muted'
              }`}
              dir={lang === 'ur' && m.role === 'assistant' ? 'auto' : undefined}
            >
              <p className="whitespace-pre-wrap leading-relaxed">{m.content}</p>
            </div>
          </div>
        ))}
        {busy && (
          <div className="flex gap-3">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 text-primary">
              <Bot className="h-4 w-4" />
            </span>
            <div className="rounded-2xl bg-muted px-4 py-3">
              <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
            </div>
          </div>
        )}
      </div>

      <div className="space-y-2 border-t border-border p-3">
        <div className="flex flex-wrap gap-2">
          {SUGGESTIONS.map((s) => (
            <button
              key={s}
              onClick={() => send(s)}
              className="rounded-full border border-border px-3 py-1 text-xs transition-colors hover:bg-muted"
            >
              {s}
            </button>
          ))}
        </div>

        {recognition.transcript && (
          <p className={cn('rounded-lg bg-muted/60 p-2 text-xs', dictLang === 'ur-PK' && 'font-urdu text-end')} dir={dictLang === 'ur-PK' ? 'rtl' : 'ltr'}>
            {recognition.transcript}
          </p>
        )}
        {!recognition.supported && (
          <p className="text-xs text-amber-700">
            Voice dictation is not available in this browser — type your question instead.
          </p>
        )}
        {recognition.error === 'mic_denied' && (
          <p className="text-xs text-amber-700">Microphone access was refused. Allow it in your browser to dictate.</p>
        )}

        <div className="flex items-end gap-2">
          <Textarea
            ref={inputRef}
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                send();
              }
            }}
            placeholder="Type or dictate your question…"
            rows={1}
            className="resize-none"
          />
          <Button
            variant={recognition.listening ? 'destructive' : 'outline'}
            size="icon"
            onClick={toggleDictation}
            disabled={!recognition.supported || busy}
            aria-label={recognition.listening ? 'Stop dictation' : 'Dictate question'}
            className="h-auto self-stretch"
          >
            {recognition.listening ? <Square className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
          </Button>
          <Button onClick={() => send()} disabled={busy} size="icon" className="h-auto self-stretch">
            <Send className="h-4 w-4" />
          </Button>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[11px] text-muted-foreground">Dictation:</span>
          {DICT_LANGS.map((d) => (
            <button
              key={d.value}
              onClick={() => setDictLang(d.value)}
              className={cn(
                'rounded-full border px-2.5 py-0.5 text-[11px] transition-colors',
                dictLang === d.value
                  ? 'border-primary bg-primary/10 text-primary font-medium'
                  : 'border-border text-muted-foreground hover:bg-muted'
              )}
            >
              {d.label}
            </button>
          ))}
          <Badge variant="secondary" className="ms-auto gap-1 text-[10px]">
            <Sparkles className="h-3 w-3" /> AI-generated — verify before acting
          </Badge>
        </div>
      </div>
    </div>
  );
}