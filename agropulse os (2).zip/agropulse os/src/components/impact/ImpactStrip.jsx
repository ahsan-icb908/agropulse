import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Droplets, Leaf, HandCoins, ArrowUpRight } from 'lucide-react';
import { useImpactSummary } from '@/hooks/useImpactSummary';
import { formatLiters, formatKg, formatPkr } from '@/lib/impact/metrics';
import { cn } from '@/lib/utils';

// Compact live SDG impact strip shown under the top bar.
export default function ImpactStrip() {
  const { data } = useImpactSummary();
  const [view, setView] = useState('mine');
  const totals = data?.[view];

  const items = [
    { icon: Droplets, label: 'Water saved', value: totals ? `${formatLiters(totals.water_liters)} L` : '—' },
    { icon: Leaf, label: 'Fertilizer reduced', value: totals ? `${formatKg(totals.fertilizer_kg)} kg` : '—' },
    { icon: HandCoins, label: 'Middleman saved', value: totals ? `PKR ${formatPkr(totals.middleman_pkr)}` : '—' },
  ];

  return (
    <div className="flex items-center gap-2 overflow-x-auto border-t border-border/60 px-4 py-1.5 sm:px-6">
      <div className="flex shrink-0 rounded-full bg-muted p-0.5">
        {[
          { key: 'mine', label: 'My farms' },
          { key: 'platform', label: 'All' },
        ].map((option) => (
          <button
            key={option.key}
            onClick={() => setView(option.key)}
            aria-pressed={view === option.key}
            className={cn(
              'rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors',
              view === option.key
                ? 'bg-card text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground'
            )}
          >
            {option.label}
          </button>
        ))}
      </div>

      <div className="flex items-center gap-4 sm:gap-6">
        {items.map(({ icon: Icon, label, value }) => (
          <div key={label} className="flex shrink-0 items-center gap-1.5" title={label}>
            <Icon className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
            <span className="text-[11px] font-semibold tabular-nums">{value}</span>
            <span className="hidden text-[11px] text-muted-foreground sm:inline">{label}</span>
          </div>
        ))}
      </div>

      <Link
        to="/impact"
        className="ms-auto flex shrink-0 items-center gap-1 text-[11px] font-medium text-primary hover:underline"
      >
        Methodology
        <ArrowUpRight className="h-3 w-3" aria-hidden="true" />
      </Link>
    </div>
  );
}