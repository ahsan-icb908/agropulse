import { useState } from 'react';
import { Plus, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useToast } from '@/components/ui/use-toast';

const EMPTY = { note: '', water_liters: '', fertilizer_kg: '', middleman_pkr: '' };

export default function SavingForm({ onSaved }) {
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  async function save() {
    if (!form.note.trim()) return;
    setSaving(true);
    try {
      await base44.entities.ImpactSaving.create({
        note: form.note.trim(),
        water_liters: Number(form.water_liters) || 0,
        fertilizer_kg: Number(form.fertilizer_kg) || 0,
        middleman_pkr: Number(form.middleman_pkr) || 0,
        recorded_on: new Date().toISOString().slice(0, 10),
      });
      setForm(EMPTY);
      toast({ title: 'Saving recorded', description: 'It now counts in your impact totals.' });
      onSaved?.();
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-3">
      <div>
        <Label htmlFor="saving-note">What did you save?</Label>
        <Input
          id="saving-note"
          value={form.note}
          onChange={(e) => setForm({ ...form, note: e.target.value })}
          placeholder="Skipped one canal turn this week"
          className="mt-1"
        />
      </div>
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <div>
          <Label htmlFor="saving-water">Water (litres)</Label>
          <Input
            id="saving-water"
            type="number"
            inputMode="numeric"
            value={form.water_liters}
            onChange={(e) => setForm({ ...form, water_liters: e.target.value })}
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="saving-fert">Fertilizer (kg)</Label>
          <Input
            id="saving-fert"
            type="number"
            inputMode="decimal"
            value={form.fertilizer_kg}
            onChange={(e) => setForm({ ...form, fertilizer_kg: e.target.value })}
            className="mt-1"
          />
        </div>
        <div>
          <Label htmlFor="saving-pkr">Middleman cost (PKR)</Label>
          <Input
            id="saving-pkr"
            type="number"
            inputMode="numeric"
            value={form.middleman_pkr}
            onChange={(e) => setForm({ ...form, middleman_pkr: e.target.value })}
            className="mt-1"
          />
        </div>
      </div>
      <Button onClick={save} disabled={saving || !form.note.trim()} className="gap-2">
        {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
        Add saving
      </Button>
    </div>
  );
}