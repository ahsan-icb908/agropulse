// SDG reference data: goal metadata, 5-P categories, and the app record types
// that act as activity evidence for each goal.

export const SDG_CATEGORIES = [
  { key: 'all', label: 'All goals', hint: '17 goals' },
  { key: 'people', label: 'People', hint: 'Goals 1–5', tint: '#E5243B' },
  { key: 'planet', label: 'Planet', hint: 'Goals 6, 12–15', tint: '#3F7E44' },
  { key: 'prosperity', label: 'Prosperity', hint: 'Goals 7–11', tint: '#DDA63A' },
  { key: 'peace', label: 'Peace', hint: 'Goal 16', tint: '#00689D' },
  { key: 'partnership', label: 'Partnership', hint: 'Goal 17', tint: '#19486A' },
];

export const SDGS = [
  { n: 1, category: 'people', name: 'No Poverty', color: '#E5243B', desc: 'End poverty in all its forms. Track agricultural income and production costs.', indicators: ['Net farm income (PKR/season)', 'Production cost per hectare'], feature: 'Direct Farmer-to-Buyer Marketplace', implementation: 'Cut middleman commissions with direct listing portals, transparent price tracking, and real-time local mandi rate feeds.', status: 'live' },
  { n: 2, category: 'people', name: 'Zero Hunger', color: '#DDA63A', desc: 'End hunger, achieve food security. Track crop production and yield trends.', indicators: ['Total yield (tons)', 'Yield per hectare', 'Post-harvest loss (%)'], feature: 'Yield & Harvest Tracking', implementation: 'Record harvests per field and season; analytics dashboard summarizes total yield and productivity trends.', status: 'live' },
  { n: 3, category: 'people', name: 'Good Health & Well-being', color: '#4C9F38', desc: 'Ensure healthy lives. Track environmental-health risk exposure.', indicators: ['Heatwave exposure days', 'Air quality index'], feature: 'Agro-Safety & Pesticide Advisory', implementation: 'Dosage calculators for eco-friendly pesticides, chemical safety guides, and non-toxic pest management alternatives.', status: 'live' },
  { n: 4, category: 'people', name: 'Quality Education', color: '#C5192D', desc: 'Inclusive education. Track agricultural training participation.', indicators: ['Training sessions attended', 'Resources accessed'], feature: 'Multilingual Audio/Visual Knowledge Hub', implementation: 'Voice-guided tutorials, step-by-step disease identification guides, and video modules for low-literacy users.', status: 'live' },
  { n: 5, category: 'people', name: 'Gender Equality', color: '#FF3A21', desc: 'Achieve gender equality. Track equitable participation (where lawfully collected).', indicators: ['Participation rate (%)'], feature: 'Women Agro-Entrepreneur Directory', implementation: 'Micro-grant applications, dedicated vendor badges, and peer network forums designed for female smallholders.', status: 'live' },
  { n: 6, category: 'planet', name: 'Clean Water & Sanitation', color: '#26BDE2', desc: 'Water and sanitation for all. Track water use, quality and irrigation efficiency.', indicators: ['Water use (L)', 'Irrigation efficiency (%)', 'Water quality reports'], feature: 'Smart Irrigation & Runoff Manager', implementation: 'Crop-water requirement calculators using weather data to prevent groundwater depletion and chemical runoff.', status: 'live' },
  { n: 7, category: 'prosperity', name: 'Affordable & Clean Energy', color: '#FCC30B', desc: 'Clean energy. Track renewable energy usage on farms.', indicators: ['Renewable energy share (%)'], feature: 'Solar & Clean Tech Equipment Rental', implementation: 'Peer-to-peer sharing or rental system for solar pumps, cold-storage capacity, and renewable farm tools.', status: 'live' },
  { n: 8, category: 'prosperity', name: 'Decent Work & Economic Growth', color: '#A21942', desc: 'Promote sustained economic growth. Track farm labor and productivity.', indicators: ['Labor employed', 'Labor cost (PKR)', 'Productivity index'], feature: 'Fair Labor & Fair-Wage Job Board', implementation: 'Seasonal labor matching system enforcing fair-wage standards, safety guidelines, and local farm jobs.', status: 'live' },
  { n: 9, category: 'prosperity', name: 'Industry, Innovation & Infrastructure', color: '#FD6925', desc: 'Build resilient infrastructure. Track ag-tech adoption and infrastructure issues.', indicators: ['Tech adoption (%)', 'Infrastructure reports'], feature: 'AI Disease Diagnosis & Offline PWA', implementation: 'Offline-first Progressive Web App (PWA) with client-side AI image detection for crop diseases.', status: 'live' },
  { n: 10, category: 'prosperity', name: 'Reduced Inequalities', color: '#DD1367', desc: 'Reduce inequality. Track equitable service access.', indicators: ['Service access index'], feature: 'Accessibility & Low-Bandwidth Mode', implementation: 'Lightweight interface optimized for 2G/3G networks, basic smartphones, and screen-reader support.', status: 'live' },
  { n: 11, category: 'prosperity', name: 'Sustainable Cities & Communities', color: '#FD9D24', desc: 'Make communities sustainable. Track community issues and resilience.', indicators: ['Open community reports', 'Resolved reports', 'Resilience measures'], feature: 'Urban-Periurban Produce Links', implementation: 'Hyper-local farm-to-table supply routes to minimize transit time and supply food deserts in urban hubs.', status: 'live' },
  { n: 12, category: 'planet', name: 'Responsible Consumption & Production', color: '#BF8B2E', desc: 'Sustainable consumption. Track input efficiency and waste.', indicators: ['Input use efficiency (%)', 'Waste tracked (kg)'], feature: 'Post-Harvest Waste Reduction & Composting', implementation: 'Surplus food redistribution boards and organic waste management trackers to turn crop residue into bio-fertilizer.', status: 'live' },
  { n: 13, category: 'planet', name: 'Climate Action', color: '#3F7E44', desc: 'Combat climate change. Track climate observations and resilience activities.', indicators: ['Climate observations', 'Resilience activities'], feature: 'Extreme Weather & Climate Alerts', implementation: 'SMS/Web push alerts for sudden weather shifts, frost, or flooding with crop-specific recovery steps.', status: 'live' },
  { n: 14, category: 'planet', name: 'Life Below Water', color: '#0A97D9', desc: 'Conserve oceans. Track verified water pollution observations where applicable.', indicators: ['Water pollution reports'], feature: 'Aquaponics & Runoff-Reduction Module', implementation: 'Soil-nitrogen balance tools to stop fertilizer leaching into local waterways and aquatic ecosystems.', status: 'live' },
  { n: 15, category: 'planet', name: 'Life on Land', color: '#56C02B', desc: 'Protect land ecosystems. Track soil health and biodiversity.', indicators: ['Soil pH avg', 'Soil moisture avg', 'Conservation activities'], feature: 'Soil Health & Regenerative Farming Tracker', implementation: 'Crop rotation planners, soil-testing loggers, and organic bio-fertilizer recipe builders.', status: 'live' },
  { n: 16, category: 'peace', name: 'Peace, Justice & Institutions', color: '#00689D', desc: 'Strong institutions. Track transparent report workflows and accountability.', indicators: ['Reports submitted', 'Reports resolved', 'Audit records'], feature: 'Land Rights & Fair Contract Registry', implementation: 'Standardized, transparent contract templates for tenant farmers to prevent exploitation.', status: 'live' },
  { n: 17, category: 'partnership', name: 'Partnerships for the Goals', color: '#19486A', desc: 'Revitalize partnerships. Track collaboration records and community projects.', indicators: ['Partnerships', 'Community projects'], feature: 'Open SDG Analytics Dashboard', implementation: 'Real-time open data API sharing localized agricultural metrics with NGOs, government bodies, and researchers.', status: 'live' },
];

// App records that act as activity evidence for each goal.
export const SDG_ACTIVITY = {
  1: [{ label: 'Marketplace listings', e: 'Listing' }, { label: 'Farms registered', e: 'Farm' }],
  2: [{ label: 'Harvests logged', e: 'Harvest' }, { label: 'Fields tracked', e: 'Field' }, { label: 'Tasks logged', e: 'Task' }],
  3: [{ label: 'Hazard alerts on file', e: 'Alert' }],
  5: [{ label: 'Women entrepreneurs listed', e: 'Entrepreneur' }],
  6: [{ label: 'Fields with moisture recorded', e: 'FieldMoisture' }],
  7: [{ label: 'Equipment listed for rent', e: 'Equipment' }],
  8: [{ label: 'Job posts on the board', e: 'Job' }],
  9: [{ label: 'Crop analyses run', e: 'CropAnalysis' }],
  11: [{ label: 'Community reports filed', e: 'CivicReport' }, { label: 'Reports resolved', e: 'ReportsResolved' }],
  12: [{ label: 'Compost batches tracked', e: 'CompostBatch' }, { label: 'Fields tracked', e: 'Field' }],
  13: [{ label: 'Hazard alerts on file', e: 'Alert' }],
  14: [{ label: 'Compost batches tracked', e: 'CompostBatch' }],
  15: [{ label: 'Fields with pH recorded', e: 'FieldPh' }, { label: 'Fields tracked', e: 'Field' }],
  16: [{ label: 'Contracts on record', e: 'Contract' }, { label: 'Community reports filed', e: 'CivicReport' }],
  17: [{ label: 'Farms registered', e: 'Farm' }, { label: 'Fields tracked', e: 'Field' }],
};

// Goals highlighted on the overview dashboard.
export const SDG_FEATURED = [2, 6, 13, 15];

export function goalsFor(categoryKey) {
  return categoryKey === 'all' ? SDGS : SDGS.filter((s) => s.category === categoryKey);
}