import { useState, useEffect, useCallback } from 'react';
import { TrendingUp, TrendingDown, Minus, RefreshCw, Loader2, Bell, BellRing, Target, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const FALLBACK_PRICES = [
  { crop: 'Wheat', price_per_kg: 120, price_per_maund: 4800, trend: 'stable' },
  { crop: 'Basmati Rice', price_per_kg: 350, price_per_maund: 14000, trend: 'up' },
  { crop: 'Maize', price_per_kg: 95, price_per_maund: 3800, trend: 'down' },
  { crop: 'Sugarcane', price_per_kg: 30, price_per_maund: 1200, trend: 'stable' },
  { crop: 'Cotton', price_per_kg: 280, price_per_maund: 11200, trend: 'up' },
  { crop: 'Tomato', price_per_kg: 80, price_per_maund: 3200, trend: 'down' },
  { crop: 'Potato', price_per_kg: 65, price_per_maund: 2600, trend: 'stable' },
  { crop: 'Onion', price_per_kg: 90, price_per_maund: 3600, trend: 'up' },
];

const TARGETS_KEY = 'agropulse.mandi.targets';

const TREND_ICON = { up: TrendingUp, down: TrendingDown, stable: Minus };
const TREND_COLOR = { up: 'text-emerald-600', down: 'text-red-600', stable: 'text-muted-foreground' };

export default function MandiRates() {
  const [prices, setPrices] = useState(FALLBACK_PRICES);
  const [loading, setLoading] = useState(false);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [targets, setTargets] = useState(() => {
    try { return JSON.parse(localStorage.getItem(TARGETS_KEY) || '{}'); } catch { return {}; }
  });
  const [settingTarget, setSettingTarget] = useState(null);
  const [targetInput, setTargetInput] = useState('');
  const { toast } = useToast();

  const fetchPrices = useCallback(async () => {
    setLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: 'Give me the current approximate mandi (wholesale market) prices in Pakistan for these crops: wheat, basmati rice, maize, sugarcane, cotton, tomato, potato, onion. Return prices in PKR per kg and per 40 kg maund. Include the trend (up, down, or stable). Use the latest available data.',
        add_context_from_internet: true,
        model: 'gemini_3_flash',
        response_json_schema: {
          type: 'object',
          properties: {
            prices: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  crop: { type: 'string' },
                  price_per_kg: { type: 'number' },
                  price_per_maund: { type: 'number' },
                  trend: { type: 'string' },
                },
              },
            },
          },
        },
      });
      if (res?.prices?.length) {
        setPrices(res.prices);
        setLastUpdated(new Date());
        checkAlerts(res.prices);
      }
    } catch (e) {
      // keep fallback prices
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { fetchPrices(); }, [fetchPrices]);

  function checkAlerts(newPrices) {
    newPrices.forEach((p) => {
      const target = targets[p.crop];
      if (target && p.price_per_kg >= target) {
        toast({
          title: `🎯 ${p.crop} target hit!`,
          description: `Current: PKR ${p.price_per_kg}/kg — your target was PKR ${target}/kg.`,
        });
      }
    });
  }

  function saveTarget(crop) {
    const val = Number(targetInput);
    if (!val) { setSettingTarget(null); return; }
    const newTargets = { ...targets, [crop]: val };
    setTargets(newTargets);
    localStorage.setItem(TARGETS_KEY, JSON.stringify(newTargets));
    setSettingTarget(null);
    setTargetInput('');
  }

  function removeTarget(crop) {
    const newTargets = { ...targets };
    delete newTargets[crop];
    setTargets(newTargets);
    localStorage.setItem(TARGETS_KEY, JSON.stringify(newTargets));
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-heading text-lg font-bold tracking-tight flex items-center gap-2">
            <span className="w-7 h-7 rounded-lg bg-primary/10 text-primary flex items-center justify-center"><TrendingUp className="w-4 h-4" /></span>
            Mandi Price Rates
          </h2>
          <p className="text-xs text-muted-foreground mt-1">
            {lastUpdated ? `Updated ${lastUpdated.toLocaleTimeString()}` : 'Showing reference rates — refresh for live prices'}
          </p>
        </div>
        <Button variant="outline" size="sm" onClick={fetchPrices} disabled={loading} className="gap-2">
          {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <RefreshCw className="w-3.5 h-3.5" />}
          Refresh
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
        {prices.map((p) => {
          const TrendIcon = TREND_ICON[p.trend] || Minus;
          const target = targets[p.crop];
          const targetHit = target && p.price_per_kg >= target;
          return (
            <Widget key={p.crop} className={`p-3.5 ${targetHit ? 'ring-2 ring-emerald-500' : ''}`}>
              <div className="flex items-start justify-between">
                <p className="font-heading font-semibold text-sm">{p.crop}</p>
                {targetHit ? <BellRing className="w-4 h-4 text-emerald-500" /> : target ? <Bell className="w-4 h-4 text-amber-500" /> : null}
              </div>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-xl font-bold">PKR {p.price_per_kg?.toLocaleString()}</span>
                <span className="text-xs text-muted-foreground">/kg</span>
              </div>
              <p className="text-xs text-muted-foreground">PKR {p.price_per_maund?.toLocaleString()} /maund</p>
              <div className={`mt-2 flex items-center gap-1 text-xs font-medium ${TREND_COLOR[p.trend] || ''}`}>
                <TrendIcon className="w-3 h-3" /> {p.trend}
              </div>
              {target && !targetHit && (
                <p className="text-xs text-amber-600 mt-1.5 flex items-center gap-1"><Target className="w-3 h-3" /> Target: PKR {target}/kg</p>
              )}
              {targetHit && (
                <p className="text-xs text-emerald-600 font-medium mt-1.5">🎯 Target reached!</p>
              )}
              {settingTarget === p.crop ? (
                <div className="mt-2 flex gap-1">
                  <Input type="number" value={targetInput} onChange={(e) => setTargetInput(e.target.value)} placeholder="PKR/kg" className="h-7 text-xs" autoFocus onKeyDown={(e) => e.key === 'Enter' && saveTarget(p.crop)} />
                  <Button size="sm" className="h-7 px-2" onClick={() => saveTarget(p.crop)}>Set</Button>
                  <button onClick={() => setSettingTarget(null)} className="p-1 text-muted-foreground hover:text-foreground"><X className="w-3.5 h-3.5" /></button>
                </div>
              ) : (
                <button
                  onClick={() => target ? removeTarget(p.crop) : setSettingTarget(p.crop)}
                  className="text-xs text-primary mt-1.5 hover:underline"
                >
                  {target ? 'Remove alert' : 'Set price alert'}
                </button>
              )}
            </Widget>
          );
        })}
      </div>
    </div>
  );
}