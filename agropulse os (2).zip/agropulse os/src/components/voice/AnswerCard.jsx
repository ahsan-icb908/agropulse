import { Volume2, AlertTriangle, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

const URGENCY = {
  low: { label: 'Low urgency', className: 'bg-emerald-500/10 text-emerald-700' },
  medium: { label: 'Medium urgency', className: 'bg-amber-500/10 text-amber-700' },
  high: { label: 'High urgency', className: 'bg-red-500/10 text-red-700' },
};

export default function AnswerCard({ answer, speaking, onReplay }) {
  const urgency = URGENCY[answer.urgency] || URGENCY.medium;

  return (
    <div className="space-y-3 rounded-xl border border-border bg-card p-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <Badge className={urgency.className}>
          {answer.urgency === 'high' && <AlertTriangle className="me-1 h-3 w-3" />}
          {urgency.label}
        </Badge>
        <Button variant="ghost" size="sm" onClick={onReplay} className="gap-1.5 text-primary">
          <Volume2 className={speaking ? 'h-4 w-4 animate-pulse' : 'h-4 w-4'} />
          دوبارہ سنیں
        </Button>
      </div>

      <p className="font-urdu text-end text-lg leading-loose" dir="rtl" lang="ur">
        {answer.answer_ur}
      </p>

      {answer.actions?.length > 0 && (
        <ol className="list-decimal space-y-1 ps-5 text-sm text-foreground/90" dir="rtl">
          {answer.actions.map((action) => (
            <li key={action} className="font-urdu leading-loose">{action}</li>
          ))}
        </ol>
      )}

      {answer.answer_en && (
        <div className="border-t border-border pt-3">
          <p className="text-[11px] uppercase tracking-wide text-muted-foreground">English</p>
          <p className="mt-1 text-sm text-muted-foreground">{answer.answer_en}</p>
        </div>
      )}

      <p className="flex items-start gap-1.5 text-[11px] text-muted-foreground">
        <Info className="mt-0.5 h-3 w-3 shrink-0" aria-hidden="true" />
        {answer.source}
      </p>
    </div>
  );
}