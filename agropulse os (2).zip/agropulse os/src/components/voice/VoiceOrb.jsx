import { Mic, MicOff, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

// Large, accessible Urdu voice control ("Bolo aur Pucho").
export default function VoiceOrb({ listening, thinking, disabled, onClick, label }) {
  return (
    <div className="flex flex-col items-center gap-3">
      <button
        type="button"
        onClick={onClick}
        disabled={disabled}
        aria-label={label}
        aria-pressed={listening}
        className={cn(
          'relative flex h-32 w-32 items-center justify-center rounded-full text-primary-foreground shadow-lg transition-transform',
          'bg-gradient-to-br from-primary to-accent hover:scale-[1.03] active:scale-95 disabled:opacity-60',
          listening && 'ring-8 ring-primary/20'
        )}
      >
        {listening && <span className="absolute inset-0 animate-ping rounded-full bg-primary/30" />}
        {thinking ? (
          <Loader2 className="h-10 w-10 animate-spin" />
        ) : listening ? (
          <MicOff className="h-10 w-10" />
        ) : (
          <Mic className="h-10 w-10" />
        )}
      </button>
      <p className="text-sm font-medium text-muted-foreground">{label}</p>
    </div>
  );
}