import { useMemo } from 'react';
import { Volume2, Square, ClipboardList, Store } from 'lucide-react';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/i18n/LanguageContext';
import { useCollection } from '@/hooks/useCollection';
import { useSpeech } from '@/hooks/useSpeech';
import { buildDailyBriefing } from '@/lib/voice/dailyBriefing';

export default function DailyBriefing() {
  const { lang } = useI18n();
  const { speak, stop, speaking, supported } = useSpeech();
  const { data: listings, loading: loadingListings } = useCollection('Listing', {
    query: { status: 'active' },
    sort: '-created_date',
    limit: 50,
  });
  const { data: tasks, loading: loadingTasks } = useCollection('Task', {
    query: { status: { $in: ['pending', 'in_progress'] } },
    sort: 'due_date',
    limit: 50,
  });

  const briefing = useMemo(
    () => buildDailyBriefing({ listings, tasks, lang }),
    [listings, tasks, lang]
  );

  const copy =
    lang === 'ur'
      ? {
          title: 'آج کی رپورٹ',
          sub: 'منڈی کی listings اور باقی کام — سنیں یا پڑھیں',
          listen: 'رپورٹ سنیں',
          stop: 'روکیں',
          loading: 'ریکارڈ لوڈ ہو رہے ہیں…',
          unsupported: 'اس براؤزر میں آواز دستیاب نہیں — رپورٹ پڑھ سکتے ہیں۔',
        }
      : {
          title: "Today's briefing",
          sub: "Market listings and open tasks — listen or read",
          listen: 'Listen to briefing',
          stop: 'Stop',
          loading: 'Loading records…',
          unsupported: 'Speech is not available in this browser — you can still read the briefing.',
        };

  const loading = loadingListings || loadingTasks;

  return (
    <Widget>
      <WidgetHeader title={copy.title} subtitle={copy.sub} icon={Volume2} />
      <WidgetBody className="space-y-3">
        {loading ? (
          <p className="text-sm text-muted-foreground">{copy.loading}</p>
        ) : (
          <>
            <div className="flex flex-wrap gap-2">
              <Button
                onClick={() => (speaking ? stop() : speak(briefing.replace(/\n/g, ' '), lang))}
                disabled={!supported}
                className="gap-2"
              >
                {speaking ? <Square className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
                {speaking ? copy.stop : copy.listen}
              </Button>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-2.5 py-1 text-xs text-muted-foreground">
                <Store className="h-3.5 w-3.5" /> {listings.length}
                <ClipboardList className="ms-1 h-3.5 w-3.5" /> {tasks.length}
              </span>
            </div>
            {!supported && <p className="text-xs text-amber-700">{copy.unsupported}</p>}
            <div
              className={`rounded-lg bg-muted/60 p-3 text-sm leading-relaxed whitespace-pre-line ${
                lang === 'ur' ? 'font-urdu text-end' : ''
              }`}
              dir={lang === 'ur' ? 'rtl' : 'ltr'}
              lang={lang}
            >
              {briefing}
            </div>
          </>
        )}
      </WidgetBody>
    </Widget>
  );
}