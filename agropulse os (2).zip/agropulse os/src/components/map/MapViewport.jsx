import { useEffect } from 'react';
import { useMap } from 'react-leaflet';

export default function MapViewport({ points, target }) {
  const map = useMap();
  useEffect(() => {
    let frame;
    const observer = new ResizeObserver(() => {
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => map.invalidateSize({ pan: false }));
    });
    observer.observe(map.getContainer());
    return () => { observer.disconnect(); cancelAnimationFrame(frame); };
  }, [map]);

  useEffect(() => {
    if (points.length) {
      map.invalidateSize({ pan: false });
      map.fitBounds(points, { padding: [32, 32], maxZoom: 14, animate: false });
    }
  }, [points, map]);

  useEffect(() => {
    if (target) map.flyTo(target.center, target.zoom || 13, { duration: 0.8 });
  }, [target, map]);
  return null;
}