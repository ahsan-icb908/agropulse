import { useMemo } from 'react';
import { useInfiniteQuery, useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';

export default function useMapRecords(entity, conditions = {}) {
  const query = { ...conditions, lat: { $gte: -90, $lte: 90 }, lng: { $gte: -180, $lte: 180 } };
  const records = useInfiniteQuery({
    queryKey: ['map-records', entity, query],
    initialPageParam: null,
    queryFn: ({ pageParam }) => base44.entities[entity].filter(query, {
      sort: '-created_date', limit: 50, ...(pageParam ? { cursor: pageParam } : {}),
    }),
    getNextPageParam: (page) => page.has_more ? page.next_cursor : undefined,
  });
  const total = useQuery({
    queryKey: ['map-count', entity, query],
    queryFn: () => base44.entities[entity].count(query),
  });
  const data = useMemo(() => records.data?.pages.flatMap((page) => page.items) || [], [records.data]);
  return {
    data, count: total.data, loading: records.isPending || total.isPending,
    error: records.error || total.error,
    hasMore: records.hasNextPage, loadingMore: records.isFetchingNextPage,
    loadMore: () => records.fetchNextPage(),
    reload: () => { records.refetch(); total.refetch(); },
  };
}