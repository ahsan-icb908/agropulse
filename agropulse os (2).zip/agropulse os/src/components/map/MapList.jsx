import { Widget } from '@/components/common/Widget';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/i18n/LanguageContext';
import { cn } from '@/lib/utils';

export default function MapList({ title, icon: Icon, tone, records, onPick, render, badge }) {
  const { lang } = useI18n();
  return (
    <Widget className="p-0">
      <div className="flex items-center gap-2 p-3 border-b border-border">
        <Icon className={cn('w-4 h-4', tone)} />
        <span className="font-semibold text-sm">{title}</span>
        <Badge variant="secondary" className="ms-auto text-[10px]">{records.count ?? '—'}</Badge>
      </div>
      <div className="max-h-52 overflow-y-auto scrollbar-thin">
        {records.loading ? <p role="status" className="p-4 text-xs text-muted-foreground">{lang === 'ur' ? 'مقامات لوڈ ہو رہے ہیں…' : 'Loading locations…'}</p> : records.error ? (
          <p role="alert" className="p-4 text-xs text-destructive">{lang === 'ur' ? 'مقامات لوڈ نہیں ہو سکے۔' : 'Locations could not be loaded.'}</p>
        ) : records.data.length === 0 ? (
          <p className="text-xs text-muted-foreground p-4 text-center">{lang === 'ur' ? 'ابھی کوئی محفوظ مقام نہیں۔' : 'No saved locations yet.'}</p>
        ) : records.data.map((item) => (
          <button key={item.id} onClick={() => onPick(item)} className="w-full flex items-center gap-3 px-3 py-2.5 text-start hover:bg-muted/50 transition-colors border-b border-border/60">
            {badge(item)}<div className="min-w-0 flex-1">{render(item)}</div>
          </button>
        ))}
      </div>
      {records.hasMore && <Button variant="ghost" className="w-full" disabled={records.loadingMore} onClick={records.loadMore}>{lang === 'ur' ? 'مزید دکھائیں' : 'Load more'}</Button>}
    </Widget>
  );
}