import { Link } from 'react-router-dom';
import { Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useI18n } from '@/i18n/LanguageContext';

export default function MapStatus({ records }) {
  const { lang } = useI18n();
  if (records.some((record) => record.loading)) return (
    <p role="status" className="flex items-center justify-center gap-2 py-4 text-sm text-muted-foreground">
      <Loader2 className="size-4 animate-spin" />{lang === 'ur' ? 'مقامات لوڈ ہو رہے ہیں…' : 'Loading saved locations…'}
    </p>
  );
  if (records.some((record) => record.error)) return (
    <div role="alert" className="flex flex-wrap items-center justify-center gap-3 py-4 text-sm text-destructive">
      <p>{lang === 'ur' ? 'محفوظ مقامات لوڈ نہیں ہو سکے۔ دوبارہ کوشش کریں۔' : 'Saved locations could not be loaded. Please try again.'}</p>
      <Button variant="outline" onClick={() => records.forEach((record) => record.reload())}>{lang === 'ur' ? 'دوبارہ کوشش کریں' : 'Try again'}</Button>
    </div>
  );
  if (records.some((record) => record.count > 0)) return null;
  return (
    <div className="space-y-3 py-4 text-center text-sm text-muted-foreground">
      <p>{lang === 'ur' ? 'نقشہ تیار ہے۔ پن دکھانے کے لیے فارم یا فیلڈ میں عرض بلد اور طول بلد شامل کریں۔' : 'The map is ready. No locations saved yet — add a farm or field with latitude and longitude to see it on the map.'}</p>
      <div className="flex items-center justify-center gap-2">
        <Button asChild variant="outline"><Link to="/farms">{lang === 'ur' ? 'فارم شامل کریں' : 'Add farm'}</Link></Button>
        <Button asChild variant="outline"><Link to="/fields">{lang === 'ur' ? 'فیلڈ شامل کریں' : 'Add field'}</Link></Button>
      </div>
    </div>
  );
}