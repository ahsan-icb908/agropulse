import { useMemo, useRef, useState } from 'react';
import * as XLSX from 'xlsx';
import { Upload, FileSpreadsheet, Loader2, CheckCircle2, AlertCircle, Download } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCollection } from '@/hooks/useCollection';
import { parseHarvestRows, buildHarvestRecords, templateCsv } from '@/lib/harvest/parseHarvestSheet';

const COPY = {
  en: {
    title: 'Bulk upload harvest records',
    sub: 'Upload an Excel (.xlsx) or CSV file of past harvests. Each row needs a field, crop, season and yield.',
    pick: 'Choose Excel or CSV file',
    hint: 'First sheet is read. Columns are matched by name: field_name, crop, season, yield_amount, yield_unit, harvest_date, area_hectares, notes.',
    defaultField: 'Field for rows without a field column',
    none: 'Not set',
    preview: 'ready to import',
    problems: 'rows will be skipped',
    import: 'Import records',
    importing: 'Importing…',
    template: 'Download CSV template',
    clear: 'Choose another file',
    done: 'Imported records',
    skipped: 'Skipped',
    empty: 'That file has no readable rows. Check that the first row holds the column names.',
    failed: 'The file could not be read. Save it as .xlsx or .csv and try again.',
    importFailed: 'The import stopped:',
  },
  ur: {
    title: 'فصل کی ریکارڈ بڑی تعداد میں اپلوڈ کریں',
    sub: 'پرانے فصل ریکارڈ کی ایکسل (.xlsx) یا سی ایس وی فائل اپلوڈ کریں۔ ہر قطار میں فیلڈ، فصل، سیزن اور پیداوار ضروری ہے۔',
    pick: 'ایکسل یا سی ایس وی فائل منتخب کریں',
    hint: 'پہلی شیٹ پڑھی جاتی ہے۔ کالم نام سے پہچانے جاتے ہیں: field_name, crop, season, yield_amount, yield_unit, harvest_date, area_hectares, notes۔',
    defaultField: 'اُن قطاروں کے لیے فیلڈ جن میں فیلڈ کالم نہیں',
    none: 'منتخب نہیں',
    preview: 'اپلوڈ کے لیے تیار',
    problems: 'قطاریں چھوڑ دی جائیں گی',
    import: 'ریکارڈ محفوظ کریں',
    importing: 'محفوظ ہو رہے ہیں…',
    template: 'سی ایس وی نمونہ ڈاؤن لوڈ کریں',
    clear: 'دوسری فائل منتخب کریں',
    done: 'ریکارڈ محفوظ ہوئے',
    skipped: 'چھوڑے گئے',
    empty: 'اس فائل میں کوئی قابلِ پڑھ قطار نہیں۔ دیکھیں کہ پہلی قطار میں کالم کے نام ہوں۔',
    failed: 'فائل پڑھی نہیں جا سکی۔ اسے .xlsx یا .csv میں محفوظ کر کے دوبارہ کوشش کریں۔',
    importFailed: 'اپلوڈ رک گیا:',
  },
};

export default function HarvestUploader({ lang = 'en', onImported }) {
  const copy = COPY[lang] || COPY.en;
  const { data: fields } = useCollection('Field', { sort: '-created_date', limit: 200 });
  const fileRef = useRef(null);
  const [defaultFieldId, setDefaultFieldId] = useState('');
  const [rows, setRows] = useState(null);
  const [fileName, setFileName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [result, setResult] = useState(null);

  const { records, errors } = useMemo(
    () => (rows ? buildHarvestRecords(rows, { fields, defaultFieldId }) : { records: [], errors: [] }),
    [rows, fields, defaultFieldId]
  );

  async function handleFile(file) {
    if (!file) return;
    setBusy(true);
    setError('');
    setResult(null);
    setRows(null);
    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: 'array', cellDates: true });
      const sheet = workbook.Sheets[workbook.SheetNames[0]];
      const parsed = parseHarvestRows(XLSX.utils.sheet_to_json(sheet, { defval: '' }));
      if (!parsed.length) {
        setError(copy.empty);
      } else {
        setFileName(file.name);
        setRows(parsed);
      }
    } catch {
      setError(copy.failed);
    } finally {
      setBusy(false);
    }
  }

  async function runImport() {
    if (!records.length) return;
    setBusy(true);
    setError('');
    try {
      for (let i = 0; i < records.length; i += 200) {
        await base44.entities.Harvest.bulkCreate(records.slice(i, i + 200));
      }
      setResult({ imported: records.length, skipped: errors.length });
      setRows(null);
      setFileName('');
      onImported?.();
    } catch (e) {
      setError(`${copy.importFailed} ${e?.message || ''}`);
    } finally {
      setBusy(false);
    }
  }

  function downloadTemplate() {
    const blob = new Blob([templateCsv()], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'harvest-template.csv';
    link.click();
    URL.revokeObjectURL(url);
  }

  return (
    <Widget>
      <WidgetHeader title={copy.title} subtitle={copy.sub} icon={FileSpreadsheet} />
      <WidgetBody className="space-y-4">
        <input
          ref={fileRef}
          type="file"
          accept=".csv,.xlsx,.xls,text/csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
          className="hidden"
          onChange={(e) => handleFile(e.target.files?.[0])}
        />

        <button
          onClick={() => fileRef.current?.click()}
          disabled={busy}
          className="w-full rounded-2xl border-2 border-dashed border-border hover:border-primary/50 hover:bg-primary/5 transition-colors py-8 flex flex-col items-center gap-2 text-muted-foreground disabled:opacity-60"
        >
          <span className="w-11 h-11 rounded-full bg-primary/10 text-primary flex items-center justify-center">
            {busy ? <Loader2 className="w-5 h-5 animate-spin" /> : <Upload className="w-5 h-5" />}
          </span>
          <span className="font-medium text-foreground">{fileName || copy.pick}</span>
          <span className="text-xs px-4 text-center">{copy.hint}</span>
        </button>

        <div>
          <Label>{copy.defaultField}</Label>
          <Select value={defaultFieldId || 'none'} onValueChange={(v) => setDefaultFieldId(v === 'none' ? '' : v)}>
            <SelectTrigger className="mt-1">
              <SelectValue placeholder={copy.none} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">{copy.none}</SelectItem>
              {fields.map((f) => (
                <SelectItem key={f.id} value={f.id}>
                  {f.name}
                  {f.farm_name ? ` · ${f.farm_name}` : ''}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        {error && (
          <div className="flex items-start gap-2 rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
            <AlertCircle className="w-4 h-4 mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {result && (
          <div className="flex items-start gap-2 rounded-lg bg-success/10 p-3 text-sm text-success">
            <CheckCircle2 className="w-4 h-4 mt-0.5 shrink-0" />
            <span>
              {copy.done}: <strong>{result.imported}</strong>
              {result.skipped > 0 && ` · ${copy.skipped}: ${result.skipped}`}
            </span>
          </div>
        )}

        {rows && (
          <div className="space-y-3">
            <div className="flex flex-wrap gap-2 text-xs">
              <span className="rounded-full bg-primary/10 px-2.5 py-1 font-medium text-primary">
                {records.length} {copy.preview}
              </span>
              {errors.length > 0 && (
                <span className="rounded-full bg-amber-500/15 px-2.5 py-1 font-medium text-amber-700">
                  {errors.length} {copy.problems}
                </span>
              )}
            </div>

            {records.length > 0 && (
              <div className="overflow-x-auto rounded-lg border border-border">
                <table className="w-full text-xs">
                  <thead className="bg-muted/60 text-muted-foreground">
                    <tr>
                      <th className="p-2 text-start">Field</th>
                      <th className="p-2 text-start">Crop</th>
                      <th className="p-2 text-start">Season</th>
                      <th className="p-2 text-end">Yield</th>
                      <th className="p-2 text-start">Date</th>
                    </tr>
                  </thead>
                  <tbody>
                    {records.slice(0, 5).map((r, i) => (
                      <tr key={i} className="border-t border-border/60">
                        <td className="p-2">{r.field_name}</td>
                        <td className="p-2">{r.crop}</td>
                        <td className="p-2">{r.season}</td>
                        <td className="p-2 text-end">
                          {r.yield_amount} {r.yield_unit}
                        </td>
                        <td className="p-2">{r.harvest_date || '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {errors.length > 0 && (
              <ul className="space-y-1 rounded-lg bg-amber-500/10 p-3 text-xs text-amber-800">
                {errors.slice(0, 5).map((e) => (
                  <li key={e.line}>
                    Row {e.line}: {e.reason}
                  </li>
                ))}
                {errors.length > 5 && <li>+ {errors.length - 5} more</li>}
              </ul>
            )}

            <div className="flex flex-wrap gap-2">
              <Button onClick={runImport} disabled={busy || !records.length} className="gap-2">
                {busy ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                {busy ? copy.importing : `${copy.import} (${records.length})`}
              </Button>
              <Button variant="outline" onClick={() => fileRef.current?.click()} disabled={busy}>
                {copy.clear}
              </Button>
            </div>
          </div>
        )}

        <Button variant="ghost" size="sm" onClick={downloadTemplate} className="gap-2 text-xs">
          <Download className="w-3.5 h-3.5" /> {copy.template}
        </Button>
      </WidgetBody>
    </Widget>
  );
}