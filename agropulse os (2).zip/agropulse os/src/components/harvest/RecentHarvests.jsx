import { useEffect } from 'react';
import { Loader2, Wheat } from 'lucide-react';
import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { useCollection } from '@/hooks/useCollection';
import moment from 'moment';

export default function RecentHarvests({ reloadKey = 0, lang = 'en' }) {
  const { data, loading, reload } = useCollection('Harvest', { sort: '-harvest_date', limit: 10 });

  useEffect(() => {
    reload();
  }, [reloadKey, reload]);

  const title = lang === 'ur' ? 'حالیہ محفوظ شدہ فصلیں' : 'Recent harvest records';
  const empty =
    lang === 'ur'
      ? 'ابھی کوئی فصل ریکارڈ نہیں۔ اوپر سے فائل اپلوڈ کریں۔'
      : 'No harvest records yet. Upload a file above to add them.';

  return (
    <Widget>
      <WidgetHeader title={title} icon={Wheat} />
      <WidgetBody>
        {loading ? (
          <div className="flex justify-center py-6">
            <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
          </div>
        ) : data.length === 0 ? (
          <p className="text-sm text-muted-foreground">{empty}</p>
        ) : (
          <ul className="divide-y divide-border/60">
            {data.map((h) => (
              <li key={h.id} className="flex items-center justify-between gap-3 py-2 text-sm">
                <div className="min-w-0">
                  <p className="truncate font-medium">
                    {h.crop} · {h.field_name || '—'}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">
                    {h.season}
                    {h.harvest_date ? ` · ${moment(h.harvest_date).format('D MMM YYYY')}` : ''}
                  </p>
                </div>
                <span className="shrink-0 font-semibold">
                  {h.yield_amount} {h.yield_unit || 'kg'}
                </span>
              </li>
            ))}
          </ul>
        )}
      </WidgetBody>
    </Widget>
  );
}