import { NavLink } from 'react-router-dom';
import { Sprout } from 'lucide-react';
import { NAV_ITEMS } from './navConfig';
import { useI18n } from '@/i18n/LanguageContext';
import { cn } from '@/lib/utils';

export default function Sidebar() {
  const { t } = useI18n();

  return (
    <aside className="hidden lg:flex flex-col w-64 shrink-0 bg-sidebar text-sidebar-foreground border-e border-sidebar-border">
      <div className="h-16 flex items-center gap-2.5 px-5 border-b border-sidebar-border">
        <div className="w-9 h-9 rounded-xl bg-sidebar-primary/15 ring-1 ring-sidebar-primary/30 flex items-center justify-center">
          <Sprout className="w-5 h-5 text-sidebar-primary" />
        </div>
        <div className="leading-tight">
          <p className="font-heading font-bold text-[15px] text-white">{t('app.name')}</p>
          <p className="text-[11px] text-sidebar-foreground/60">{t('app.tagline')}</p>
        </div>
      </div>

      <nav className="flex-1 overflow-y-auto scrollbar-thin px-3 py-4 space-y-1">
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              cn(
                'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors',
                isActive
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-sm'
                  : 'text-sidebar-foreground/75 hover:bg-sidebar-accent hover:text-sidebar-accent-foreground'
              )
            }
          >
            <item.icon className="w-[18px] h-[18px] shrink-0" />
            <span>{t(item.labelKey)}</span>
          </NavLink>
        ))}
      </nav>

      <div className="p-4 border-t border-sidebar-border text-[11px] text-sidebar-foreground/50">
        <p className="font-medium text-sidebar-foreground/70">Developed by</p>
        <p className="mt-0.5">Ahsan Safwan · XI-B Pre-Engg & team</p>
      </div>
    </aside>
  );
}