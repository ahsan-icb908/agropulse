import {
  LayoutDashboard,
  Sprout,
  Layers,
  Map as MapIcon,
  Sparkles,
  Leaf,
  CloudSun,
  Wheat,
  Users,
  BarChart3,
  LayoutGrid,
  Settings,
  Dna,
  FlaskConical,
  Youtube,
  FileText,
  HandCoins,
  Mic,
} from 'lucide-react';

// Single source of truth for primary navigation.
// SDGs, Community (civic reports) and Alerts are integrated capabilities —
// Alerts have NO dedicated page (shown in Overview, Map, Weather, Notifications).
export const NAV_ITEMS = [
  { to: '/', labelKey: 'nav.overview', icon: LayoutDashboard, end: true },
  { to: '/farms', labelKey: 'nav.farms', icon: Sprout },
  { to: '/fields', labelKey: 'nav.fields', icon: Layers },
  { to: '/harvest', labelKey: 'nav.harvest', icon: Wheat },
  { to: '/map', labelKey: 'nav.map', icon: MapIcon },
  { to: '/assistant', labelKey: 'nav.assistant', icon: Sparkles },
  { to: '/crop-scan', labelKey: 'nav.cropscan', icon: Leaf },
  { to: '/weather', labelKey: 'nav.weather', icon: CloudSun },
  { to: '/biology', labelKey: 'nav.biology', icon: Dna },
  { to: '/research', labelKey: 'nav.research', icon: FlaskConical },
  { to: '/mandi-connect', labelKey: 'nav.mandi', icon: HandCoins },
  { to: '/voice', labelKey: 'nav.voice', icon: Mic },
  { to: '/agro-vids', labelKey: 'nav.agrovids', icon: Youtube },
  { to: '/community', labelKey: 'nav.community', icon: Users },
  { to: '/analytics', labelKey: 'nav.analytics', icon: BarChart3 },
  { to: '/programs', labelKey: 'nav.programs', icon: LayoutGrid },
  { to: '/documentation', labelKey: 'nav.docs', icon: FileText },
  { to: '/settings', labelKey: 'nav.settings', icon: Settings },
];