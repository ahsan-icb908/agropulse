import { NavLink } from 'react-router-dom';
import { NAV_ITEMS } from './navConfig';
import { useI18n } from '@/i18n/LanguageContext';
import { cn } from '@/lib/utils';

// Bottom navigation for mobile — compact, most-used destinations.
export default function MobileNav() {
  const { t } = useI18n();
  const items = NAV_ITEMS.slice(0, 5);

  return (
    <nav className="lg:hidden fixed bottom-0 inset-x-0 z-30 bg-card/90 backdrop-blur border-t border-border flex">
      {items.map((item) => (
        <NavLink
          key={item.to}
          to={item.to}
          end={item.end}
          className={({ isActive }) =>
            cn(
              'flex-1 flex flex-col items-center gap-1 py-2.5 text-[10px] font-medium transition-colors',
              isActive ? 'text-primary' : 'text-muted-foreground'
            )
          }
        >
          <item.icon className="w-5 h-5" />
          <span className="truncate max-w-full px-1">{t(item.labelKey)}</span>
        </NavLink>
      ))}
    </nav>
  );
}