import { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import Topbar from './Topbar';
import MobileNav from './MobileNav';
import { Sheet, SheetContent } from '@/components/ui/sheet';
import { PageTransition } from '@/components/common/motion';
import { useAlertSync } from '@/hooks/useAlertSync';
import VoiceGuide from '@/components/common/VoiceGuide';

export default function AppLayout() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  useAlertSync();

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      <Sidebar />

      <Sheet open={mobileOpen} onOpenChange={setMobileOpen}>
        <SheetContent side="left" className="w-72 p-0 bg-sidebar">
          <Sidebar />
        </SheetContent>
      </Sheet>

      <div className="flex-1 flex flex-col min-w-0">
        <Topbar onOpenMobile={() => setMobileOpen(true)} />
        <main className="flex-1 overflow-y-auto scrollbar-thin pb-20 lg:pb-0">
          <PageTransition key={location.pathname}>
            <div className="mx-auto max-w-7xl px-4 sm:px-6 py-6">
              <Outlet />
            </div>
          </PageTransition>
        </main>
      </div>

      <MobileNav />
      <VoiceGuide />
    </div>
  );
}