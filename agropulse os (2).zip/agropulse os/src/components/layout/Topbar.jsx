import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Search, Languages, Menu, Sprout, WifiOff } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';
import ImpactStrip from '@/components/impact/ImpactStrip';

export default function Topbar({ onOpenMobile }) {
  const { t, lang, toggleLang } = useI18n();
  const navigate = useNavigate();
  const [online] = useState(() => navigator.onLine);
  const unread = 3; // sample until notifications entity is wired

  return (
    <header className="sticky top-0 z-30 bg-card/80 backdrop-blur border-b border-border">
      <div className="h-16 flex items-center gap-3 px-4 sm:px-6">
      <button
        onClick={onOpenMobile}
        className="lg:hidden p-2 -ms-1 rounded-lg hover:bg-muted"
        aria-label="Menu"
      >
        <Menu className="w-5 h-5" />
      </button>

      <div className="lg:hidden flex items-center gap-2 me-auto">
        <Sprout className="w-5 h-5 text-primary" />
        <span className="font-heading font-bold text-sm">{t('app.name')}</span>
      </div>

      <div className="relative hidden md:block w-72 lg:w-80">
        <Search className="w-4 h-4 absolute top-1/2 -translate-y-1/2 start-3 text-muted-foreground" />
        <Input
          placeholder={t('common.search')}
          className="ps-9 h-10 bg-muted/60 border-transparent focus-visible:bg-background"
        />
      </div>

      <div className="ms-auto flex items-center gap-1.5 sm:gap-2">
        {!online && (
          <Badge variant="outline" className="gap-1 text-warning border-warning/40 hidden sm:flex">
            <WifiOff className="w-3 h-3" /> {t('common.offline')}
          </Badge>
        )}

        <Button
          variant="ghost"
          size="sm"
          onClick={toggleLang}
          className="gap-1.5 font-medium"
          aria-label={t('lang.label')}
        >
          <Languages className="w-4 h-4" />
          <span className={cn(lang === 'ur' && 'font-urdu')}>{t('lang.toggle')}</span>
        </Button>

        <Button
          variant="ghost"
          size="icon"
          className="relative"
          onClick={() => navigate('/notifications')}
          aria-label={t('nav.notifications')}
        >
          <Bell className="w-5 h-5" />
          {unread > 0 && (
            <span className="absolute top-1 end-1 min-w-4 h-4 px-1 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center">
              {unread}
            </span>
          )}
        </Button>

        <button
          onClick={() => navigate('/settings')}
          className="w-9 h-9 rounded-full bg-primary/10 text-primary font-semibold text-sm flex items-center justify-center ring-1 ring-primary/20 hover:bg-primary/15 transition-colors"
          aria-label="Profile"
        >
          AS
        </button>
      </div>
      </div>
      <ImpactStrip />
    </header>
  );
}