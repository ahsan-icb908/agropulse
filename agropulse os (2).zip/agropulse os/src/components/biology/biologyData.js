// Content for the AgroPulse Biology Lab — the science-exhibition module.
// Every example is tied to a real farm situation so biology stays concrete.

// 1. Levels of biological organisation, from biosphere down to molecule.
export const ORGANIZATION = [
  { level: 'Biosphere', tint: '#0369a1', farm: 'Every life zone on Earth. Climate patterns formed here decide the sowing window for the whole district.' },
  { level: 'Biome', tint: '#0891b2', farm: 'The semi-arid plains of Punjab — a grassland biome now managed as cropland.' },
  { level: 'Ecosystem', tint: '#0d9488', farm: 'One farm: soil, water, air, crops, livestock and microbes, all exchanging energy and matter.' },
  { level: 'Community', tint: '#16a34a', farm: 'All populations in one field — wheat, weeds, aphids, ladybirds, earthworms, rhizobia.' },
  { level: 'Population', tint: '#65a30d', farm: 'Every aphid of one species feeding on a single plot of wheat.' },
  { level: 'Organism', tint: '#ca8a04', farm: 'One wheat plant — it takes in light, water and minerals, and returns oxygen and seed.' },
  { level: 'Organ system', tint: '#ea580c', farm: 'The shoot system (leaves and stem) above ground, the root system below.' },
  { level: 'Organ', tint: '#dc2626', farm: 'A leaf — the solar panel. The ear — the grain factory.' },
  { level: 'Tissue', tint: '#db2777', farm: 'Palisade mesophyll packed with chloroplasts; xylem and phloem running through the stem.' },
  { level: 'Cell', tint: '#9333ea', farm: 'A root hair cell absorbing nitrate, or a guard cell opening a stoma.' },
  { level: 'Organelle', tint: '#4f46e5', farm: 'Chloroplast for photosynthesis, mitochondrion for respiration, vacuole for water storage.' },
  { level: 'Molecule', tint: '#0f766e', farm: 'Chlorophyll capturing light, RuBisCO fixing CO₂, DNA carrying the variety’s traits.' },
];

// 2. Core physiological processes an agroecosystem runs on.
export const PROCESSES = [
  {
    name: 'Photosynthesis',
    tint: '#16a34a',
    equation: '6CO₂ + 6H₂O + light → C₆H₁₂O₆ + 6O₂',
    where: 'Chloroplast — thylakoid membranes (light reactions), stroma (Calvin cycle)',
    why: 'Builds the entire crop biomass. Yield is stored chemical energy, so anything limiting light, CO₂ or water limits the harvest.',
  },
  {
    name: 'Cellular respiration',
    tint: '#0d9488',
    equation: 'C₆H₁₂O₆ + 6O₂ → 6CO₂ + 6H₂O + energy (ATP)',
    where: 'Mitochondria of every living cell in the farm',
    why: 'Runs 24 hours a day. It powers nutrient uptake, growth and grain filling — and it continues after harvest inside the stored grain.',
  },
  {
    name: 'Transpiration',
    tint: '#0284c7',
    equation: 'Soil water → root → xylem → leaf → stoma → atmosphere',
    where: 'Stomata of the leaf, xylem of the stem',
    why: 'The cohesion–tension pull that lifts water and dissolved minerals metres upward, and the leaf’s own evaporative cooling.',
  },
  {
    name: 'Translocation',
    tint: '#7c3aed',
    equation: 'Sucrose source (leaf) → phloem → sink (grain, root, tuber)',
    where: 'Phloem sieve tubes',
    why: 'Moves the sugars made in leaves to where they are stored. This single process is what "grain filling" means in agronomy.',
  },
  {
    name: 'Mineral uptake',
    tint: '#ca8a04',
    equation: 'NO₃⁻, H₂PO₄⁻, K⁺, Mg²⁺, Ca²⁺ — absorbed against a gradient',
    where: 'Root hair cells, via active transport and ion exchange',
    why: 'Magnesium sits at the centre of every chlorophyll molecule. Nitrogen builds every protein. Deficiency shows first in the leaves.',
  },
  {
    name: 'Nitrogen fixation',
    tint: '#ea580c',
    equation: 'N₂ + 8H⁺ + 8e⁻ + 16ATP → 2NH₃ + H₂',
    where: 'Rhizobium in root nodules of legumes; free-living Azotobacter in soil',
    why: 'Converts inert atmospheric nitrogen into a form plants can use. Rotating a legume restores soil nitrogen without synthetic fertiliser.',
  },
  {
    name: 'Decomposition',
    tint: '#57534e',
    equation: 'Detritus → humus + inorganic ions (N, P, K, S)',
    where: 'Saprophytic fungi and bacteria in the litter layer and topsoil',
    why: 'Recycles nutrients locked in crop residue back into plant-available form and builds the organic matter that holds soil together.',
  },
];

// 3. Biogeochemical cycles that close the loop on a farm.
export const CYCLES = [
  {
    name: 'Carbon cycle',
    tint: '#0d9488',
    steps: ['Atmospheric CO₂', 'Photosynthesis into crop biomass', 'Respiration returns CO₂', 'Residue and roots enter soil', 'Decomposers form humus', 'Humus stores carbon for years'],
    note: 'Every tonne of soil organic carbon kept in the ground is carbon kept out of the atmosphere — the farm as a carbon sink.',
  },
  {
    name: 'Nitrogen cycle',
    tint: '#ea580c',
    steps: ['N₂ in air', 'Fixation by Rhizobium / Azotobacter', 'Ammonia → nitrite → nitrate (nitrification)', 'Nitrate absorbed by roots', 'Crop and residue consumed', 'Ammonification and denitrification', 'Leaching risk if surplus'],
    note: 'Surplus nitrate leaches into groundwater and waterways, causing eutrophication. The nitrogen balance tool tracks exactly this gap.',
  },
  {
    name: 'Water cycle',
    tint: '#0284c7',
    steps: ['Rainfall and canal supply', 'Infiltration into soil pores', 'Root absorption', 'Transpiration through stomata', 'Evaporation from soil surface', 'Condensation and return as rain'],
    note: 'Irrigation is only efficient when infiltration and transpiration are matched to the crop’s actual requirement.',
  },
  {
    name: 'Phosphorus cycle',
    tint: '#7c3aed',
    steps: ['Rock phosphate (no gas phase)', 'Weathering releases phosphate', 'Mycorrhizal fungi extend root reach', 'Plant uptake for ATP and DNA', 'Crop removal at harvest', 'Manure and compost return it'],
    note: 'Phosphorus does not cycle through the air, so it must be recycled through compost, manure and crop residue.',
  },
];

// 4. Soil as a living ecosystem.
export const SOIL_LIFE = [
  { name: 'Bacteria', tint: '#16a34a', role: 'Decompose residue; nitrifying species convert ammonia to nitrate; Rhizobium fixes nitrogen in legume nodules.' },
  { name: 'Fungi & mycorrhizae', tint: '#a16207', role: 'Break down tough cellulose and lignin. Mycorrhizal threads act as an extended root system, delivering phosphorus and water in exchange for sugar.' },
  { name: 'Actinomycetes', tint: '#0891b2', role: 'Give soil its earthy smell; break down chitin and complex organic matter; source of many antibiotics.' },
  { name: 'Protozoa & nematodes', tint: '#db2777', role: 'Graze on bacteria and release locked-up nitrogen in plant-available form. Most are beneficial; a few are plant parasites.' },
  { name: 'Earthworms', tint: '#92400e', role: 'Shred residue, mix organic matter into the profile, and leave castings rich in nutrients. Their burrows are drainage channels.' },
  { name: 'Arthropods', tint: '#4f46e5', role: 'Springtails and mites fragment litter; ground beetles and spiders prey on crop pests — free biological control.' },
  { name: 'Plant roots', tint: '#ca8a04', role: 'Release up to a third of their sugars into the rhizosphere to feed the microbes that, in turn, feed the plant.' },
];

// 5. Trophic levels of an agroecosystem — the food web behind integrated pest management.
export const TROPHIC_LEVELS = [
  { level: 'Producers', tint: '#16a34a', members: 'Wheat, maize, cotton, fodder crops, weeds', role: 'Capture solar energy and fix it into biomass. Everything above depends on this level.' },
  { level: 'Primary consumers', tint: '#ea580c', members: 'Aphids, stem borers, grasshoppers, whitefly, rodents', role: 'Herbivores. At high density these become the "pests" of agronomy.' },
  { level: 'Secondary consumers', tint: '#0284c7', members: 'Ladybird beetles, spiders, hoverfly larvae, parasitic wasps', role: 'Natural enemies. Their presence is the cheapest pest control available — protect them.' },
  { level: 'Tertiary consumers', tint: '#7c3aed', members: 'Insectivorous birds, bats, dragonflies, frogs', role: 'Top predators that keep herbivore outbreaks from building up.' },
  { level: 'Decomposers', tint: '#57534e', members: 'Fungi, bacteria, earthworms', role: 'Break down dead matter at every level and return nutrients to the soil. They close the cycle.' },
];

// 6. Plant growth — hormones and directional responses.
export const HORMONES = [
  { name: 'Auxin', tint: '#16a34a', effect: 'Cell elongation, phototropism, apical dominance' },
  { name: 'Gibberellin', tint: '#65a30d', effect: 'Stem elongation, seed germination, breaking dormancy' },
  { name: 'Cytokinin', tint: '#0d9488', effect: 'Cell division, delays leaf senescence' },
  { name: 'Abscisic acid', tint: '#ca8a04', effect: 'Closes stomata under drought, enforces seed dormancy' },
  { name: 'Ethylene', tint: '#ea580c', effect: 'Fruit ripening, leaf and flower abscission, stress response' },
];

export const TROPISMS = [
  { name: 'Phototropism', tint: '#ca8a04', how: 'Auxin redistributes to the shaded side, elongating those cells so the shoot bends toward light.' },
  { name: 'Gravitropism', tint: '#0891b2', how: 'Roots grow downward and shoots upward through statolith signalling — the reason a seed germinates the right way up.' },
  { name: 'Hydrotropism', tint: '#0284c7', how: 'Roots grow toward moisture, allowing a crop to find water in drying soil.' },
  { name: 'Thigmotropism', tint: '#7c3aed', how: 'Growth response to touch; supports lodging resistance in slender stems.' },
];

export const MERISTEMS = [
  { name: 'Apical meristem', where: 'Root and shoot tips', does: 'Primary growth — height and root depth. This is what "vegetative stage" measures.' },
  { name: 'Intercalary meristem', where: 'Base of the stem in grasses', does: 'Regrowth after grazing or mowing — why wheat and fodder recover so fast.' },
  { name: 'Lateral meristem', where: 'Cambium of woody species', does: 'Secondary growth in thickness; the source of timber and long-lived tree biomass.' },
];

// 7. Ecosystem services and the pressures on them.
export const SERVICES = [
  { name: 'Pollination', tint: '#ca8a04', detail: 'Insects and wind move pollen. Without it, fruiting crops yield little or nothing.' },
  { name: 'Pest regulation', tint: '#ea580c', detail: 'Natural enemies hold herbivore numbers down, reducing the need for chemical sprays.' },
  { name: 'Nutrient cycling', tint: '#16a34a', detail: 'Microbes convert residue and manure into plant-available nutrients.' },
  { name: 'Soil formation', tint: '#92400e', detail: 'Rock, roots and organisms build topsoil over decades — it cannot be replaced in a season.' },
  { name: 'Water regulation', tint: '#0284c7', detail: 'Organic soil holds water and filters it, recharging groundwater instead of shedding runoff.' },
  { name: 'Genetic diversity', tint: '#7c3aed', detail: 'Traditional and improved varieties carry the traits needed for drought, salt and disease resilience.' },
];

export const PRESSURES = [
  'Monoculture removes habitat for natural enemies and pollinators.',
  'Pesticide overuse kills beneficial insects along with pests and leaves residues.',
  'Continuous cropping and bare soil accelerate erosion and organic-matter loss.',
  'Excess nitrogen and phosphorus leach into groundwater and waterways.',
  'Groundwater extraction outpaces recharge, lowering the water table.',
];

// 8. Concept → app module → how the number is obtained.
export const APP_MAPPING = [
  { concept: 'Organism & organ system', module: 'Farms — Fields', kind: 'measured', detail: 'Each field records crop, area, sowing and harvest dates, so one organism’s environment is described as data.' },
  { concept: 'Growth & development', module: 'Growth Stage Tracker', kind: 'measured', detail: 'Nine stages from land preparation to harvest, logged against the field with a dated history per crop season.' },
  { concept: 'Photosynthesis & translocation', module: 'Harvest log', kind: 'measured', detail: 'Yield per field and season is the end product of light capture and grain filling, recorded then totalled.' },
  { concept: 'Soil ecology & nutrient cycles', module: 'Nitrogen Balance, Composting', kind: 'estimated', detail: 'Inputs, crop uptake and residue returned are combined into a soil-nitrogen balance; compost batches track decomposition.' },
  { concept: 'Water relations & transpiration', module: 'Irrigation Manager', kind: 'estimated', detail: 'Crop water requirement is calculated from weather and growth stage to cut runoff and groundwater draw.' },
  { concept: 'Pathogens & plant disease', module: 'Crop Scan', kind: 'estimated', detail: 'Symptoms and photographs are analysed for likely causes, with expert review recommended when confidence is low.' },
  { concept: 'Population dynamics of pests', module: 'Pesticide Advisory', kind: 'measured', detail: 'Economic thresholds and eco-friendly dosage guidance, favouring biological control over blanket spraying.' },
  { concept: 'Ecosystem & food web', module: 'Alerts, Map, Community', kind: 'measured', detail: 'Hazard events, their location and community reports are mapped so pressure on one part of the system is visible.' },
  { concept: 'Biodiversity & ecosystem services', module: 'SDG Explorer, Analytics', kind: 'measured', detail: 'Activity records are grouped against SDG indicators, with measured, estimated and missing values labelled distinctly.' },
];

// 9. Suggested live demonstration order for exhibition judges.
export const EXHIBITION_STEPS = [
  { step: 1, title: 'Start with the organism', text: 'Open Fields and show one plot: crop, area, sowing date, soil pH and moisture. This is a population of one species in a defined space.' },
  { step: 2, title: 'Show it developing', text: 'Open the Growth Stage Tracker and record a new stage. Point out that the change is dated and kept in that season’s history — growth is a process, not a snapshot.' },
  { step: 3, title: 'Follow the energy', text: 'Move to a harvest record. Yield is captured solar energy from photosynthesis, moved by translocation into grain.' },
  { step: 4, title: 'Close the nutrient loop', text: 'Show the Composting tracker and Nitrogen Balance. Residue becomes humus and available nitrogen instead of being burnt.' },
  { step: 5, title: 'Balance water', text: 'Open the Irrigation Manager and compare crop water requirement against the logged application.' },
  { step: 6, title: 'Defend the crop', text: 'Run a Crop Scan on a diseased leaf, then open Pesticide Advisory to show threshold-based, eco-friendly dosage instead of blanket spraying.' },
  { step: 7, title: 'Zoom out to the ecosystem', text: 'Open the Map with alerts and community reports — hazards crossing the boundary between the farm and the wider ecosystem.' },
  { step: 8, title: 'Report honestly', text: 'Finish on the SDG Explorer. Measured, estimated and missing indicators are labelled — say clearly which is which.' },
];

export const KEY_TERMS = [
  { term: 'Agroecosystem', def: 'A managed ecosystem where humans direct energy and nutrient flow to produce food.' },
  { term: 'Biogeochemical cycle', def: 'The pathway by which an element moves between living organisms and the physical environment.' },
  { term: 'Rhizosphere', def: 'The narrow zone of soil immediately around a root, densely populated by microorganisms.' },
  { term: 'Mycorrhiza', def: 'A mutualism between a fungus and a plant root that improves nutrient and water uptake.' },
  { term: 'Trophic level', def: 'A feeding position in a food chain; only about 10% of energy passes to the next level.' },
  { term: 'Meristem', def: 'A region of undifferentiated, dividing cells where plant growth occurs.' },
  { term: 'Tropism', def: 'A directional growth response to an external stimulus such as light, gravity or water.' },
  { term: 'Ecosystem service', def: 'A benefit people obtain from ecosystem processes, such as pollination or nutrient cycling.' },
];