import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { RefreshCw, ArrowDown } from 'lucide-react';
import { CYCLES } from './biologyData';

export default function CycleGrid() {
  return (
    <div className="space-y-4">
      <Widget>
        <WidgetHeader title="Biogeochemical cycles" subtitle="Matter is never created or destroyed on a farm — it only changes form" icon={RefreshCw} />
        <WidgetBody className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {CYCLES.map((c) => (
            <div key={c.name} className="rounded-xl border border-border/70 p-4">
              <div className="flex items-center gap-2 mb-3">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: c.tint }} />
                <p className="font-heading font-semibold text-sm">{c.name}</p>
              </div>
              <ol className="space-y-1.5">
                {c.steps.map((s, i) => (
                  <li key={s} className="flex items-start gap-2">
                    <span
                      className="w-5 h-5 rounded-md text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5"
                      style={{ background: `${c.tint}1f`, color: c.tint }}
                    >
                      {i + 1}
                    </span>
                    <span className="text-xs text-foreground/85 leading-relaxed">{s}</span>
                  </li>
                ))}
              </ol>
              <div className="mt-3 pt-3 border-t border-border/70 flex items-start gap-2">
                <ArrowDown className="w-3.5 h-3.5 text-primary shrink-0 mt-0.5" />
                <p className="text-[11px] text-muted-foreground leading-relaxed">{c.note}</p>
              </div>
            </div>
          ))}
        </WidgetBody>
      </Widget>
    </div>
  );
}