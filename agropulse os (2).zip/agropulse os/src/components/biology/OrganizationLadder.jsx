import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Layers } from 'lucide-react';
import { ORGANIZATION } from './biologyData';

export default function OrganizationLadder() {
  return (
    <Widget>
      <WidgetHeader title="Levels of biological organisation" subtitle="Biosphere down to molecule — each level shown with a real farm example" icon={Layers} />
      <WidgetBody className="space-y-2">
        {ORGANIZATION.map((o, i) => (
          <div key={o.level} className="flex items-start gap-3 rounded-xl border border-border/70 p-3">
            <span
              className="w-7 h-7 rounded-lg flex items-center justify-center text-[11px] font-bold text-white shrink-0"
              style={{ background: o.tint }}
            >
              {i + 1}
            </span>
            <div className="min-w-0">
              <p className="font-heading font-semibold text-sm">{o.level}</p>
              <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">{o.farm}</p>
            </div>
          </div>
        ))}
        <p className="text-[11px] text-muted-foreground/70 pt-1">
          Order matters: each level is built from the one below it, and each level above constrains what the lower one can do.
        </p>
      </WidgetBody>
    </Widget>
  );
}