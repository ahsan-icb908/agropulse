import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { TrendingUp, Compass, Scissors } from 'lucide-react';
import { HORMONES, TROPISMS, MERISTEMS } from './biologyData';

export default function GrowthBiology() {
  return (
    <div className="space-y-4">
      <Widget>
        <WidgetHeader title="Where growth actually happens" subtitle="Meristems are the dividing tissue behind every change in growth stage" icon={Scissors} />
        <WidgetBody className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {MERISTEMS.map((m) => (
            <div key={m.name} className="rounded-xl border border-border/70 p-4">
              <p className="font-heading font-semibold text-sm">{m.name}</p>
              <p className="text-[11px] text-muted-foreground mt-0.5">{m.where}</p>
              <p className="text-xs text-muted-foreground leading-relaxed mt-2">{m.does}</p>
            </div>
          ))}
        </WidgetBody>
      </Widget>

      <Widget>
        <WidgetHeader title="Plant growth regulators" subtitle="Chemical signals that switch development on and off" icon={TrendingUp} />
        <WidgetBody className="space-y-2">
          {HORMONES.map((h) => (
            <div key={h.name} className="flex items-center justify-between gap-3 rounded-xl border border-border/70 p-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: h.tint }} />
                <p className="text-sm font-medium">{h.name}</p>
              </div>
              <p className="text-[11px] text-muted-foreground text-end max-w-[58%]">{h.effect}</p>
            </div>
          ))}
        </WidgetBody>
      </Widget>

      <Widget>
        <WidgetHeader title="Tropisms" subtitle="Directional growth responses — how a plant answers its environment" icon={Compass} />
        <WidgetBody className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {TROPISMS.map((t) => (
            <div key={t.name} className="rounded-xl border border-border/70 p-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: t.tint }} />
                <p className="font-heading font-semibold text-sm">{t.name}</p>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed mt-2">{t.how}</p>
            </div>
          ))}
        </WidgetBody>
      </Widget>
    </div>
  );
}