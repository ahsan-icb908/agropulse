import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Link2, Award, BookOpen } from 'lucide-react';
import { APP_MAPPING, EXHIBITION_STEPS, KEY_TERMS, SERVICES, PRESSURES } from './biologyData';

const KIND_STYLE = {
  measured: 'bg-emerald-500/15 text-emerald-700 border-emerald-500/30',
  estimated: 'bg-amber-500/15 text-amber-700 border-amber-500/30',
  missing: 'bg-muted text-muted-foreground border-border',
};

export default function AppMapping() {
  return (
    <div className="space-y-4">
      <Widget>
        <WidgetHeader title="Biology → AgroPulse module" subtitle="Every module in this app measures one part of the agroecosystem" icon={Link2} />
        <WidgetBody className="p-0 sm:p-0">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="ps-4">Biological concept</TableHead>
                  <TableHead>App module</TableHead>
                  <TableHead>Data basis</TableHead>
                  <TableHead className="pe-4">What is recorded</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {APP_MAPPING.map((m) => (
                  <TableRow key={m.concept}>
                    <TableCell className="ps-4 font-medium text-sm align-top">{m.concept}</TableCell>
                    <TableCell className="text-sm align-top">{m.module}</TableCell>
                    <TableCell className="align-top">
                      <Badge variant="outline" className={`text-[10px] capitalize ${KIND_STYLE[m.kind]}`}>{m.kind}</Badge>
                    </TableCell>
                    <TableCell className="pe-4 text-xs text-muted-foreground align-top">{m.detail}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </WidgetBody>
      </Widget>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Widget>
          <WidgetHeader title="Ecosystem services the farm depends on" subtitle="What a functioning agroecosystem provides for free" icon={BookOpen} />
          <WidgetBody className="space-y-2">
            {SERVICES.map((s) => (
              <div key={s.name} className="flex items-start gap-2.5 rounded-xl border border-border/70 p-3">
                <span className="w-2.5 h-2.5 rounded-full shrink-0 mt-1.5" style={{ background: s.tint }} />
                <div className="min-w-0">
                  <p className="text-sm font-medium">{s.name}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">{s.detail}</p>
                </div>
              </div>
            ))}
            <div className="rounded-xl bg-destructive/5 border border-destructive/20 p-3 mt-1">
              <p className="text-xs font-semibold text-destructive mb-1.5">Pressures on these services</p>
              <ul className="space-y-1">
                {PRESSURES.map((p) => (
                  <li key={p} className="text-[11px] text-muted-foreground leading-relaxed flex gap-2">
                    <span className="text-destructive/60">—</span>
                    {p}
                  </li>
                ))}
              </ul>
            </div>
          </WidgetBody>
        </Widget>

        <Widget>
          <WidgetHeader title="Live demonstration order" subtitle="A suggested walkthrough for exhibition judges" icon={Award} />
          <WidgetBody className="space-y-2">
            {EXHIBITION_STEPS.map((s) => (
              <div key={s.step} className="flex items-start gap-3 rounded-xl border border-border/70 p-3">
                <span className="w-6 h-6 rounded-lg bg-primary/10 text-primary flex items-center justify-center text-[11px] font-bold shrink-0">
                  {s.step}
                </span>
                <div className="min-w-0">
                  <p className="text-sm font-medium">{s.title}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">{s.text}</p>
                </div>
              </div>
            ))}
          </WidgetBody>
        </Widget>
      </div>

      <Widget>
        <WidgetHeader title="Key terms" subtitle="Definitions to have ready during the demonstration" icon={BookOpen} />
        <WidgetBody className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {KEY_TERMS.map((k) => (
            <div key={k.term} className="rounded-xl border border-border/70 p-3">
              <p className="text-sm font-heading font-semibold">{k.term}</p>
              <p className="text-xs text-muted-foreground leading-relaxed mt-1">{k.def}</p>
            </div>
          ))}
        </WidgetBody>
      </Widget>
    </div>
  );
}