import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Sprout, Network } from 'lucide-react';
import { SOIL_LIFE, TROPHIC_LEVELS } from './biologyData';

export default function SoilAndWeb() {
  return (
    <div className="space-y-4">
      <Widget>
        <WidgetHeader title="Soil is not dirt — it is a living ecosystem" subtitle="A single teaspoon of healthy topsoil can hold millions of organisms" icon={Sprout} />
        <WidgetBody className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {SOIL_LIFE.map((s) => (
            <div key={s.name} className="rounded-xl border border-border/70 p-4">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: s.tint }} />
                <p className="font-heading font-semibold text-sm">{s.name}</p>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed mt-2">{s.role}</p>
            </div>
          ))}
        </WidgetBody>
      </Widget>

      <Widget>
        <WidgetHeader title="Food web & trophic levels" subtitle="Energy passes upward through the farm’s feeding levels" icon={Network} />
        <WidgetBody className="space-y-3">
          {TROPHIC_LEVELS.map((t, i) => (
            <div key={t.level} className="rounded-xl border border-border/70 p-4">
              <div className="flex items-start gap-3">
                <span
                  className="w-9 h-9 rounded-xl flex items-center justify-center font-heading font-bold text-xs text-white shrink-0"
                  style={{ background: t.tint }}
                >
                  T{i + 1}
                </span>
                <div className="min-w-0">
                  <p className="font-heading font-semibold text-sm">{t.level}</p>
                  <p className="text-[11px] text-muted-foreground mt-0.5">{t.members}</p>
                  <p className="text-xs text-muted-foreground leading-relaxed mt-1.5">{t.role}</p>
                </div>
              </div>
            </div>
          ))}
          <p className="text-[11px] text-muted-foreground/70 bg-muted/50 rounded-lg p-3">
            Only about 10% of the energy at one trophic level reaches the next — the rest is lost as heat through respiration. That is why
            a food chain is short, and why spraying a field also removes the predators that would have kept pests in check for free.
          </p>
        </WidgetBody>
      </Widget>
    </div>
  );
}