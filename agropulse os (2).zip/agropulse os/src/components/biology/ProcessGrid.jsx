import { Widget, WidgetHeader, WidgetBody } from '@/components/common/Widget';
import { Atom } from 'lucide-react';
import { PROCESSES } from './biologyData';

export default function ProcessGrid() {
  return (
    <Widget>
      <WidgetHeader title="Core physiological processes" subtitle="The reactions that turn sunlight, water and minerals into a harvest" icon={Atom} />
      <WidgetBody className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {PROCESSES.map((p) => (
          <div key={p.name} className="rounded-xl border border-border/70 p-4">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: p.tint }} />
              <p className="font-heading font-semibold text-sm">{p.name}</p>
            </div>
            <p className="mt-2 font-mono text-[11px] leading-relaxed rounded-lg bg-muted/60 px-2.5 py-2 break-words">{p.equation}</p>
            <p className="text-[11px] text-muted-foreground mt-2"><span className="font-medium text-foreground/80">Where: </span>{p.where}</p>
            <p className="text-xs text-muted-foreground leading-relaxed mt-1.5">{p.why}</p>
          </div>
        ))}
      </WidgetBody>
    </Widget>
  );
}