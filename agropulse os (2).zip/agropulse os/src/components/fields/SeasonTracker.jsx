import { useState } from 'react';
import { Loader2, CalendarRange, Plus, Check, History } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import GrowthStageBadge, { GROWTH_STAGES, stageInfo, stageProgress } from './GrowthStageBadge';

function formatDate(value) {
  if (!value) return '';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '';
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: 'numeric' });
}

// What each stage means biologically — ties the tracker to plant development.
export const STAGE_NOTES = {
  land_prep: 'Soil is prepared — ploughing, levelling and organic matter incorporated. No living crop yet.',
  sown: 'Seed is placed in the soil. Germination begins once moisture and temperature are suitable.',
  germination: 'Radicle and plumule emerge. The seedling switches from seed reserves to its own photosynthesis.',
  tillering: 'Intercalary meristems produce side shoots. Leaf area — and light capture — rises quickly.',
  vegetative: 'Rapid cell division and elongation build the canopy that will power final yield.',
  flowering: 'Anthesis and pollination. This is the stage most sensitive to heat and water stress.',
  grain_filling: 'Translocation moves sucrose from leaves into the grain, fixing the final yield.',
  mature: 'Grain hardens and moisture falls as the leaves senesce.',
  harvested: 'Crop removed. Residue is returned as organic matter, composted, or burned.',
};

function SeasonForm({ field, onCreate }) {
  const [form, setForm] = useState({ season_label: '', crop: field.crop || '', sowing_date: '' });
  const [saving, setSaving] = useState(false);

  async function submit() {
    if (!form.season_label.trim()) return;
    setSaving(true);
    try {
      await onCreate(form);
      setForm({ season_label: '', crop: field.crop || '', sowing_date: '' });
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="rounded-xl border border-dashed border-border p-4 space-y-3">
      <p className="text-sm font-medium">Start a crop season for this field</p>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <Label className="text-xs">Season *</Label>
          <Input className="mt-1" placeholder="Rabi 2025" value={form.season_label} onChange={(e) => setForm({ ...form, season_label: e.target.value })} />
        </div>
        <div>
          <Label className="text-xs">Crop</Label>
          <Input className="mt-1" placeholder="Wheat" value={form.crop} onChange={(e) => setForm({ ...form, crop: e.target.value })} />
        </div>
        <div>
          <Label className="text-xs">Sowing date</Label>
          <Input className="mt-1" type="date" value={form.sowing_date} onChange={(e) => setForm({ ...form, sowing_date: e.target.value })} />
        </div>
      </div>
      <Button size="sm" className="gap-1.5" onClick={submit} disabled={saving || !form.season_label.trim()}>
        {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Plus className="w-3.5 h-3.5" />} Create season
      </Button>
    </div>
  );
}

export default function SeasonTracker({ field, seasons, onCreateSeason, onRecordStage }) {
  const [selectedId, setSelectedId] = useState(seasons[0]?.id || null);
  const [stage, setStage] = useState('');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);

  const season = seasons.find((s) => s.id === selectedId) || seasons[0] || null;

  if (seasons.length === 0) {
    return <SeasonForm field={field} onCreate={onCreateSeason} />;
  }

  const current = season.current_stage || field.growth_stage || 'land_prep';
  const info = stageInfo(current);
  const progress = stageProgress(current);
  const history = [...(season.stage_history || [])].reverse();

  async function record() {
    if (!stage) return;
    setSaving(true);
    try {
      await onRecordStage(season, stage, note);
      setStage('');
      setNote('');
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4">
      {/* Season switcher */}
      <div className="flex flex-wrap items-center gap-2">
        {seasons.map((s) => (
          <button
            key={s.id}
            onClick={() => setSelectedId(s.id)}
            className={`rounded-full px-3 py-1.5 text-xs font-medium border transition-colors ${
              s.id === season.id ? 'bg-primary text-primary-foreground border-primary' : 'border-border hover:bg-muted'
            }`}
          >
            {s.season_label}
          </button>
        ))}
        <SeasonAdder field={field} onCreate={onCreateSeason} />
      </div>

      {/* Current stage */}
      <div className="rounded-xl border border-border p-4">
        <div className="flex items-center justify-between gap-3">
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground">Current stage · {season.season_label}{season.crop ? ` · ${season.crop}` : ''}</p>
            <div className="mt-2"><GrowthStageBadge stage={current} /></div>
          </div>
          <div className="text-end shrink-0">
            <p className="text-2xl font-heading font-bold">{progress}%</p>
            <p className="text-[10px] text-muted-foreground">of season</p>
          </div>
        </div>

        <div className="h-2 rounded-full bg-muted overflow-hidden mt-3">
          <div className="h-full rounded-full transition-all duration-300" style={{ width: `${progress}%`, background: info.color }} />
        </div>

        {/* Stage stepper */}
        <div className="flex items-center gap-0.5 mt-3 overflow-x-auto scrollbar-thin pb-1">
          {GROWTH_STAGES.map((s, i) => (
            <div key={s.key} className="flex items-center shrink-0">
              <span
                className={`w-2 h-2 rounded-full ${i <= info.step ? '' : 'bg-muted-foreground/30'}`}
                style={i <= info.step ? { background: s.color } : {}}
                title={s.label}
              />
              {i < GROWTH_STAGES.length - 1 && <span className={`w-2.5 h-px ${i < info.step ? 'bg-foreground/30' : 'bg-muted-foreground/20'}`} />}
            </div>
          ))}
        </div>

        <p className="text-xs text-muted-foreground leading-relaxed mt-3">{STAGE_NOTES[current]}</p>
      </div>

      {/* Manual stage update */}
      <div className="rounded-xl border border-border p-4 space-y-3">
        <p className="text-sm font-medium">Record a new stage</p>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div>
            <Label className="text-xs">Stage</Label>
            <Select value={stage} onValueChange={setStage}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select stage" /></SelectTrigger>
              <SelectContent>
                {GROWTH_STAGES.map((s) => <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Note (optional)</Label>
            <Textarea rows={1} className="mt-1 min-h-9" placeholder="Observed leaf rust, applied fungicide…" value={note} onChange={(e) => setNote(e.target.value)} />
          </div>
        </div>
        <Button size="sm" className="gap-1.5" onClick={record} disabled={saving || !stage}>
          {saving ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Check className="w-3.5 h-3.5" />} Save to season history
        </Button>
      </div>

      {/* History */}
      <div className="rounded-xl border border-border p-4">
        <div className="flex items-center gap-2 mb-3">
          <History className="w-4 h-4 text-primary" />
          <p className="text-sm font-medium">Season history</p>
          <Badge variant="secondary" className="text-[10px]">{history.length} recorded</Badge>
        </div>
        {history.length === 0 ? (
          <p className="text-xs text-muted-foreground">No stage changes recorded yet for this season.</p>
        ) : (
          <ol className="relative space-y-3.5 ps-6">
            <span className="absolute start-[7px] top-2 bottom-2 w-px bg-border" />
            {history.map((h, i) => {
              const hi = stageInfo(h.stage);
              return (
                <li key={`${h.at}-${i}`} className="relative">
                  <span className="absolute -start-[17px] top-1 w-3 h-3 rounded-full ring-4 ring-background" style={{ background: hi.color }} />
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-sm font-medium">{hi.label}</span>
                    <span className="text-[11px] text-muted-foreground">{formatDate(h.at)}</span>
                  </div>
                  {h.note && <p className="text-xs text-muted-foreground mt-0.5">{h.note}</p>}
                </li>
              );
            })}
          </ol>
        )}
      </div>

      {season.sowing_date && (
        <p className="text-[11px] text-muted-foreground/80 flex items-center gap-1.5">
          <CalendarRange className="w-3 h-3" /> Sown {formatDate(season.sowing_date)}
        </p>
      )}
    </div>
  );
}

function SeasonAdder({ field, onCreate }) {
  const [open, setOpen] = useState(false);
  if (!open) {
    return (
      <button onClick={() => setOpen(true)} className="rounded-full px-3 py-1.5 text-xs font-medium border border-dashed border-border text-muted-foreground hover:bg-muted transition-colors">
        + New season
      </button>
    );
  }
  return <SeasonForm field={field} onCreate={async (d) => { await onCreate(d); setOpen(false); }} />;
}