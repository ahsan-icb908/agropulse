import moment from 'moment';
import { CalendarRange, ArrowRight } from 'lucide-react';
import { Widget } from '@/components/common/Widget';
import { Badge } from '@/components/ui/badge';
import GrowthStageBadge, { GROWTH_STAGES, stageInfo, stageProgress } from './GrowthStageBadge';

// Timeline view: where each field's crop sits in its season right now.
export default function GrowthTimeline({ fields, seasons = [] }) {
  const seasonFor = (fieldId) => seasons.find((s) => s.field_id === fieldId && s.status === 'active');

  return (
    <div className="space-y-3">
      {fields.map((field) => (
        <TimelineRow key={field.id} field={field} season={seasonFor(field.id)} />
      ))}
    </div>
  );
}

function TimelineRow({ field, season }) {
  const current = stageInfo(field.growth_stage || season?.current_stage);
  const progress = stageProgress(current.key);
  const next = GROWTH_STAGES[current.step + 1];
  const sowing = season?.sowing_date || field.sowing_date;
  const days = sowing ? Math.max(0, moment().diff(moment(sowing), 'days')) : null;
  const history = season?.stage_history || [];
  const dateFor = (stageKey) => {
    const hit = [...history].reverse().find((h) => h.stage === stageKey);
    return hit?.at ? moment(hit.at).format('D MMM') : null;
  };

  return (
    <Widget className="p-4">
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="font-heading font-semibold truncate">{field.name}</p>
          <p className="text-xs text-muted-foreground truncate">
            {field.farm_name || '—'}
            {field.crop ? ` · ${field.crop}` : ''}
            {season?.season_label ? ` · ${season.season_label}` : ''}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <GrowthStageBadge stage={current.key} />
          {days !== null && (
            <Badge variant="outline" className="text-xs gap-1">
              <CalendarRange className="h-3 w-3" /> Day {days + 1}
            </Badge>
          )}
        </div>
      </div>

      <div className="mt-4">
        <div className="flex items-center">
          {GROWTH_STAGES.map((stage, i) => {
            const done = i <= current.step;
            return (
              <div key={stage.key} className="flex flex-1 items-center last:flex-none">
                <span
                  className={`h-2.5 w-2.5 shrink-0 rounded-full ${done ? '' : 'bg-muted-foreground/25'}`}
                  style={done ? { background: stage.color } : undefined}
                  title={`${stage.label}${dateFor(stage.key) ? ` · ${dateFor(stage.key)}` : ''}`}
                />
                {i < GROWTH_STAGES.length - 1 && (
                  <span
                    className={`h-0.5 flex-1 ${i < current.step ? 'bg-foreground/30' : 'bg-muted-foreground/20'}`}
                  />
                )}
              </div>
            );
          })}
        </div>
        <div className="mt-1.5 flex items-center justify-between text-[10px] text-muted-foreground">
          <span>{GROWTH_STAGES[0].label}</span>
          <span className="font-semibold text-foreground">
            {current.label} · {progress}%
          </span>
          <span>{GROWTH_STAGES[GROWTH_STAGES.length - 1].label}</span>
        </div>
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
        {next ? (
          <span className="inline-flex items-center gap-1">
            <ArrowRight className="h-3 w-3" /> Next: {next.label}
          </span>
        ) : (
          <span>Season complete</span>
        )}
        {dateFor(current.key) && <span>Reached {dateFor(current.key)}</span>}
        {!season && <span>No active season — stage set manually</span>}
      </div>
    </Widget>
  );
}