import { cn } from '@/lib/utils';

export const GROWTH_STAGES = [
  { key: 'land_prep', label: 'Land Prep', color: '#a16207', step: 0 },
  { key: 'sown', label: 'Sown', color: '#0284c7', step: 1 },
  { key: 'germination', label: 'Germination', color: '#06b6d4', step: 2 },
  { key: 'tillering', label: 'Tillering', color: '#14b8a6', step: 3 },
  { key: 'vegetative', label: 'Vegetative', color: '#16a34a', step: 4 },
  { key: 'flowering', label: 'Flowering', color: '#84cc16', step: 5 },
  { key: 'grain_filling', label: 'Grain Filling', color: '#eab308', step: 6 },
  { key: 'mature', label: 'Mature', color: '#f97316', step: 7 },
  { key: 'harvested', label: 'Harvested', color: '#64748b', step: 8 },
];

export function stageInfo(key) {
  return GROWTH_STAGES.find((s) => s.key === key) || GROWTH_STAGES[0];
}

export function stageProgress(key) {
  const info = stageInfo(key);
  return Math.round((info.step / (GROWTH_STAGES.length - 1)) * 100);
}

export default function GrowthStageBadge({ stage, className }) {
  const info = stageInfo(stage);
  return (
    <span
      className={cn('inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium', className)}
      style={{ background: `${info.color}1a`, color: info.color }}
    >
      <span className="w-1.5 h-1.5 rounded-full" style={{ background: info.color }} />
      {info.label}
    </span>
  );
}