import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Sprout, MapPin } from 'lucide-react';
import SeasonTracker from './SeasonTracker';

export default function FieldDetailDialog({ field, seasons, onCreateSeason, onRecordStage, onClose }) {
  if (!field) return null;

  return (
    <Dialog open={!!field} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[88vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <span className="w-9 h-9 rounded-xl bg-primary/10 text-primary flex items-center justify-center shrink-0">
              <Sprout className="w-4 h-4" />
            </span>
            <span className="min-w-0">
              <span className="block truncate">{field.name}</span>
              <span className="block text-xs font-normal text-muted-foreground truncate">
                {field.farm_name || '—'}{field.crop ? ` · ${field.crop}` : ''}
              </span>
            </span>
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          {field.area_hectares && <Badge variant="outline" className="text-xs">{field.area_hectares} ha</Badge>}
          {field.status && <Badge variant="outline" className="text-xs capitalize">{field.status}</Badge>}
          {field.lat && field.lng && <Badge variant="outline" className="text-xs gap-1"><MapPin className="w-3 h-3" /> Geo-located</Badge>}
          {field.soil_ph && <Badge variant="outline" className="text-xs">pH {field.soil_ph}</Badge>}
          {field.soil_moisture && <Badge variant="outline" className="text-xs">Moisture {field.soil_moisture}%</Badge>}
        </div>

        <div className="pt-2">
          <SeasonTracker
            field={field}
            seasons={seasons}
            onCreateSeason={onCreateSeason}
            onRecordStage={onRecordStage}
          />
        </div>
      </DialogContent>
    </Dialog>
  );
}