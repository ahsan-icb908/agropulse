import { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';

const COLLEGE_NAME = 'ISLAMABAD COLLEGE FOR BOYS G-6/3 ISLAMABAD';
const LOGO_URL = 'https://media.base44.com/images/public/6ad39577ddb9c386d04981a9/5f2b5b2bb_Gemini_Generated_Image_oyb8ekoyb8ekoyb8-removebg-preview.png';

export default function IntroAnimation({ onComplete }) {
  const [visible, setVisible] = useState(true);
  const [phase, setPhase] = useState('logo');
  const [typed, setTyped] = useState('');
  const [showBadge, setShowBadge] = useState(false);
  const [showSubtitle, setShowSubtitle] = useState(false);

  const finish = useCallback(() => setVisible(false), []);

  // Phase 1 → 2: after logo settles, show subtitle then start typewriter
  useEffect(() => {
    const t1 = setTimeout(() => setShowSubtitle(true), 1200);
    const t2 = setTimeout(() => setPhase('text'), 1800);
    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, []);

  // Phase 2: typewriter
  useEffect(() => {
    if (phase !== 'text') return;
    let i = 0;
    const interval = setInterval(() => {
      i++;
      setTyped(COLLEGE_NAME.slice(0, i));
      if (i >= COLLEGE_NAME.length) {
        clearInterval(interval);
        setTimeout(() => setPhase('badge'), 250);
      }
    }, 40);
    return () => clearInterval(interval);
  }, [phase]);

  // Phase 3: badge → exit
  useEffect(() => {
    if (phase !== 'badge') return;
    setShowBadge(true);
    const t = setTimeout(finish, 2400);
    return () => clearTimeout(t);
  }, [phase, finish]);

  return (
    <AnimatePresence onExitComplete={onComplete}>
      {visible && (
        <motion.div
          className="fixed inset-0 z-[200] flex flex-col items-center justify-center overflow-hidden"
          style={{ background: 'radial-gradient(ellipse at 50% 40%, #0d1b2e 0%, #060b16 70%, #03060d 100%)' }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.7, ease: 'easeInOut' }}
        >
          {/* Ambient glow orbs */}
          <motion.div
            className="absolute top-1/4 left-1/4 w-64 h-64 rounded-full bg-amber-500/8 blur-3xl"
            animate={{ scale: [1, 1.15, 1], opacity: [0.5, 0.8, 0.5] }}
            transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/4 w-72 h-72 rounded-full bg-emerald-500/8 blur-3xl"
            animate={{ scale: [1, 1.2, 1], opacity: [0.4, 0.7, 0.4] }}
            transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
          />

          {/* Skip button */}
          <button
            onClick={finish}
            className="absolute top-5 right-5 sm:top-6 sm:right-6 z-10 text-white/25 hover:text-white/70 text-xs sm:text-sm flex items-center gap-1.5 transition-colors"
          >
            <X className="w-3.5 h-3.5 sm:w-4 sm:h-4" /> Skip intro
          </button>

          {/* Single bouncing logo */}
          <motion.div
            className="mb-5 sm:mb-7 relative z-[1]"
            initial={{ y: -350, opacity: 0, scale: 0.7 }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            transition={{ type: 'spring', stiffness: 32, damping: 5, mass: 1.3 }}
          >
            <img
              src={LOGO_URL}
              alt="Islamabad College for Boys G-6/3"
              className="w-24 h-24 sm:w-36 sm:h-36 object-contain"
              style={{ filter: 'drop-shadow(0 0 25px rgba(251,191,36,0.3))' }}
            />
          </motion.div>

          {/* FOR: SDGs youth programme */}
          <AnimatePresence>
            {showSubtitle && (
              <motion.p
                className="text-emerald-300/80 font-medium text-xs sm:text-sm tracking-[0.2em] uppercase mb-5 sm:mb-7 relative z-[1]"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4 }}
              >
                FOR: SDGs Youth Programme
              </motion.p>
            )}
          </AnimatePresence>

          {/* Typewriter heading */}
          <div className="text-center px-6 min-h-[2.5rem] sm:min-h-[4rem] relative z-[1]">
            {phase !== 'logo' && (
              <motion.h1
                className="font-heading text-lg sm:text-3xl lg:text-4xl font-bold tracking-tight leading-tight"
                style={{
                  background: 'linear-gradient(135deg, #fbbf24 0%, #fcd34d 40%, #f59e0b 100%)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  backgroundClip: 'text',
                  filter: 'drop-shadow(0 0 18px rgba(251,191,36,0.25))',
                }}
              >
                {typed}
                {phase === 'text' && (
                  <span className="inline-block w-[2px] h-4 sm:h-7 bg-amber-400 ms-1 animate-pulse rounded-full align-middle" />
                )}
              </motion.h1>
            )}
          </div>

          {/* Developer badge */}
          <AnimatePresence>
            {showBadge && (
              <motion.div
                className="mt-7 sm:mt-10 relative z-[1]"
                initial={{ opacity: 0, y: 24, scale: 0.92 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.55, ease: 'easeOut' }}
              >
                <div
                  className="flex flex-col items-center gap-0.5 px-6 py-3 sm:px-8 sm:py-4 rounded-2xl"
                  style={{
                    background: 'rgba(255,255,255,0.04)',
                    backdropFilter: 'blur(12px)',
                    WebkitBackdropFilter: 'blur(12px)',
                    border: '1px solid rgba(251,191,36,0.25)',
                    boxShadow: '0 0 30px rgba(251,191,36,0.12), inset 0 1px 0 rgba(255,255,255,0.06)',
                  }}
                >
                  <p className="text-amber-300 font-semibold text-sm sm:text-base tracking-wide">Developed by AHSAN SAFWAN</p>
                  <p className="text-white/45 text-xs sm:text-sm">XI-B Pre Engineering</p>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
}