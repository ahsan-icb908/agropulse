import { useMemo, useState } from 'react';
import {
  Bar,
  BarChart,
  CartesianGrid,
  ErrorBar,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { AlertTriangle, Download, Loader2, Table2 } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import EvidenceBadge from './EvidenceBadge';
import DemoNotice from './DemoNotice';
import { CHART_COLORS, useChartData } from './useChartData';
import { exportAnalysisCsv } from '@/lib/biology/researchStore';
import { formatValue, valueOf } from '@/lib/biology/calculations';

const WARNING_KEYS = {
  no_observations: 'research.warn.no_observations',
  single_plant: 'research.warn.single_plant',
  few_plants: 'research.warn.few_plants',
  repeated_measures: 'research.warn.repeated_measures',
  below_planned_replicates: 'research.warn.below_planned_replicates',
};

function ChartShell({ title, subtitle, empty, children }) {
  return (
    <Widget className="p-4">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h3 className="font-heading text-sm font-semibold tracking-tight">{title}</h3>
        {subtitle && <span className="text-[11px] text-muted-foreground">{subtitle}</span>}
      </div>
      <div className="mt-3 h-64 w-full">
        {empty ? <p className="grid h-full place-items-center text-xs text-muted-foreground">{empty}</p> : children}
      </div>
    </Widget>
  );
}

export default function AnalysisPanel({ ctx }) {
  const { t } = useI18n();
  const { experiment, treatments, treatmentsById, observations } = ctx;
  const data = useChartData(ctx);
  const [inspect, setInspect] = useState(null);
  const [showIndividual, setShowIndividual] = useState(false);
  const [exported, setExported] = useState(false);

  const hasHeight = data.heightChartRows.length > 0;
  const hasLeaves = data.leafChartRows.length > 0;
  const hasBiomass = data.biomassPerGroup.some((b) => b.mean !== null);
  const isDemo = Boolean(experiment.is_demo);

  const tableRows = useMemo(
    () =>
      data.heightSeries.map((row) => ({
        ...row,
        name: treatmentsById[row.treatment_id]?.name || row.treatment_code,
      })),
    [data.heightSeries, treatmentsById]
  );

  // The records behind one summary row, read straight from the saved observations.
  const recordRowsFor = (row) =>
    row
      ? observations
          .filter((o) => o.treatment_id === row.treatment_id && o.observation_date === row.date)
          .sort((a, b) => String(a.plant_code).localeCompare(String(b.plant_code)))
      : [];

  // One row per date, one column per plant — repeated readings stay with their plant.
  const perPlantRows = useMemo(() => {
    const byDate = new Map();
    data.perPlantHeight.forEach((series) => {
      series.points.forEach((point) => {
        if (!byDate.has(point.date)) byDate.set(point.date, { date: point.date });
        const row = byDate.get(point.date);
        if (point.value !== null) row[series.plant_code] = point.value;
      });
    });
    return Array.from(byDate.values()).sort((a, b) => (a.date < b.date ? -1 : 1));
  }, [data.perPlantHeight]);

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.tab.analysis')}</h2>
          <p className="text-xs text-muted-foreground">{t('research.uncertaintyNote')}</p>
        </div>
        <Button
          size="sm"
          variant="outline"
          className="gap-1.5"
          disabled={observations.length === 0}
          onClick={() => {
            exportAnalysisCsv({
              experiment,
              groupDateRows: data.heightSeries,
              germination: data.germinationPerGroup,
              biomass: data.biomassPerGroup,
              treatmentsById,
            });
            setExported(true);
          }}
        >
          <Download className="h-3.5 w-3.5" />
          {t('research.exportCsv')}
        </Button>
      </div>

      {isDemo && <DemoNotice />}

      {/* Data quality: what the charts are actually built from */}
      <Widget className="p-4">
        <h3 className="font-heading text-sm font-semibold tracking-tight">{t('research.dataQuality')}</h3>
        <div className="mt-3 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
          {[
            [t('research.observationsCount'), data.quality.total],
            [t('research.independentPlants'), data.independentPlants],
            [t('research.badge.real'), data.quality.real],
            [t('research.badge.estimated'), data.quality.estimated],
            [t('research.missingCount'), data.quality.missing],
          ].map(([label, value]) => (
            <div key={label} className="rounded-xl border border-border p-3">
              <p className="font-heading text-xl font-bold">{value}</p>
              <p className="text-[11px] text-muted-foreground">{label}</p>
            </div>
          ))}
        </div>
        {data.quality.demo > 0 && (
          <p className="mt-3 text-[11px] text-muted-foreground">
            {t('research.badge.demo')}: {data.quality.demo}
          </p>
        )}
      </Widget>

      {data.warnings.length > 0 && (
        <div className="space-y-2 rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-800 dark:text-amber-300">
          {data.warnings.map((warning) => (
            <p key={warning} className="flex items-start gap-2 leading-relaxed">
              <AlertTriangle className="mt-0.5 h-3.5 w-3.5 shrink-0" />
              {t(WARNING_KEYS[warning])}
            </p>
          ))}
        </div>
      )}

      <p className="rounded-xl border border-border bg-muted/40 p-3 text-xs leading-relaxed text-muted-foreground">
        {t('research.warn.no_significance')}
      </p>

      {/* Charts */}
      <ChartShell
        title={t('research.heightOverTime')}
        subtitle={`cm • n = ${data.independentPlants} ${t('research.independentPlants')}`}
        empty={hasHeight ? null : t('research.noChartData')}
      >
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={data.heightChartRows} margin={{ top: 8, right: 12, bottom: 4, left: -12 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
            <XAxis dataKey="date" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 11 }} unit=" cm" />
            <Tooltip contentStyle={{ fontSize: 12 }} />
            <Legend wrapperStyle={{ fontSize: 11 }} />
            {data.codes.map((code, index) => (
              <Line
                key={code}
                type="monotone"
                dataKey={code}
                name={`${code} — ${t('research.groupMeans')}`}
                stroke={CHART_COLORS[index % CHART_COLORS.length]}
                strokeWidth={2}
                connectNulls={false}
                dot={{ r: 2 }}
              />
            ))}
          </LineChart>
        </ResponsiveContainer>
      </ChartShell>

      {showIndividual && (
        <ChartShell
          title={t('research.individualPlants')}
          subtitle={`cm • ${data.perPlantHeight.length} ${t('research.field.plant')}`}
          empty={data.perPlantHeight.length ? null : t('research.noChartData')}
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={perPlantRows} margin={{ top: 8, right: 12, bottom: 4, left: -12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} unit=" cm" />
              <Tooltip contentStyle={{ fontSize: 12 }} />
              {data.perPlantHeight.map((series, index) => (
                <Line
                  key={series.plant_id}
                  type="monotone"
                  dataKey={series.plant_code}
                  stroke={CHART_COLORS[index % CHART_COLORS.length]}
                  strokeWidth={1}
                  dot={{ r: 1 }}
                  opacity={0.7}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </ChartShell>
      )}

      <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
        <ChartShell
          title={t('research.leavesOverTime')}
          subtitle={`${t('research.field.leaves')}`}
          empty={hasLeaves ? null : t('research.noChartData')}
        >
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={data.leafChartRows} margin={{ top: 8, right: 12, bottom: 4, left: -12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="date" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip contentStyle={{ fontSize: 12 }} />
              <Legend wrapperStyle={{ fontSize: 11 }} />
              {data.codes.map((code, index) => (
                <Line
                  key={code}
                  type="monotone"
                  dataKey={code}
                  stroke={CHART_COLORS[index % CHART_COLORS.length]}
                  strokeWidth={2}
                  dot={{ r: 2 }}
                />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </ChartShell>

        <ChartShell
          title={`${t('research.groupMeans')} — ${data.lastDate || '—'}`}
          subtitle={`cm • ± ${t('research.sd')}`}
          empty={data.groupMeanBar.some((g) => g.mean !== null) ? null : t('research.noChartData')}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.groupMeanBar} margin={{ top: 8, right: 12, bottom: 4, left: -12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="code" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} unit=" cm" />
              <Tooltip contentStyle={{ fontSize: 12 }} />
              <Bar dataKey="mean" name={t('research.field.height')} fill={CHART_COLORS[0]} radius={[6, 6, 0, 0]}>
                <ErrorBar dataKey="sd" width={4} strokeWidth={1.5} stroke="hsl(var(--foreground))" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartShell>

        <ChartShell
          title={t('research.germinationChart')}
          subtitle="%"
          empty={data.germinationPerGroup.some((g) => g.percent !== null) ? null : t('research.noChartData')}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.germinationPerGroup} margin={{ top: 8, right: 12, bottom: 4, left: -12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="code" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} domain={[0, 100]} unit="%" />
              <Tooltip contentStyle={{ fontSize: 12 }} />
              <Bar dataKey="percent" name={t('research.calc.germination')} fill={CHART_COLORS[1]} radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartShell>

        <ChartShell
          title={t('research.biomassChart')}
          subtitle={`g • ${t('research.sd')}`}
          empty={hasBiomass ? null : t('research.noChartData')}
        >
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data.biomassPerGroup} margin={{ top: 8, right: 12, bottom: 4, left: -12 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
              <XAxis dataKey="code" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} unit=" g" />
              <Tooltip contentStyle={{ fontSize: 12 }} />
              <Bar dataKey="mean" name={t('research.calc.mean_biomass')} fill={CHART_COLORS[2]} radius={[6, 6, 0, 0]}>
                <ErrorBar dataKey="sd" width={4} strokeWidth={1.5} stroke="hsl(var(--foreground))" />
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </ChartShell>
      </div>

      <label className="flex items-center gap-2 text-xs text-muted-foreground">
        <input
          type="checkbox"
          checked={showIndividual}
          onChange={(e) => setShowIndividual(e.target.checked)}
          className="h-4 w-4 rounded border-border"
        />
        {t('research.showIndividual')}
      </label>

      {/* Group summary table with access to the underlying records */}
      <Widget className="overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 p-4">
          <h3 className="font-heading text-sm font-semibold tracking-tight">{t('research.groupSummary')}</h3>
          <span className="text-[11px] text-muted-foreground">{t('research.sampleSize')} • {t('research.units')}: cm</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[760px] text-sm">
            <thead className="bg-muted/60 text-xs">
              <tr>
                <th className="p-2.5 text-start font-medium">{t('research.field.date')}</th>
                <th className="p-2.5 text-start font-medium">{t('research.field.treatment')}</th>
                <th className="p-2.5 text-start font-medium">n</th>
                <th className="p-2.5 text-start font-medium">{t('research.independentPlants')}</th>
                <th className="p-2.5 text-start font-medium">{t('research.field.height')}</th>
                <th className="p-2.5 text-start font-medium">{t('research.sd')}</th>
                <th className="p-2.5 text-start font-medium">{t('research.missingCount')}</th>
                <th className="p-2.5" />
              </tr>
            </thead>
            <tbody>
              {tableRows.map((row) => (
                <tr key={`${row.date}-${row.treatment_id}`} className="border-t border-border">
                  <td className="p-2.5 whitespace-nowrap">{row.date}</td>
                  <td className="p-2.5">
                    <Badge variant="secondary" className="text-[10px]">
                      {row.treatment_code}
                    </Badge>
                  </td>
                  <td className="p-2.5">{row.n}</td>
                  <td className="p-2.5">{row.plants}</td>
                  <td className="p-2.5 font-medium">{formatValue(row.mean)}</td>
                  <td className="p-2.5">{formatValue(row.sd)}</td>
                  <td className="p-2.5">{row.missing}</td>
                  <td className="p-2.5 text-end">
                    <Button size="sm" variant="ghost" className="gap-1.5" onClick={() => setInspect(row)}>
                      <Table2 className="h-3.5 w-3.5" />
                      {t('research.viewRecords')}
                    </Button>
                  </td>
                </tr>
              ))}
              {tableRows.length === 0 && (
                <tr>
                  <td colSpan={8} className="p-6 text-center text-sm text-muted-foreground">
                    {t('research.noChartData')}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Widget>

      {exported && <p className="text-xs text-muted-foreground">CSV — {t('research.exportCsv')}</p>}

      <Dialog open={Boolean(inspect)} onOpenChange={(open) => !open && setInspect(null)}>
        <DialogContent className="max-h-[85vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>
              {t('research.underlyingRecords')} — {inspect?.treatment_code} • {inspect?.date}
            </DialogTitle>
            <DialogDescription>
              {inspect?.n} {t('research.recordsShown')} • {t('research.field.height')} (cm)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2">
            {recordRowsFor(inspect).map((observation) => {
              const value = valueOf(observation, 'height_cm');
              return (
                <div key={observation.id} className="flex items-center justify-between gap-3 rounded-lg border border-border p-2.5 text-sm">
                  <span className="font-medium">{observation.plant_code}</span>
                  <span>{value === null ? t('research.notCalculable') : `${value} cm`}</span>
                  <EvidenceBadge type={observation.record_type || 'real'} />
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      {observations.length === 0 && (
        <p className="flex items-center gap-2 text-xs text-muted-foreground">
          <Loader2 className="h-3.5 w-3.5" /> {t('research.warn.no_observations')}
        </p>
      )}

      <p className="text-[11px] leading-relaxed text-muted-foreground">
        {treatments.length} {t('research.field.treatment')} • {t('research.report.dataOrigin')}:{' '}
        {isDemo ? t('research.badge.demo') : t('research.badge.real')}
      </p>
    </div>
  );
}