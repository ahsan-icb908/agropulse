import {
  Bar,
  BarChart,
  CartesianGrid,
  ErrorBar,
  Legend,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { useI18n } from '@/i18n/LanguageContext';
import { CHART_COLORS } from './useChartData';

function Shell({ title, subtitle, empty, height = 'h-56', children }) {
  return (
    <div className="rounded-xl border border-border p-3 print:break-inside-avoid">
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h4 className="font-heading text-xs font-semibold tracking-tight">{title}</h4>
        {subtitle && <span className="text-[10px] text-muted-foreground">{subtitle}</span>}
      </div>
      <div className={`mt-2 w-full ${height}`}>
        {empty ? <p className="grid h-full place-items-center text-xs text-muted-foreground">{empty}</p> : children}
      </div>
    </div>
  );
}

// Compact chart set reused by the report and the exhibition slides.
export function HeightChart({ data, codes, plants, empty }) {
  const { t } = useI18n();
  return (
    <Shell title={t('research.heightOverTime')} subtitle={`cm • ${plants} ${t('research.independentPlants')}`} empty={empty}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 12, bottom: 4, left: -14 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis dataKey="date" tick={{ fontSize: 10 }} />
          <YAxis tick={{ fontSize: 10 }} unit=" cm" />
          <Tooltip contentStyle={{ fontSize: 11 }} />
          <Legend wrapperStyle={{ fontSize: 10 }} />
          {codes.map((code, index) => (
            <Line
              key={code}
              type="monotone"
              dataKey={code}
              stroke={CHART_COLORS[index % CHART_COLORS.length]}
              strokeWidth={2}
              dot={{ r: 2 }}
              connectNulls={false}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </Shell>
  );
}

export function LeafChart({ data, codes, empty }) {
  const { t } = useI18n();
  return (
    <Shell title={t('research.leavesOverTime')} subtitle={t('research.field.leaves')} empty={empty}>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data} margin={{ top: 8, right: 12, bottom: 4, left: -14 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis dataKey="date" tick={{ fontSize: 10 }} />
          <YAxis tick={{ fontSize: 10 }} />
          <Tooltip contentStyle={{ fontSize: 11 }} />
          <Legend wrapperStyle={{ fontSize: 10 }} />
          {codes.map((code, index) => (
            <Line
              key={code}
              type="monotone"
              dataKey={code}
              stroke={CHART_COLORS[index % CHART_COLORS.length]}
              strokeWidth={2}
              dot={{ r: 2 }}
            />
          ))}
        </LineChart>
      </ResponsiveContainer>
    </Shell>
  );
}

export function MeanBarChart({ data, title, unit, dataKey = 'mean', withSd = true, empty }) {
  return (
    <Shell title={title} subtitle={withSd ? `${unit} • ± SD` : unit} empty={empty}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={data} margin={{ top: 8, right: 12, bottom: 4, left: -14 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
          <XAxis dataKey="code" tick={{ fontSize: 10 }} />
          <YAxis tick={{ fontSize: 10 }} unit={unit === '%' ? '%' : ` ${unit}`} domain={dataKey === 'percent' ? [0, 100] : undefined} />
          <Tooltip contentStyle={{ fontSize: 11 }} />
          <Bar dataKey={dataKey} fill={CHART_COLORS[0]} radius={[6, 6, 0, 0]}>
            {withSd && <ErrorBar dataKey="sd" width={4} strokeWidth={1.5} stroke="hsl(var(--foreground))" />}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </Shell>
  );
}