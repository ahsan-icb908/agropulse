import { useMemo } from 'react';
import {
  dataQuality,
  finalBiomassSummary,
  germinationByGroup,
  germinationSummary,
  groupDateSeries,
  independentPlantCount,
  plantSeries,
  sampleSizeWarnings,
  summariseByGroup,
} from '@/lib/biology/calculations';

// Every chart dataset in the lab is derived here from saved observations only.
// Repeated readings of one plant are never counted as extra plants.
export function useChartData(ctx) {
  const { experiment, treatments, plants, observations } = ctx;

  return useMemo(() => {
    const lastDate = observations.reduce(
      (latest, o) => (o.observation_date > latest ? o.observation_date : latest),
      ''
    );

    const lastDateObservations = observations.filter((o) => o.observation_date === lastDate);
    const codeOf = (row) => row.treatment_code || row.treatment_id;

    const toChartRows = (rows) => {
      const map = new Map();
      rows.forEach((row) => {
        if (!map.has(row.date)) map.set(row.date, { date: row.date });
        const bucket = map.get(row.date);
        const code = codeOf(row);
        bucket[code] = row.mean;
        bucket[`${code}__sd`] = row.sd;
        bucket[`${code}__n`] = row.n;
      });
      return Array.from(map.values()).sort((a, b) => (a.date < b.date ? -1 : 1));
    };

    const heightSeries = groupDateSeries(observations, 'height_cm');
    const leafSeries = groupDateSeries(observations, 'leaf_count');

    const groupMeanBar = summariseByGroup(lastDateObservations, 'height_cm').map((group) => ({
      code: codeOf(group),
      label: codeOf(group),
      mean: group.mean,
      sd: group.sd,
      n: group.n,
      plants: group.plants,
    }));

    const germinationPerGroup = germinationByGroup(plants, observations).map((g) => ({
      code: g.treatment_code || g.treatment_id,
      percent: g.percent,
      germinated: g.germinated,
      total: g.total,
      unrecorded: g.unrecorded,
    }));

    const biomassPerGroup = treatments.map((treatment) => {
      const groupObservations = observations.filter((o) => o.treatment_id === treatment.id);
      const summary = finalBiomassSummary(groupObservations);
      return {
        code: treatment.code || treatment.id,
        mean: summary.mean,
        sd: summary.sd,
        plants: summary.plants,
        values: summary.values,
      };
    });

    const independentPlants = independentPlantCount(observations);

    return {
      lastDate,
      heightChartRows: toChartRows(heightSeries),
      leafChartRows: toChartRows(leafSeries),
      heightSeries,
      leafSeries,
      groupMeanBar,
      germinationPerGroup,
      germinationOverall: germinationSummary(plants, observations),
      biomassPerGroup,
      perPlantHeight: plantSeries(observations, 'height_cm'),
      quality: dataQuality(observations, 'height_cm'),
      independentPlants,
      warnings: sampleSizeWarnings({
        independentPlants,
        observations: observations.length,
        replicates: Number(experiment?.replicates_per_group) || 0,
      }),
      codes: treatments.map((treatment) => treatment.code || treatment.id),
    };
  }, [experiment, treatments, plants, observations]);
}

export const CHART_COLORS = [
  'hsl(var(--chart-1))',
  'hsl(var(--chart-2))',
  'hsl(var(--chart-3))',
  'hsl(var(--chart-4))',
  'hsl(var(--chart-5))',
];