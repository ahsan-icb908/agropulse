import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { BookOpen, Check, Droplet, Droplets, ExternalLink, Loader2, Scale, Sun, Trash2, Waves, Wind } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BIO_CONCEPTS, INTERPRETATION_CAUTION } from './data/biologyExplanations';
import { REFERENCE_NOTICE } from './data/references';

const ICONS = {
  droplet: Droplets,
  waves: Waves,
  wind: Wind,
  sun: Sun,
  alert: Scale,
  bubble: Droplet,
  scale: Scale,
};

const TYPES = ['textbook', 'extension', 'journal', 'organization', 'other'];

const EMPTY = {
  title: '',
  authors: '',
  organization: '',
  year: '',
  source_url: '',
  reference_type: 'textbook',
  notes: '',
};

export default function BiologyPanel({ ctx }) {
  const { t, lang } = useI18n();
  const { experiment } = ctx;
  const [references, setReferences] = useState([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const res = await base44.entities.ResearchReference.filter(
        { experiment_id: experiment.id },
        { sort: 'title', limit: 100 }
      );
      setReferences(res.items || []);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
     
  }, [experiment.id]);

  async function save() {
    if (!form.title.trim()) {
      setError('A reference title is required.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await base44.entities.ResearchReference.create({
        ...form,
        experiment_id: experiment.id,
        is_starter: false,
        is_demo: Boolean(experiment.is_demo),
      });
      setForm(EMPTY);
      setOpen(false);
      load();
    } catch (e) {
      setError(e?.message || 'Could not save the reference.');
    } finally {
      setSaving(false);
    }
  }

  async function remove(reference) {
    if (!window.confirm(t('research.confirmDeleteReference'))) return;
    await base44.entities.ResearchReference.delete(reference.id);
    load();
  }

  return (
    <div className="space-y-5">
      {/* Biological explanation, in the selected language */}
      <section className="space-y-3">
        <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.concepts')}</h2>
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {BIO_CONCEPTS.map((concept) => {
            const Icon = ICONS[concept.icon] || Droplets;
            return (
              <Widget key={concept.id} className="p-4 print:break-inside-avoid">
                <div className="flex items-start gap-2.5">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-primary/10 text-primary">
                    <Icon className="h-4 w-4" />
                  </span>
                  <h3 className="font-heading text-sm font-semibold leading-snug">
                    {lang === 'ur' ? concept.title.ur : concept.title.en}
                  </h3>
                </div>
                <p
                  dir={lang === 'ur' ? 'rtl' : 'ltr'}
                  className="mt-2 text-xs leading-relaxed text-muted-foreground"
                >
                  {lang === 'ur' ? concept.body.ur : concept.body.en}
                </p>
              </Widget>
            );
          })}
        </div>
        <p
          dir={lang === 'ur' ? 'rtl' : 'ltr'}
          className="rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-xs leading-relaxed text-amber-800 dark:text-amber-300"
        >
          {t('research.caution')}: {lang === 'ur' ? INTERPRETATION_CAUTION.ur : INTERPRETATION_CAUTION.en}
        </p>
      </section>

      {/* References */}
      <section className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.references')}</h2>
            <p className="text-xs text-muted-foreground">{t('research.verifySources')}</p>
          </div>
          <Button size="sm" variant="outline" className="gap-1.5" onClick={() => setOpen(true)}>
            <BookOpen className="h-3.5 w-3.5" />
            {t('research.addReference')}
          </Button>
        </div>

        <p
          dir={lang === 'ur' ? 'rtl' : 'ltr'}
          className="rounded-xl border border-border bg-muted/40 p-3 text-[11px] leading-relaxed text-muted-foreground"
        >
          {lang === 'ur' ? REFERENCE_NOTICE.ur : REFERENCE_NOTICE.en}
        </p>

        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="h-5 w-5 animate-spin text-muted-foreground" />
          </div>
        ) : references.length === 0 ? (
          <Widget className="p-6 text-center text-sm text-muted-foreground">{t('research.noReferences')}</Widget>
        ) : (
          <ul className="space-y-2">
            {references.map((reference) => (
              <li key={reference.id}>
                <Widget className="flex flex-wrap items-start justify-between gap-3 p-3.5">
                  <div className="min-w-0">
                    <p className="text-sm font-medium leading-snug">{reference.title}</p>
                    <p className="mt-0.5 text-[11px] text-muted-foreground">
                      {[reference.authors, reference.organization, reference.year].filter(Boolean).join(' • ')}
                    </p>
                    {reference.notes && (
                      <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{reference.notes}</p>
                    )}
                    <div className="mt-1.5 flex flex-wrap items-center gap-2">
                      <Badge variant="outline" className="text-[10px]">
                        {reference.reference_type}
                      </Badge>
                      {reference.is_starter && (
                        <Badge variant="secondary" className="gap-1 text-[10px]">
                          <Check className="h-3 w-3" />
                          {t('research.starters')}
                        </Badge>
                      )}
                      {reference.source_url && (
                        <a
                          href={reference.source_url}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 text-[11px] text-primary hover:underline"
                        >
                          <ExternalLink className="h-3 w-3" />
                          {reference.source_url}
                        </a>
                      )}
                    </div>
                  </div>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-8 w-8 text-muted-foreground hover:text-destructive"
                    onClick={() => remove(reference)}
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </Widget>
              </li>
            ))}
          </ul>
        )}
      </section>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>{t('research.addReference')}</DialogTitle>
            <DialogDescription>{t('research.verifySources')}</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-1">
            <div>
              <Label>{t('research.referenceTitle')} *</Label>
              <Input value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="mt-1" />
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <Label>{t('research.authors')}</Label>
                <Input value={form.authors} onChange={(e) => setForm({ ...form, authors: e.target.value })} className="mt-1" />
              </div>
              <div>
                <Label>{t('research.year')}</Label>
                <Input value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} className="mt-1" />
              </div>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <div>
                <Label>{t('research.organization')}</Label>
                <Input
                  value={form.organization}
                  onChange={(e) => setForm({ ...form, organization: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label>{t('research.type')}</Label>
                <Select value={form.reference_type} onValueChange={(v) => setForm({ ...form, reference_type: v })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {TYPES.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div>
              <Label>{t('research.url')}</Label>
              <Input value={form.source_url} onChange={(e) => setForm({ ...form, source_url: e.target.value })} className="mt-1" />
            </div>
            <div>
              <Label>{t('research.field.notes')}</Label>
              <Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} className="mt-1" />
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button onClick={save} disabled={saving} className="gap-2">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              {t('common.save')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}