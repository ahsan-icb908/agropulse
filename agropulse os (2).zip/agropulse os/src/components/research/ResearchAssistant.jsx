import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { AlertTriangle, Loader2, Send, Sparkles } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { BIO_CONCEPTS, JUDGE_QUESTIONS } from './data/biologyExplanations';

// The assistant is optional and clearly framed as guidance, never as findings.
// If the AI service is unavailable the panel says so plainly and falls back to
// the built-in explanations and the deterministic calculations elsewhere in the lab.
export default function ResearchAssistant({ ctx }) {
  const { t, lang } = useI18n();
  const { experiment, treatments, observations } = ctx;
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');
  const [status, setStatus] = useState('idle'); // idle | loading | error | ok
  const [openConcept, setOpenConcept] = useState(null);

  async function ask() {
    if (!question.trim()) return;
    setStatus('loading');
    setAnswer('');
    try {
      const prompt = [
        'You are an educational biology research assistant for a Class 11-12 science exhibition project.',
        'Rules you must follow: never invent measurements, citations, statistics, p-values or results; never claim that a hypothesis is proven; never describe correlation as causation.',
        'If the user asks for data or results you do not have, explain that the researcher must measure it and record it in the app.',
        'Answer in Urdu if the requested language is Urdu, otherwise answer in English. Keep the answer concise and school-appropriate.',
        `Requested answer language: ${lang === 'ur' ? 'Urdu' : 'English'}.`,
        `Project title: ${experiment?.title || '—'}`,
        `Research question: ${experiment?.research_question || '—'}`,
        `Hypothesis: ${experiment?.hypothesis || '—'}`,
        `Treatment groups: ${treatments.map((tr) => `${tr.code || ''} ${tr.name}`).join('; ') || 'none'}`,
        `Saved observations so far: ${observations.length} records (no values are shared with you).`,
        `Question: ${question}`,
      ].join('\n');

      const result = await base44.integrations.Core.InvokeLLM({ prompt });
      setAnswer(typeof result === 'string' ? result : JSON.stringify(result));
      setStatus('ok');
    } catch {
      setStatus('error');
    }
  }

  return (
    <div className="space-y-5 print:hidden">
      <div>
        <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.ai.title')}</h2>
        <p className="text-xs text-muted-foreground">{t('research.ai.subtitle')}</p>
      </div>

      <Widget className="p-4">
        <Textarea
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          rows={3}
          placeholder={t('research.ai.placeholder')}
          disabled={status === 'loading'}
        />
        <div className="mt-3 flex flex-wrap items-center gap-2">
          <Button onClick={ask} disabled={status === 'loading' || !question.trim()} className="gap-2">
            {status === 'loading' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-3.5 w-3.5" />}
            {t('research.ai.send')}
          </Button>
          <Badge variant="outline" className="gap-1 text-[10px]">
            <Sparkles className="h-3 w-3" />
            {t('research.ai.disclaimer')}
          </Badge>
        </div>

        {status === 'loading' && (
          <p className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
            <Loader2 className="h-3.5 w-3.5 animate-spin" />
            {t('common.loading')}
          </p>
        )}

        {status === 'ok' && (
          <div className="mt-3 whitespace-pre-line rounded-xl border border-primary/30 bg-primary/5 p-3.5 text-sm leading-relaxed">
            {answer}
            <p className="mt-2 text-[11px] text-muted-foreground">{t('research.ai.disclaimer')}</p>
          </div>
        )}

        {status === 'error' && (
          <div className="mt-3 flex items-start gap-2.5 rounded-xl border border-amber-500/40 bg-amber-500/10 p-3.5 text-amber-800 dark:text-amber-300">
            <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
            <div className="text-xs leading-relaxed">
              <p className="font-semibold">{t('research.ai.error')}</p>
              <p className="mt-1">{t('research.ai.unavailable')}</p>
            </div>
          </div>
        )}
      </Widget>

      {/* Built-in help — works with no AI, no credits and no internet services */}
      <Widget className="p-4">
        <h3 className="font-heading text-sm font-semibold tracking-tight">{t('research.ai.fallback')}</h3>

        <div className="mt-3 space-y-2">
          {BIO_CONCEPTS.map((concept) => (
            <div key={concept.id} className="rounded-xl border border-border">
              <button
                type="button"
                className="flex w-full items-center justify-between gap-2 p-3 text-start"
                onClick={() => setOpenConcept(openConcept === concept.id ? null : concept.id)}
              >
                <span className="text-sm font-medium">{lang === 'ur' ? concept.title.ur : concept.title.en}</span>
                <span className="text-xs text-muted-foreground">{openConcept === concept.id ? '−' : '+'}</span>
              </button>
              {openConcept === concept.id && (
                <p
                  dir={lang === 'ur' ? 'rtl' : 'ltr'}
                  className="border-t border-border p-3 text-xs leading-relaxed text-muted-foreground"
                >
                  {lang === 'ur' ? concept.body.ur : concept.body.en}
                </p>
              )}
            </div>
          ))}
        </div>

        <h4 className="mt-4 font-heading text-xs font-semibold tracking-tight">{t('research.ai.judgeQs')}</h4>
        <ul className="mt-2 space-y-2">
          {JUDGE_QUESTIONS.map((item, index) => (
            <li
              key={index}
              dir={lang === 'ur' ? 'rtl' : 'ltr'}
              className="rounded-lg bg-muted/50 p-2.5 text-xs leading-relaxed"
            >
              {lang === 'ur' ? item.ur : item.en}
            </li>
          ))}
        </ul>
      </Widget>
    </div>
  );
}