import { useEffect, useState } from 'react';
import { CheckCircle2, Circle, Loader2, Pencil } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { updateExperiment } from '@/lib/biology/researchStore';
import { WORKFLOW_NOTE, WORKFLOW_STEPS, workflowState } from './data/workflow';

const STATUSES = ['planning', 'running', 'completed', 'archived'];
const OUTCOMES = ['not_assessed', 'supported', 'partially_supported', 'not_supported', 'inconclusive'];

const asList = (value) =>
  value
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);

function Field({ label, children }) {
  return (
    <div>
      <Label>{label}</Label>
      {children}
    </div>
  );
}

// Project details + the scientific-method workflow, in one place.
export default function OverviewPanel({ ctx }) {
  const { t, lang } = useI18n();
  const { experiment, treatments, observations, reload } = ctx;
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState(experiment);

  useEffect(() => setForm(experiment), [experiment]);

  const state = workflowState({ experiment, treatments, observations });
  const isDemo = Boolean(experiment.is_demo);

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  async function save() {
    setSaving(true);
    try {
      await updateExperiment(experiment.id, {
        ...form,
        replicates_per_group: Number(form.replicates_per_group) || undefined,
      });
      setOpen(false);
      reload();
    } finally {
      setSaving(false);
    }
  }

  const rows = [
    [t('research.researchQuestion'), experiment.research_question],
    [t('research.hypothesis'), experiment.hypothesis],
    [t('research.independentVar'), experiment.independent_variable],
    [t('research.dependentVars'), (experiment.dependent_variables || []).join(', ')],
    [t('research.controlledVars'), (experiment.controlled_variables || []).join(', ')],
    [t('research.species'), [experiment.species, experiment.variety].filter(Boolean).join(' — ')],
    [t('research.schedule'), experiment.measurement_schedule],
    [t('research.startDate'), [experiment.start_date, experiment.end_date].filter(Boolean).join(' → ')],
    [t('research.replicates'), experiment.replicates_per_group ? String(experiment.replicates_per_group) : ''],
    [t('research.location'), experiment.location_text],
    [t('research.methodology'), experiment.methodology],
    [t('research.conclusion'), experiment.conclusion],
    [t('research.limitations'), experiment.limitations],
    [t('research.futureResearch'), experiment.future_research],
  ].filter(([, value]) => value && String(value).trim());

  return (
    <div className="space-y-5">
      <Widget className="p-4 sm:p-5">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div className="min-w-0">
            <h2 className="font-heading text-lg font-semibold tracking-tight">{experiment.title}</h2>
            <div className="mt-2 flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="text-[10px]">
                {t(`research.status.${experiment.status || 'planning'}`)}
              </Badge>
              <Badge variant="outline" className="text-[10px]">
                {t('research.outcome')}: {t(`research.outcome.${experiment.hypothesis_outcome || 'not_assessed'}`)}
              </Badge>
              {experiment.farm_name && (
                <Badge variant="secondary" className="text-[10px]">
                  {t('research.linkedRecords')}: {[experiment.farm_name, experiment.field_name, experiment.crop].filter(Boolean).join(' • ')}
                </Badge>
              )}
            </div>
          </div>
          <Button variant="outline" size="sm" className="gap-1.5" onClick={() => setOpen(true)}>
            <Pencil className="h-3.5 w-3.5" />
            {t('research.editProject')}
          </Button>
        </div>

        <dl className="mt-4 space-y-3 border-t border-border pt-4">
          {rows.map(([label, value]) => (
            <div key={label} className="grid grid-cols-1 gap-1 sm:grid-cols-[200px_1fr] sm:gap-4">
              <dt className="text-xs font-medium text-muted-foreground">{label}</dt>
              <dd className="whitespace-pre-line text-sm leading-relaxed">{value}</dd>
            </div>
          ))}
          {(experiment.objectives || []).length > 0 && (
            <div className="grid grid-cols-1 gap-1 sm:grid-cols-[200px_1fr] sm:gap-4">
              <dt className="text-xs font-medium text-muted-foreground">{t('research.objectives')}</dt>
              <dd>
                <ul className="list-disc space-y-1 ps-4 text-sm leading-relaxed">
                  {experiment.objectives.map((objective, index) => (
                    <li key={index}>{objective}</li>
                  ))}
                </ul>
              </dd>
            </div>
          )}
        </dl>

        {isDemo && (
          <p className="mt-4 rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-xs leading-relaxed text-amber-800 dark:text-amber-300">
            {experiment.notes}
          </p>
        )}
      </Widget>

      <Widget className="p-4 sm:p-5">
        <h3 className="font-heading text-sm font-semibold tracking-tight">{t('research.workflow')}</h3>
        <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
          {lang === 'ur' ? WORKFLOW_NOTE.ur : WORKFLOW_NOTE.en}
        </p>
        <ol className="mt-4 grid grid-cols-1 gap-2 sm:grid-cols-2">
          {WORKFLOW_STEPS.map((step, index) => {
            const done = Boolean(state[step.id]);
            return (
              <li
                key={step.id}
                className={`flex items-start gap-2.5 rounded-xl border p-2.5 text-xs leading-relaxed ${
                  done ? 'border-primary/30 bg-primary/5' : 'border-border'
                }`}
              >
                {done ? (
                  <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                ) : (
                  <Circle className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                )}
                <span>
                  <span className="font-medium">{index + 1}.</span> {lang === 'ur' ? step.ur : step.en}
                </span>
              </li>
            );
          })}
        </ol>
      </Widget>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t('research.editProject')}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-1">
            <Field label={t('research.fieldTitle')}>
              <Input value={form.title || ''} onChange={set('title')} className="mt-1" />
            </Field>
            <Field label={t('research.researchQuestion')}>
              <Textarea value={form.research_question || ''} onChange={set('research_question')} rows={2} className="mt-1" />
            </Field>
            <Field label={t('research.hypothesis')}>
              <Textarea value={form.hypothesis || ''} onChange={set('hypothesis')} rows={3} className="mt-1" />
            </Field>
            <Field label={t('research.objectives')}>
              <Textarea
                value={(form.objectives || []).join('\n')}
                onChange={(e) => setForm({ ...form, objectives: e.target.value.split('\n').filter(Boolean) })}
                rows={3}
                className="mt-1"
              />
            </Field>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Field label={t('research.independentVar')}>
                <Input value={form.independent_variable || ''} onChange={set('independent_variable')} className="mt-1" />
              </Field>
              <Field label={t('research.schedule')}>
                <Input value={form.measurement_schedule || ''} onChange={set('measurement_schedule')} className="mt-1" />
              </Field>
            </div>
            <Field label={t('research.dependentVars')}>
              <Input
                value={(form.dependent_variables || []).join(', ')}
                onChange={(e) => setForm({ ...form, dependent_variables: asList(e.target.value) })}
                className="mt-1"
              />
            </Field>
            <Field label={t('research.controlledVars')}>
              <Input
                value={(form.controlled_variables || []).join(', ')}
                onChange={(e) => setForm({ ...form, controlled_variables: asList(e.target.value) })}
                className="mt-1"
              />
            </Field>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
              <Field label={t('research.startDate')}>
                <Input type="date" value={form.start_date || ''} onChange={set('start_date')} className="mt-1" />
              </Field>
              <Field label={t('research.endDate')}>
                <Input type="date" value={form.end_date || ''} onChange={set('end_date')} className="mt-1" />
              </Field>
              <Field label={t('research.replicates')}>
                <Input type="number" min="1" value={form.replicates_per_group ?? ''} onChange={set('replicates_per_group')} className="mt-1" />
              </Field>
            </div>
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
              <Field label={t('research.setStatus')}>
                <Select value={form.status || 'planning'} onValueChange={(v) => setForm({ ...form, status: v })}>
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {STATUSES.map((s) => (
                      <SelectItem key={s} value={s}>
                        {t(`research.status.${s}`)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
              <Field label={t('research.outcome')}>
                <Select
                  value={form.hypothesis_outcome || 'not_assessed'}
                  onValueChange={(v) => setForm({ ...form, hypothesis_outcome: v })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {OUTCOMES.map((o) => (
                      <SelectItem key={o} value={o}>
                        {t(`research.outcome.${o}`)}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </Field>
            </div>
            <p className="text-[11px] leading-relaxed text-muted-foreground">{t('research.outcomeHint')}</p>
            <Field label={t('research.methodology')}>
              <Textarea value={form.methodology || ''} onChange={set('methodology')} rows={4} className="mt-1" />
            </Field>
            <Field label={t('research.conclusion')}>
              <Textarea value={form.conclusion || ''} onChange={set('conclusion')} rows={3} className="mt-1" />
            </Field>
            <Field label={t('research.limitations')}>
              <Textarea value={form.limitations || ''} onChange={set('limitations')} rows={3} className="mt-1" />
            </Field>
            <Field label={t('research.futureResearch')}>
              <Textarea value={form.future_research || ''} onChange={set('future_research')} rows={2} className="mt-1" />
            </Field>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button onClick={save} disabled={saving} className="gap-2">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              {t('common.save')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}