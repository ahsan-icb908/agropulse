import { AlertTriangle } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { cn } from '@/lib/utils';

// Standing reminder shown wherever demonstration records are on screen.
export default function DemoNotice({ className, text }) {
  const { t } = useI18n();
  return (
    <div
      className={cn(
        'flex items-start gap-2.5 rounded-xl border border-amber-500/40 bg-amber-500/10 p-3 text-amber-800 dark:text-amber-300',
        className
      )}
    >
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
      <div className="min-w-0 text-xs leading-relaxed">
        <span className="font-semibold">{t('research.badge.demo')}</span> —{' '}
        {text || t('research.demoNotice')}
      </div>
    </div>
  );
}