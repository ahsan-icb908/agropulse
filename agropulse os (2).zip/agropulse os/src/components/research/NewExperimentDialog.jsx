import { useState } from 'react';
import { Loader2, Plus } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useCollection } from '@/hooks/useCollection';
import { base44 } from '@/api/base44Client';
import { BLANK_TEMPLATE, MUNG_BEAN_TEMPLATE } from './data/experimentTemplates';
import { createExperiment } from '@/lib/biology/researchStore';

const todayISO = () => new Date().toISOString().slice(0, 10);

export default function NewExperimentDialog({ onCreated, trigger, defaultTemplate = 'blank' }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  const [templateId, setTemplateId] = useState(defaultTemplate);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [links, setLinks] = useState({ farm_id: '', field_id: '', crop_season_id: '' });

  const { data: farms } = useCollection('Farm', { limit: 50 });
  const { data: fields } = useCollection('Field', { limit: 200 });
  const { data: seasons } = useCollection('CropSeason', { limit: 200 });

  const template = templateId === 'mung_water' ? MUNG_BEAN_TEMPLATE : BLANK_TEMPLATE;
  const [form, setForm] = useState({ ...template.fields, start_date: todayISO() });

  function pickTemplate(id) {
    setTemplateId(id);
    const next = id === 'mung_water' ? MUNG_BEAN_TEMPLATE : BLANK_TEMPLATE;
    setForm({ ...next.fields, start_date: form.start_date });
  }

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  async function save() {
    if (!form.title.trim()) {
      setError('A project title is required.');
      return;
    }
    if (form.end_date && form.start_date && form.end_date < form.start_date) {
      setError('The end date cannot be before the start date.');
      return;
    }
    const replicates = Number(form.replicates_per_group);
    if (!Number.isInteger(replicates) || replicates < 1) {
      setError('Replicates per group must be a whole number of at least 1.');
      return;
    }

    setSaving(true);
    setError('');
    try {
      const farm = farms.find((f) => f.id === links.farm_id);
      const field = fields.find((f) => f.id === links.field_id);
      const season = seasons.find((s) => s.id === links.crop_season_id);

      const experiment = await createExperiment(
        {
          ...form,
          replicates_per_group: replicates,
          farm_id: farm?.id,
          farm_name: farm?.name,
          field_id: field?.id,
          field_name: field?.name,
          crop_season_id: season?.id,
          crop: season?.crop || field?.crop,
        },
        { withStarters: true }
      );

      if (template.suggestedTreatments.length) {
        await base44.entities.ExperimentTreatment.bulkCreate(
          template.suggestedTreatments.map((treatment, index) => ({
            ...treatment,
            sort_order: index,
            plants_planned: replicates,
            experiment_id: experiment.id,
            level_note: t('research.templateNote'),
          }))
        );
      }

      setOpen(false);
      onCreated?.(experiment);
    } catch (e) {
      setError(e?.message || 'Could not save the experiment.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger || <Button className="gap-2"><Plus className="h-4 w-4" />{t('research.newProject')}</Button>}</DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{t('research.newProject')}</DialogTitle>
          <DialogDescription>{t('research.chooseNewHint')}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-1">
          <div className="flex flex-wrap gap-2">
            {[BLANK_TEMPLATE, MUNG_BEAN_TEMPLATE].map((option) => (
              <Button
                key={option.id}
                type="button"
                size="sm"
                variant={templateId === option.id ? 'default' : 'outline'}
                onClick={() => pickTemplate(option.id)}
              >
                {t(option.labelKey)}
              </Button>
            ))}
          </div>

          {templateId === 'mung_water' && (
            <p className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-xs leading-relaxed text-amber-800 dark:text-amber-300">
              {t('research.templateNote')}
            </p>
          )}

          <div>
            <Label>{t('research.fieldTitle')} *</Label>
            <Input value={form.title} onChange={set('title')} className="mt-1" />
          </div>

          <div>
            <Label>{t('research.researchQuestion')}</Label>
            <Textarea value={form.research_question} onChange={set('research_question')} rows={2} className="mt-1" />
          </div>

          <div>
            <Label>{t('research.hypothesis')}</Label>
            <Textarea value={form.hypothesis} onChange={set('hypothesis')} rows={3} className="mt-1" />
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <Label>{t('research.species')}</Label>
              <Input value={form.species} onChange={set('species')} className="mt-1" placeholder="Vigna radiata (mung bean)" />
            </div>
            <div>
              <Label>{t('research.variety')}</Label>
              <Input value={form.variety} onChange={set('variety')} className="mt-1" />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <Label>{t('research.startDate')}</Label>
              <Input type="date" value={form.start_date || ''} onChange={set('start_date')} className="mt-1" />
            </div>
            <div>
              <Label>{t('research.endDate')}</Label>
              <Input type="date" value={form.end_date || ''} onChange={set('end_date')} className="mt-1" />
            </div>
            <div>
              <Label>{t('research.replicates')}</Label>
              <Input
                type="number"
                min="1"
                value={form.replicates_per_group ?? ''}
                onChange={set('replicates_per_group')}
                className="mt-1"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <Label>{t('research.linkFarm')}</Label>
              <Select value={links.farm_id} onValueChange={(v) => setLinks({ ...links, farm_id: v })}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder={t('research.optional')} />
                </SelectTrigger>
                <SelectContent>
                  {farms.map((f) => (
                    <SelectItem key={f.id} value={f.id}>
                      {f.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t('research.linkField')}</Label>
              <Select value={links.field_id} onValueChange={(v) => setLinks({ ...links, field_id: v })}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder={t('research.optional')} />
                </SelectTrigger>
                <SelectContent>
                  {fields.map((f) => (
                    <SelectItem key={f.id} value={f.id}>
                      {f.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t('research.linkSeason')}</Label>
              <Select value={links.crop_season_id} onValueChange={(v) => setLinks({ ...links, crop_season_id: v })}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder={t('research.optional')} />
                </SelectTrigger>
                <SelectContent>
                  {seasons.map((s) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.season_label} — {s.crop}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label>{t('research.methodology')}</Label>
            <Textarea value={form.methodology} onChange={set('methodology')} rows={4} className="mt-1" />
            <p className="mt-1 text-[11px] text-muted-foreground">{t('research.methodologyHint')}</p>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <Label>{t('research.independentVar')}</Label>
              <Input value={form.independent_variable} onChange={set('independent_variable')} className="mt-1" />
            </div>
            <div>
              <Label>{t('research.schedule')}</Label>
              <Input value={form.measurement_schedule} onChange={set('measurement_schedule')} className="mt-1" />
            </div>
          </div>

          <div>
            <Label>{t('research.dependentVars')}</Label>
            <Input
              value={(form.dependent_variables || []).join(', ')}
              onChange={(e) =>
                setForm({ ...form, dependent_variables: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) })
              }
              className="mt-1"
              placeholder="Height (cm), Leaf number"
            />
          </div>

          <div>
            <Label>{t('research.controlledVars')}</Label>
            <Input
              value={(form.controlled_variables || []).join(', ')}
              onChange={(e) =>
                setForm({ ...form, controlled_variables: e.target.value.split(',').map((s) => s.trim()).filter(Boolean) })
              }
              className="mt-1"
            />
          </div>

          <div className="flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
            <Badge variant="outline" className="text-[10px]">
              {t('research.badge.real')}
            </Badge>
            {t('research.privateNote')}
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            {t('common.cancel')}
          </Button>
          <Button onClick={save} disabled={saving} className="gap-2">
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            {t('common.save')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}