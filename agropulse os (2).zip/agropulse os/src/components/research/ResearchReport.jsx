import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Printer } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import EvidenceBadge from './EvidenceBadge';
import DemoNotice from './DemoNotice';
import { MeanBarChart, HeightChart, LeafChart } from './MiniCharts';
import { useChartData } from './useChartData';
import { INTERPRETATION_CAUTION, BIO_CONCEPTS } from './data/biologyExplanations';
import { formatValue, summariseByGroup } from '@/lib/biology/calculations';

function Section({ title, auto, children }) {
  return (
    <section className="space-y-2 print:break-inside-avoid">
      <div className="flex flex-wrap items-center gap-2 border-b border-border pb-1.5">
        <h3 className="font-heading text-sm font-semibold tracking-tight">{title}</h3>
        {auto && (
          <Badge variant="secondary" className="text-[9px] uppercase">
            auto
          </Badge>
        )}
      </div>
      <div className="space-y-2 text-sm leading-relaxed">{children}</div>
    </section>
  );
}

export default function ResearchReport({ ctx }) {
  const { t, lang } = useI18n();
  const { experiment, treatments, plants, observations, treatmentsById } = ctx;
  const data = useChartData(ctx);
  const [references, setReferences] = useState([]);
  const isDemo = Boolean(experiment.is_demo);
  const heightByGroup = summariseByGroup(observations, 'height_cm');

  useEffect(() => {
    base44.entities.ResearchReference.filter({ experiment_id: experiment.id }, { sort: 'title', limit: 100 })
      .then((res) => setReferences(res.items || []))
      .catch(() => setReferences([]));
  }, [experiment.id]);

  const ranked = heightByGroup
    .filter((g) => g.mean !== null)
    .sort((a, b) => b.mean - a.mean);
  const highest = ranked[0];
  const lowest = ranked.slice(-1)[0];

  const abstract = [
    `${experiment.title}.`,
    experiment.research_question ? `Research question: ${experiment.research_question}` : '',
    experiment.hypothesis ? `Hypothesis: ${experiment.hypothesis}` : '',
    `${t('research.report.dataOrigin')}: ${isDemo ? t('research.report.basedOnDemo') : t('research.report.basedOnReal')}`,
    `${treatments.length} ${t('research.field.treatment')}, ${plants.length} ${t('research.field.plant')}, ${observations.length} ${t('research.observationsCount')}, ${data.quality.missing} ${t('research.missingCount')}.`,
  ]
    .filter(Boolean)
    .join(' ');

  const resultsLines = heightByGroup.map((g) => {
    const group = treatmentsById[g.treatment_id];
    return `${group?.code || g.treatment_code} (${group?.name || ''}): ${t('research.field.height')} = ${formatValue(g.mean)} cm, ${t('research.sd')} = ${g.sd === null ? t('research.notCalculable') : formatValue(g.sd)}, n = ${g.n}, ${t('research.independentPlants')} = ${g.plants}, ${t('research.missingCount')} = ${g.missing}.`;
  });

  const discussion = ranked.length >= 2
    ? [
        `${highest.treatment_code} recorded the highest group mean height (${formatValue(highest.mean)} cm) and ${lowest.treatment_code} the lowest (${formatValue(lowest.mean)} cm) on the dates recorded.`,
        lang === 'ur' ? INTERPRETATION_CAUTION.ur : INTERPRETATION_CAUTION.en,
      ].join(' ')
    : lang === 'ur' ? INTERPRETATION_CAUTION.ur : INTERPRETATION_CAUTION.en;

  const autoLimitations = [
    observations.length === 0 ? t('research.warn.no_observations') : null,
    data.independentPlants < 3 ? t('research.warn.few_plants') : null,
    data.quality.missing > 0 ? `${t('research.missingCount')}: ${data.quality.missing}` : null,
    t('research.warn.no_significance'),
  ].filter(Boolean);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
        <div>
          <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.tab.report')}</h2>
          <p className="text-xs text-muted-foreground">{t('research.report.autoNote')}</p>
        </div>
        <Button size="sm" variant="outline" className="gap-1.5" onClick={() => window.print()}>
          <Printer className="h-3.5 w-3.5" />
          {t('research.report.print')}
        </Button>
      </div>

      {isDemo && <DemoNotice />}

      <Widget className="space-y-6 p-5 print:border-0 print:p-0 print:shadow-none">
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <EvidenceBadge type={isDemo ? 'demonstration' : 'real'} />
            <Badge variant="outline" className="text-[10px]">
              {t(`research.status.${experiment.status || 'planning'}`)}
            </Badge>
          </div>
          <h1 className="font-heading text-xl font-bold leading-snug tracking-tight">{experiment.title}</h1>
          <p className="text-xs text-muted-foreground">
            {[experiment.species, experiment.variety].filter(Boolean).join(' — ')}
            {experiment.start_date ? ` • ${experiment.start_date} → ${experiment.end_date || '—'}` : ''}
          </p>
        </div>

        <Section title={t('research.report.abstract')} auto>
          <p>{abstract}</p>
        </Section>

        <Section title={t('research.report.introduction')} auto>
          {experiment.research_question && <p>{experiment.research_question}</p>}
          {(experiment.objectives || []).length > 0 && (
            <ul className="list-disc space-y-1 ps-5">
              {experiment.objectives.map((objective, index) => (
                <li key={index}>{objective}</li>
              ))}
            </ul>
          )}
          <p className="text-xs text-muted-foreground">
            {(lang === 'ur' ? BIO_CONCEPTS[0].body.ur : BIO_CONCEPTS[0].body.en)}
          </p>
        </Section>

        <Section title={t('research.hypothesis')}>
          <p>{experiment.hypothesis || '—'}</p>
          <p className="text-xs text-muted-foreground">
            {t('research.outcome')}: {t(`research.outcome.${experiment.hypothesis_outcome || 'not_assessed'}`)}
          </p>
        </Section>

        <Section title={t('research.report.materials')}>
          <p className="whitespace-pre-line">{experiment.methodology || '—'}</p>
        </Section>

        <Section title={t('research.exhibition.setup')}>
          <ul className="space-y-1 text-xs">
            <li>
              <span className="text-muted-foreground">{t('research.independentVar')}:</span> {experiment.independent_variable || '—'}
            </li>
            <li>
              <span className="text-muted-foreground">{t('research.dependentVars')}:</span>{' '}
              {(experiment.dependent_variables || []).join(', ') || '—'}
            </li>
            <li>
              <span className="text-muted-foreground">{t('research.controlledVars')}:</span>{' '}
              {(experiment.controlled_variables || []).join(', ') || '—'}
            </li>
            <li>
              <span className="text-muted-foreground">{t('research.schedule')}:</span> {experiment.measurement_schedule || '—'}
            </li>
          </ul>
          <div className="overflow-x-auto">
            <table className="w-full min-w-[520px] text-xs">
              <thead className="bg-muted/60">
                <tr>
                  <th className="p-2 text-start font-medium">{t('research.code')}</th>
                  <th className="p-2 text-start font-medium">{t('research.fieldTreatmentName')}</th>
                  <th className="p-2 text-start font-medium">{t('research.waterMl')}</th>
                  <th className="p-2 text-start font-medium">{t('research.frequency')}</th>
                  <th className="p-2 text-start font-medium">{t('research.plantsPlanned')}</th>
                </tr>
              </thead>
              <tbody>
                {treatments.map((treatment) => (
                  <tr key={treatment.id} className="border-t border-border">
                    <td className="p-2">{treatment.code || '—'}</td>
                    <td className="p-2">
                      {treatment.name}
                      {treatment.is_control ? ` (${t('research.control')})` : ''}
                    </td>
                    <td className="p-2">{treatment.water_ml ?? '—'}</td>
                    <td className="p-2">{treatment.water_frequency || '—'}</td>
                    <td className="p-2">
                      {plants.filter((p) => p.treatment_id === treatment.id).length} / {treatment.plants_planned ?? '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Section>

        <Section title={t('research.report.results')} auto>
          {resultsLines.length ? (
            <ul className="list-disc space-y-1 ps-5">
              {resultsLines.map((line, index) => (
                <li key={index}>{line}</li>
              ))}
            </ul>
          ) : (
            <p>{t('research.warn.no_observations')}</p>
          )}
          {data.germinationOverall.calculable && (
            <p>
              {t('research.calc.germination')}: {data.germinationOverall.percent}% (
              {data.germinationOverall.germinated}/{data.germinationOverall.germinated + data.germinationOverall.notGerminated})
            </p>
          )}
        </Section>

        <Section title={t('research.charts')}>
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <HeightChart
              data={data.heightChartRows}
              codes={data.codes}
              plants={data.independentPlants}
              empty={data.heightChartRows.length ? null : t('research.noChartData')}
            />
            <LeafChart data={data.leafChartRows} codes={data.codes} empty={data.leafChartRows.length ? null : t('research.noChartData')} />
            <MeanBarChart
              data={data.groupMeanBar}
              title={t('research.groupMeans')}
              unit="cm"
              empty={data.groupMeanBar.some((g) => g.mean !== null) ? null : t('research.noChartData')}
            />
            <MeanBarChart
              data={data.germinationPerGroup}
              title={t('research.germinationChart')}
              unit="%"
              dataKey="percent"
              withSd={false}
              empty={data.germinationPerGroup.some((g) => g.percent !== null) ? null : t('research.noChartData')}
            />
          </div>
        </Section>

        <Section title={t('research.report.discussion')} auto>
          <p>{discussion}</p>
        </Section>

        <Section title={t('research.conclusion')}>
          <p>{experiment.conclusion || '—'}</p>
        </Section>

        <Section title={t('research.limitations')}>
          <p>{experiment.limitations || '—'}</p>
          <ul className="list-disc space-y-1 ps-5 text-xs text-muted-foreground">
            {autoLimitations.map((line, index) => (
              <li key={index}>{line}</li>
            ))}
          </ul>
        </Section>

        <Section title={t('research.futureResearch')}>
          <p>{experiment.future_research || '—'}</p>
        </Section>

        <Section title={t('research.references')}>
          {references.length ? (
            <ol className="list-decimal space-y-1 ps-5 text-xs">
              {references.map((reference) => (
                <li key={reference.id}>
                  {[reference.title, reference.authors, reference.organization, reference.year]
                    .filter(Boolean)
                    .join(' — ')}
                  {reference.source_url ? ` (${reference.source_url})` : ''}
                </li>
              ))}
            </ol>
          ) : (
            <p className="text-xs text-muted-foreground">{t('research.noReferences')}</p>
          )}
          <p className="text-[10px] text-muted-foreground">{t('research.verifySources')}</p>
        </Section>
      </Widget>
    </div>
  );
}