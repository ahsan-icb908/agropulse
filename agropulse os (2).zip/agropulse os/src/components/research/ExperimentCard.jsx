import { Link } from 'react-router-dom';
import { CalendarDays, Copy, ExternalLink, FlaskConical, RotateCcw, Trash2 } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import EvidenceBadge from './EvidenceBadge';

const STATUS_TONE = {
  planning: 'bg-sky-500/15 text-sky-700 border-sky-500/30 dark:text-sky-400',
  running: 'bg-primary/10 text-primary border-primary/30',
  completed: 'bg-emerald-500/15 text-emerald-700 border-emerald-500/30 dark:text-emerald-400',
  archived: 'bg-muted text-muted-foreground border-border',
  demonstration: 'bg-amber-500/15 text-amber-700 border-amber-500/40 dark:text-amber-400',
};

export default function ExperimentCard({ experiment, onDuplicate, onArchive, onReopen, onDelete }) {
  const { t } = useI18n();
  const status = experiment.status || 'planning';
  const isDemo = Boolean(experiment.is_demo);

  return (
    <Widget className="flex h-full flex-col p-4">
      <div className="flex items-start justify-between gap-2">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
          <FlaskConical className="h-5 w-5" />
        </span>
        <div className="flex flex-wrap justify-end gap-1.5">
          <Badge variant="outline" className={`text-[10px] capitalize ${STATUS_TONE[status] || STATUS_TONE.planning}`}>
            {t(`research.status.${status}`)}
          </Badge>
          <EvidenceBadge type={isDemo ? 'demonstration' : 'real'} />
        </div>
      </div>

      <p className="mt-3 font-heading text-sm font-semibold leading-snug">{experiment.title}</p>
      <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
        {experiment.research_question || experiment.notes || '—'}
      </p>

      <div className="mt-3 flex flex-wrap items-center gap-2 text-[11px] text-muted-foreground">
        <span className="inline-flex items-center gap-1">
          <CalendarDays className="h-3 w-3" />
          {experiment.start_date || '—'} → {experiment.end_date || '—'}
        </span>
        {experiment.species && <span className="truncate">• {experiment.species}</span>}
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-border pt-3">
        <Button asChild size="sm" className="gap-1.5">
          <Link to={`/research/${experiment.id}`}>
            <ExternalLink className="h-3.5 w-3.5" />
            {t('research.open')}
          </Link>
        </Button>
        <Button size="sm" variant="outline" className="gap-1.5" onClick={() => onDuplicate(experiment)}>
          <Copy className="h-3.5 w-3.5" />
          {t('research.duplicate')}
        </Button>
        {status === 'archived' ? (
          <Button size="sm" variant="ghost" className="gap-1.5" onClick={() => onReopen(experiment)}>
            <RotateCcw className="h-3.5 w-3.5" />
            {t('research.reopen')}
          </Button>
        ) : (
          <Button size="sm" variant="ghost" className="gap-1.5" onClick={() => onArchive(experiment)}>
            {t('research.archive')}
          </Button>
        )}
        <Button
          size="sm"
          variant="ghost"
          className="ms-auto gap-1.5 text-muted-foreground hover:text-destructive"
          onClick={() => onDelete(experiment)}
        >
          <Trash2 className="h-3.5 w-3.5" />
        </Button>
      </div>
    </Widget>
  );
}