// The scientific method as a guided workflow. Step text is bilingual; whether a
// step is complete is derived from the researcher's own saved records only.

export const WORKFLOW_STEPS = [
  { id: 'question', en: 'Define the research question', ur: 'تحقیقی سوال طے کریں' },
  { id: 'hypothesis', en: 'Write the hypothesis', ur: 'مفروضہ لکھیں' },
  { id: 'variables', en: 'Select independent, dependent and controlled variables', ur: 'آزاد، تابع اور قابو شدہ متغیرات منتخب کریں' },
  { id: 'groups', en: 'Design control and treatment groups', ur: 'کنٹرول اور ٹریٹمنٹ گروپ بنائیں' },
  { id: 'methodology', en: 'Record the methodology before measuring', ur: 'پیمائش سے پہلے طریقۂ کار درج کریں' },
  { id: 'collect', en: 'Collect actual observations', ur: 'حقیقی مشاہدات جمع کریں' },
  { id: 'quality', en: 'Review data quality and missing measurements', ur: 'ڈیٹا کے معیار اور غائب پیمائشوں کا جائزہ لیں' },
  { id: 'charts', en: 'Generate charts and summary statistics', ur: 'چارٹ اور خلاصہ اعداد و شمار بنائیں' },
  { id: 'compare', en: 'Compare results with the hypothesis', ur: 'نتائج کا مفروضے سے موازنہ کریں' },
  { id: 'conclude', en: 'Write the conclusion, limitations and future work', ur: 'نتیجہ، حدود اور آئندہ کام لکھیں' },
];

export const WORKFLOW_NOTE = {
  en: 'A step is marked complete only from data you saved. The app never marks a hypothesis as proven.',
  ur: 'کوئی مرحلہ صرف آپ کے محفوظ کردہ ڈیٹا سے مکمل ہوتا ہے۔ ایپ کسی مفروضے کو خود ثابت شدہ قرار نہیں دیتی۔',
};

export function workflowState({ experiment, treatments, observations, counts = {} }) {
  const hasControl = treatments.some((t) => t.is_control);
  return {
    question: Boolean(experiment?.research_question?.trim()),
    hypothesis: Boolean(experiment?.hypothesis?.trim()),
    variables:
      Boolean(experiment?.independent_variable?.trim()) &&
      (experiment?.dependent_variables || []).length > 0 &&
      (experiment?.controlled_variables || []).length > 0,
    groups: treatments.length >= 2 && hasControl,
    methodology: Boolean(experiment?.methodology?.trim()),
    collect: observations.length > 0,
    quality: observations.length > 0,
    charts: observations.length > 0,
    compare: Boolean(experiment?.hypothesis_outcome) && experiment.hypothesis_outcome !== 'not_assessed',
    conclude: Boolean(experiment?.conclusion?.trim()) && Boolean(experiment?.limitations?.trim()),
    ...counts,
  };
}