// Starter reading list for the research lab.
//
// These are real, widely available sources (school textbooks and public
// university/agency extension material). Only the title, author/organisation and
// the publisher or organisation website are stored — no page numbers, DOIs or
// quotations are invented. The researcher must confirm each source before citing
// it, and can add their own references to the experiment in the app.
//
// `is_starter: true` records are seeded per experiment on request and are always
// shown under the "confirm before citing" notice.

export const STARTER_REFERENCES = [
  {
    title: 'Biology Textbook for Class XI — Transport in Plants, Mineral Nutrition',
    authors: 'NCERT (National Council of Educational Research and Training)',
    organization: 'NCERT, India',
    year: 'current edition',
    source_url: 'https://ncert.nic.in',
    reference_type: 'textbook',
    notes: 'School-level treatment of water absorption, osmosis, transpiration and mineral uptake.',
  },
  {
    title: 'Biology Textbook for Class XII — photosynthesis and plant physiology chapters',
    authors: 'NCERT (National Council of Educational Research and Training)',
    organization: 'NCERT, India',
    year: 'current edition',
    source_url: 'https://ncert.nic.in',
    reference_type: 'textbook',
    notes: 'Photosynthesis, respiration and plant growth for the Higher Secondary syllabus.',
  },
  {
    title: 'Plant Physiology and Development',
    authors: 'Taiz, L., Zeiger, E., Møller, I. M. & Murphy, A.',
    organization: 'Oxford University Press / Sinauer',
    year: '6th edition, 2015',
    source_url: 'https://global.oup.com',
    reference_type: 'textbook',
    notes: 'Reference text for water relations, water potential, stomatal behaviour and stress physiology.',
  },
  {
    title: 'Campbell Biology',
    authors: 'Urry, L. A., Cain, M. L., Wasserman, S. A., Minorsky, P. V. & Reece, J. B.',
    organization: 'Pearson',
    year: '12th edition, 2020',
    source_url: 'https://www.pearson.com',
    reference_type: 'textbook',
    notes: 'General biology background on transport, osmosis, photosynthesis and experimental design.',
  },
  {
    title: 'Crop evapotranspiration — Guidelines for computing crop water requirements (Irrigation and Drainage Paper 56)',
    authors: 'Allen, R. G., Pereira, L. S., Raes, D. & Smith, M.',
    organization: 'Food and Agriculture Organization of the United Nations (FAO)',
    year: '1998',
    source_url: 'https://www.fao.org',
    reference_type: 'organization',
    notes: 'Standard reference on evapotranspiration, soil water balance and irrigation water requirements.',
  },
  {
    title: 'Soil health and soil water — technical resources',
    authors: 'USDA Natural Resources Conservation Service',
    organization: 'United States Department of Agriculture (NRCS)',
    year: 'undated web resource',
    source_url: 'https://www.nrcs.usda.gov',
    reference_type: 'extension',
    notes: 'Soil structure, porosity and how water is held and moves in soil.',
  },
  {
    title: 'Home and garden plant watering guidance',
    authors: 'Michigan State University Extension',
    organization: 'Michigan State University',
    year: 'undated web resource',
    source_url: 'https://www.canr.msu.edu',
    reference_type: 'extension',
    notes: 'Practical watering guidance including overwatering and root-zone oxygen problems.',
  },
  {
    title: 'Irrigation and plant water relations — extension publications',
    authors: 'Penn State Extension',
    organization: 'The Pennsylvania State University',
    year: 'undated web resource',
    source_url: 'https://extension.psu.edu',
    reference_type: 'extension',
    notes: 'Applied explanations of soil moisture, plant water use and irrigation scheduling.',
  },
  {
    title: 'Agriculture and Natural Resources research and extension',
    authors: 'University of California Agriculture and Natural Resources',
    organization: 'University of California ANR',
    year: 'undated web resource',
    source_url: 'https://ucanr.edu',
    reference_type: 'extension',
    notes: 'Applied crop and soil science material suitable for school-level projects.',
  },
  {
    title: 'NCBI Bookshelf — freely available life-science texts',
    authors: 'National Center for Biotechnology Information',
    organization: 'U.S. National Library of Medicine',
    year: 'undated web resource',
    source_url: 'https://www.ncbi.nlm.nih.gov/books',
    reference_type: 'organization',
    notes: 'Access point for open life-science texts; confirm the specific book and edition you use.',
  },
];

export const REFERENCE_NOTICE = {
  en: 'Starter list: publisher and organisation websites only — no page numbers or quotations are claimed. Confirm each source yourself, and add the references you actually used.',
  ur: 'ابتدائی فہرست: صرف ناشر یا ادارے کی ویب سائٹس — صفحہ نمبر یا اقتباسات کا دعویٰ نہیں۔ ہر ماخذ کی خود تصدیق کریں اور وہی حوالہ جات درج کریں جو آپ نے واقعی استعمال کیے۔',
};