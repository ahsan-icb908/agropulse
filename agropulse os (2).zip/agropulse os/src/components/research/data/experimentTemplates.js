// Experiment design templates.
//
// Templates pre-fill the *design* fields. Water levels are supplied as editable
// examples with a stated caution: they are not a universal prescription and must
// be justified by the researcher in the methodology.

export const MUNG_BEAN_TEMPLATE = {
  id: 'mung_water',
  labelKey: 'research.template.mung',
  cautionKey: 'research.templateNote',
  fields: {
    title:
      'Effect of Water Availability on the Growth of Mung Bean Seedlings: An Experimental Study Using AgroPulse OS',
    research_question:
      'How does water availability affect the growth of mung bean seedlings under controlled conditions?',
    hypothesis:
      'Seedlings receiving an appropriate amount of water will generally demonstrate better growth than seedlings experiencing water deficit, under otherwise comparable conditions.',
    objectives: [
      'Measure the effect of three water levels on the height of mung bean seedlings.',
      'Compare leaf number and germination between the treatment groups.',
      'Report the results with their sample sizes, missing measurements and limitations.',
    ],
    species: 'Vigna radiata (mung bean)',
    variety: '',
    methodology: [
      '1. Fill identical pots with the same soil type and quantity (record the mass).',
      '2. Sow the same number of mung bean seeds per pot at the same depth.',
      '3. Place all pots on the same bench so light and temperature are comparable.',
      '4. Keep every condition the same except the water level stated for each group.',
      '5. Record height (cm), leaf number, water applied (mL) and germination on the chosen schedule.',
      '6. Measure final biomass (g) and soil moisture (%) at the end of the experiment if equipment allows.',
      '7. State the water levels you chose and why, and note any equipment or timing limits.',
    ].join('\n'),
    independent_variable: 'Water applied per pot (mL)',
    dependent_variables: ['Plant height (cm)', 'Leaf number', 'Germination', 'Final biomass (g)'],
    controlled_variables: [
      'Species and seed lot',
      'Soil type and quantity',
      'Pot size',
      'Light conditions and bench position',
      'Measurement schedule and observer',
    ],
    measurement_schedule: 'Every 2 days (adjust to your school timetable)',
    replicates_per_group: 4,
    status: 'planning',
    data_origin: 'real',
    is_demo: false,
  },
  // Editable starting point. The researcher must confirm these levels.
  suggestedTreatments: [
    { name: 'Control — moderate water (example level)', code: 'C', is_control: true, water_ml: 25, water_frequency: 'every 2 days' },
    { name: 'Low water (example level)', code: 'T1', is_control: false, water_ml: 10, water_frequency: 'every 2 days' },
    { name: 'High water (example level)', code: 'T2', is_control: false, water_ml: 50, water_frequency: 'every 2 days' },
  ],
};

export const BLANK_TEMPLATE = {
  id: 'blank',
  labelKey: 'research.blank',
  fields: {
    title: '',
    research_question: '',
    hypothesis: '',
    objectives: [],
    species: '',
    variety: '',
    methodology: '',
    independent_variable: '',
    dependent_variables: [],
    controlled_variables: [],
    measurement_schedule: '',
    replicates_per_group: 3,
    status: 'planning',
    data_origin: 'real',
    is_demo: false,
  },
  suggestedTreatments: [],
};

export const TEMPLATES = [BLANK_TEMPLATE, MUNG_BEAN_TEMPLATE];