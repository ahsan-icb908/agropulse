// Biological explanations for the research lab, in English and Urdu.
//
// These are textbook-level principles. They explain what a pattern could mean;
// they never assert what a particular dataset proves.

export const BIO_CONCEPTS = [
  {
    id: 'uptake',
    icon: 'droplet',
    title: {
      en: 'Water uptake through roots',
      ur: 'جڑوں کے ذریعے پانی کا حصول',
    },
    body: {
      en: 'Root hairs increase the absorbing surface of the root. Water enters the root mainly through the epidermis and root hairs, then moves inward across the cortex towards the xylem, which carries it upward to the shoot. Uptake depends on how much water is available in the root zone and on how freely it can move through the soil.',
      ur: 'جڑ کے روئیں (روٹ ہیئرز) جذب کرنے والی سطح بڑھاتے ہیں۔ پانی بنیادی طور پر جڑ کی بیرونی تہہ اور جڑ کے روئیں سے داخل ہو کر کارٹیکس سے گزرتا ہوا زائلم تک پہنچتا ہے، جو اسے اوپر تنے اور پتوں تک لے جاتا ہے۔ حصول کا انحصار اس بات پر ہے کہ جڑ کے علاقے میں کتنا پانی دستیاب ہے اور وہ مٹی میں کتنی آسانی سے حرکت کر سکتا ہے۔',
    },
  },
  {
    id: 'osmosis',
    icon: 'waves',
    title: {
      en: 'Osmosis and water potential',
      ur: 'اوسموسس اور واٹر پوٹینشل',
    },
    body: {
      en: 'Water moves from a region of higher water potential to a region of lower water potential. In a well-watered soil, soil water potential is higher than inside the root cell, so water enters the cell across the semi-permeable membrane. As soil dries, soil water potential falls and the gradient becomes smaller, so the same plant can take up less water even though its roots are unchanged.',
      ur: 'پانی زیادہ واٹر پوٹینشل والے علاقے سے کم واٹر پوٹینشل والے علاقے کی طرف حرکت کرتا ہے۔ مناسب پانی والی مٹی میں مٹی کا واٹر پوٹینشل جڑ کے خلیے سے زیادہ ہوتا ہے، اس لیے پانی نیم-نفوذ پذیر جھلی سے گزر کر خلیے میں داخل ہوتا ہے۔ مٹی خشک ہونے پر اس کا واٹر پوٹینشل کم ہو جاتا ہے اور فرق چھوٹا رہ جاتا ہے، چنانچہ جڑیں وہی رہتے ہوئے بھی پودا کم پانی لے پاتا ہے۔',
    },
  },
  {
    id: 'transpiration',
    icon: 'wind',
    title: {
      en: 'Transpiration and stomatal regulation',
      ur: 'ٹرانسپیریشن اور اسٹومیٹا کا کنٹرول',
    },
    body: {
      en: 'Most water taken up by a plant is lost as vapour through stomata in the leaves. Guard cells open and close the stomata, balancing carbon dioxide intake for photosynthesis against water loss. When water is short, plants usually close stomata, which reduces transpiration but also reduces carbon dioxide entry and therefore growth.',
      ur: 'پودا جو پانی لیتا ہے اس کا بڑا حصہ پتوں کے اسٹومیٹا سے بخارات کی صورت میں نکل جاتا ہے۔ گارڈ سیل اسٹومیٹا کو کھولتے اور بند کرتے ہیں، اور فوٹوسنتھیسس کے لیے کاربن ڈائی آکسائیڈ کے حصول کو پانی کے ضیاع کے ساتھ متوازن رکھتے ہیں۔ پانی کی کمی پر پودے عام طور پر اسٹومیٹا بند کر دیتے ہیں، جس سے ٹرانسپیریشن تو کم ہوتی ہے مگر کاربن ڈائی آکسائیڈ کا داخلہ بھی کم ہو جاتا ہے اور نشوونما سست پڑ جاتی ہے۔',
    },
  },
  {
    id: 'photosynthesis',
    icon: 'sun',
    title: {
      en: 'Photosynthesis and plant growth',
      ur: 'فوٹوسنتھیسس اور پودے کی نشوونما',
    },
    body: {
      en: 'Photosynthesis uses light energy to convert carbon dioxide and water into sugars, releasing oxygen. The sugars are used for respiration and as building material for new cells. Growth therefore depends on water not only as a raw material but also because water shortage forces stomatal closure, limits carbon dioxide supply and reduces cell expansion in growing tissues.',
      ur: 'فوٹوسنتھیسس روشنی کی توانائی سے کاربن ڈائی آکسائیڈ اور پانی کو شکر میں بدلتا ہے اور آکسیجن خارج کرتا ہے۔ یہ شکر تنفس کے لیے اور نئے خلیے بنانے کے لیے استعمال ہوتی ہے۔ اس لیے نشوونما کا تعلق پانی سے صرف ایک خام مادے کے طور پر نہیں: پانی کی کمی اسٹومیٹا بند کراتی ہے، کاربن ڈائی آکسائیڈ کی فراہمی محدود کرتی ہے اور بڑھتے ہوئے حصوں میں خلیوں کی کشادگی کم کر دیتی ہے۔',
    },
  },
  {
    id: 'deficit',
    icon: 'alert',
    title: {
      en: 'Water deficit and plant physiology',
      ur: 'پانی کی کمی اور پودے کی فعلیات',
    },
    body: {
      en: 'Under water deficit, cells lose turgor, leaves may roll or wilt, cell expansion slows before photosynthesis is affected, and stomata close. If the deficit continues, chlorophyll breaks down and leaves yellow, roots may grow deeper in search of water, and eventually tissues die. Height is one of the first measurements to change, which is why it is used here, but height alone does not identify the mechanism.',
      ur: 'پانی کی کمی میں خلیوں کا ٹرگور کم ہو جاتا ہے، پتے مڑ سکتے ہیں یا مرجھا سکتے ہیں، خلیوں کی کشادگی فوٹوسنتھیسس پر اثر سے پہلے سست پڑ جاتی ہے اور اسٹومیٹا بند ہو جاتے ہیں۔ کمی جاری رہے تو کلوروفل ٹوٹنے لگتا ہے، پتے زرد پڑتے ہیں، جڑیں پانی کی تلاش میں گہری جا سکتی ہیں اور آخرکار بافتیں مر جاتی ہیں۔ قد ان پہلی پیمائشوں میں سے ہے جن میں تبدیلی نظر آتی ہے، اسی لیے یہاں قد استعمال کیا گیا ہے — مگر صرف قد سے طریقۂ کار کا تعین نہیں ہوتا۔',
    },
  },
  {
    id: 'oxygen',
    icon: 'bubble',
    title: {
      en: 'Root-zone oxygen and waterlogging',
      ur: 'جڑ کے علاقے میں آکسیجن اور پانی کا بھراؤ',
    },
    body: {
      en: 'Root cells respire and need oxygen, which reaches them through air spaces in the soil. When soil pores fill with water, air is displaced and oxygen becomes scarce. In waterlogged pots, roots may be damaged, nutrient uptake falls and some species show yellowing or stunted growth — so a group given a very large volume of water is not automatically the fastest-growing group.',
      ur: 'جڑ کے خلیے تنفس کرتے ہیں اور انہیں آکسیجن درکار ہے، جو مٹی کے ہوا کے خلاوں سے پہنچتی ہے۔ جب مٹی کے سوراخ پانی سے بھر جائیں تو ہوا ہٹ جاتی ہے اور آکسیجن کم پڑ جاتی ہے۔ پانی میں ڈوبے گملوں میں جڑیں خراب ہو سکتی ہیں، غذائی اجزا کا حصول گھٹ جاتا ہے اور بعض انواع میں پتے زرد یا نشوونما رکی ہوئی دکھائی دیتی ہے — اس لیے سب سے زیادہ پانی دینے والا گروپ لازماً سب سے تیز بڑھنے والا نہیں ہوتا۔',
    },
  },
  {
    id: 'interpretation',
    icon: 'scale',
    title: {
      en: 'How the design shapes interpretation',
      ur: 'تجربے کی تشکیل اور نتائج کی تشریح',
    },
    body: {
      en: 'A difference between group means shows an association within this experiment, not proof of cause. Confounding factors — unequal light, pot position, soil compaction, seed quality, a single observer changing technique — can produce the same pattern. Small samples make means unstable, repeated readings of one plant do not add independent evidence, and survival differences can make later averages look better or worse for reasons unrelated to the treatment. A conclusion should therefore state what was measured, how many independent plants supported it, and what could not be ruled out.',
      ur: 'گروپوں کے اوسط میں فرق اس تجربے میں ایک تعلق دکھاتا ہے، سبب کا ثبوت نہیں۔ چھپے ہوئے عوامل — روشنی کا فرق، گملوں کی جگہ، مٹی کا دباؤ، بیج کا معیار یا ایک ہی مبصر کا طریقہ بدل جانا — بھی یہی نمونہ پیدا کر سکتے ہیں۔ چھوٹے نمونوں کے اوسط غیر مستحکم ہوتے ہیں، ایک ہی پودے کی بار بار پیمائش آزاد ثبوت نہیں بڑھاتی، اور زندہ بچ جانے والے پودوں کی تعداد کا فرق بھی اوسط کو ٹریٹمنٹ سے غیر متعلق وجوہات پر بدل سکتا ہے۔ اس لیے نتیجے میں یہ لکھا جانا چاہیے کہ کیا ناپا گیا، کتنے آزاد پودوں نے اس کی تائید کی، اور کون سے عوامل خارج نہیں کیے جا سکے۔',
    },
  },
];

export const INTERPRETATION_CAUTION = {
  en: 'A pattern in your saved records describes this experiment. It does not by itself prove the mechanism explained above — alternative explanations are listed with every conclusion.',
  ur: 'آپ کے محفوظ ریکارڈ کا نمونہ اسی تجربے کو بیان کرتا ہے۔ یہ بذات خود اوپر بیان کردہ طریقۂ کار کو ثابت نہیں کرتا — ہر نتیجے کے ساتھ متبادل تشریحات بھی درج ہیں۔',
};

export const JUDGE_QUESTIONS = [
  {
    en: 'What exactly was your independent variable, and which conditions did you keep identical between groups?',
    ur: 'آپ کا آزاد متغیر بالکل کیا تھا، اور کون سی شرائط آپ نے گروپوں میں یکساں رکھیں؟',
  },
  {
    en: 'How many independent plants supported each mean, and how were repeated readings of the same plant handled?',
    ur: 'ہر اوسط کی تائید کتنے آزاد پودوں نے کی، اور ایک ہی پودے کی بار بار پیمائش کو کیسے شمار کیا گیا؟',
  },
  {
    en: 'Why did you choose those particular water levels, and what evidence supports that choice?',
    ur: 'آپ نے پانی کی وہ خاص سطحیں کیوں منتخب کیں، اور اس انتخاب کا کیا ثبوت ہے؟',
  },
  {
    en: 'Which measurements were missing or estimated, and how did that affect your means?',
    ur: 'کون سی پیمائشیں غائب یا تخمینی تھیں، اور اس کا آپ کے اوسط پر کیا اثر پڑا؟',
  },
  {
    en: 'Could any other factor explain the difference you observed, and how did you control it?',
    ur: 'آپ نے جو فرق دیکھا اس کی کوئی اور وجہ بھی ہو سکتی ہے؟ آپ نے اسے کیسے قابو کیا؟',
  },
  {
    en: 'What would you change in a repeat of this experiment, and why?',
    ur: 'یہ تجربہ دوبارہ کرتے تو آپ کیا تبدیل کرتے، اور کیوں؟',
  },
];