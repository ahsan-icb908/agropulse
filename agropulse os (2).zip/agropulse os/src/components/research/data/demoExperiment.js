// Demonstration dataset for the Biology Research Lab.
//
// Every value below is SIMULATED and illustrative. It exists so a researcher can
// explore the interface, charts and calculations before collecting real data.
// It is labelled DEMO DATA everywhere in the app, it lives in its own records,
// and it must never be presented as a real measurement or a completed study.

export const DEMO_DAYS = [0, 2, 4, 6, 8, 10, 12, 14];

// Water levels are EXAMPLE levels chosen for this demonstration only. They are
// not a universal recommendation; a real design must justify its own levels.
export const DEMO_GROUPS = [
  {
    code: 'C',
    name: 'Moderate water — control (example level)',
    water_ml: 25,
    water_frequency: 'every 2 days',
    is_control: true,
    level_note: 'Example level used for this demonstration dataset, not a universal optimum.',
    condition: 'healthy',
    base: [0, 2.0, 4.1, 6.2, 8.4, 10.5, 12.3, 13.8],
    biomass: [2.6, 2.8, 2.4, 2.5],
    moisture: 24,
  },
  {
    code: 'T1',
    name: 'Low water — deficit (example level)',
    water_ml: 10,
    water_frequency: 'every 2 days',
    is_control: false,
    level_note: 'Example deficit level for this demonstration dataset.',
    condition: 'moderate_stress',
    base: [0, 1.2, 2.1, 3.0, 3.6, 4.2, 4.6, 4.9],
    biomass: [1.1, 1.3, 1.0, null],
    moisture: 12,
  },
  {
    code: 'T2',
    name: 'High water — excess (example level)',
    water_ml: 50,
    water_frequency: 'every 2 days',
    is_control: false,
    level_note: 'Example excess level for this demonstration dataset.',
    condition: 'mild_stress',
    base: [0, 1.8, 3.6, 5.2, 6.8, 8.1, 9.0, 9.6],
    biomass: [2.0, 2.1, 1.9, 2.0],
    moisture: 38,
  },
];

const PLANT_OFFSETS = [0, 0.4, -0.3, 0.2];
const LEAF_BASE = [0, 0, 2, 3, 4, 5, 6, 7];
export const DEMO_PLANTS_PER_GROUP = 4;

const round1 = (n) => Math.round(n * 10) / 10;

export const DEMO_TITLE =
  '[DEMONSTRATION] Effect of Water Availability on the Growth of Mung Bean Seedlings';

export const DEMO_NOTE =
  'Simulated demonstration dataset created inside AgroPulse OS to explore the interface, charts and calculations before real data collection. These are not real measurements and this is not a completed scientific experiment.';

function isoDate(startISO, offsetDays) {
  const d = new Date(`${startISO}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + offsetDays);
  return d.toISOString().slice(0, 10);
}

// Deterministic: the same start date always produces the same dataset.
export function buildDemoDataset({ startDate } = {}) {
  const start = startDate || new Date().toISOString().slice(0, 10);

  const treatments = DEMO_GROUPS.map((g, index) => ({
    name: g.name,
    code: g.code,
    is_control: g.is_control,
    water_ml: g.water_ml,
    water_frequency: g.water_frequency,
    plants_planned: DEMO_PLANTS_PER_GROUP,
    soil_type: 'Garden loam, sieved (same batch for every group)',
    soil_quantity: '300 g per pot',
    pot_size: 'Small plastic pot, 8 cm diameter',
    light_conditions: 'Same bench, natural daylight, no direct noon sun',
    level_note: g.level_note,
    description: 'Demonstration group. Conditions kept identical except the water level.',
    sort_order: index,
    is_demo: true,
  }));

  const plants = [];
  const rows = [];

  DEMO_GROUPS.forEach((group) => {
    for (let i = 0; i < DEMO_PLANTS_PER_GROUP; i += 1) {
      const plantCode = `${group.code}-${i + 1}`;
      plants.push({
        treatment_code: group.code,
        plant_code: plantCode,
        label: `Pot ${i + 1}`,
        is_demo: true,
      });

      const germinated = !(group.code === 'T1' && i === 3);

      DEMO_DAYS.forEach((offset, dayIndex) => {
        const date = isoDate(start, offset);

        // The plant that never emerged is reported honestly as not germinated
        // and its missing measurements are flagged instead of being filled in.
        if (!germinated) {
          if (dayIndex === 1) {
            rows.push({
              treatment_code: group.code,
              plant_code: plantCode,
              observation_date: date,
              record_type: 'demonstration',
              germinated: false,
              plant_condition: 'not_germinated',
              water_ml: group.water_ml,
              missing_fields: ['height_cm', 'leaf_count'],
              notes: 'No shoot emerged in this pot during the demonstration period.',
              is_demo: true,
            });
          }
          return;
        }

        const ramp = dayIndex / (DEMO_DAYS.length - 1);
        const height = dayIndex === 0 ? 0 : round1(group.base[dayIndex] + PLANT_OFFSETS[i] * ramp);
        const leaves = Math.max(0, LEAF_BASE[dayIndex] + (i === 1 && dayIndex > 3 ? 1 : 0));
        const isLastDay = dayIndex === DEMO_DAYS.length - 1;

        const row = {
          treatment_code: group.code,
          plant_code: plantCode,
          observation_date: date,
          record_type: 'demonstration',
          height_cm: height,
          leaf_count: leaves,
          water_ml: group.water_ml,
          germinated: dayIndex === 1 ? true : undefined,
          plant_condition: group.condition,
          is_demo: true,
          notes: isLastDay ? 'Final demonstration reading.' : undefined,
        };

        if (isLastDay) {
          const biomass = group.biomass[i];
          if (biomass !== null && biomass !== undefined) row.biomass_g = biomass;
          else row.missing_fields = ['biomass_g'];
          row.soil_moisture_percent = group.moisture;
        }

        rows.push(row);
      });
    }
  });

  return {
    experiment: {
      title: DEMO_TITLE,
      research_question:
        'How does water availability affect the growth of mung bean seedlings under controlled conditions?',
      hypothesis:
        'Seedlings receiving an appropriate amount of water will generally demonstrate better growth than seedlings experiencing water deficit, under otherwise comparable conditions.',
      objectives: [
        'Compare the growth of mung bean seedlings across three controlled water levels.',
        'Measure plant height, leaf number and germination over a two-week period.',
        'Practise recording observations, calculating means and reporting uncertainty honestly.',
      ],
      species: 'Vigna radiata (mung bean)',
      variety: 'Not specified in this demonstration dataset',
      start_date: start,
      end_date: isoDate(start, DEMO_DAYS[DEMO_DAYS.length - 1]),
      methodology: [
        'DEMONSTRATION DATASET — simulated values, not measurements.',
        'Twelve pots were represented in three groups of four, differing only in water applied.',
        'Height (cm), leaf number, water applied (mL) and germination were recorded on days 0, 2, 4, 6, 8, 10, 12 and 14.',
        'Final biomass (g) and soil moisture (%) were represented on the last day only.',
      ].join('\n'),
      independent_variable: 'Water applied per pot (mL)',
      dependent_variables: ['Plant height (cm)', 'Leaf number', 'Germination', 'Final biomass (g)'],
      controlled_variables: [
        'Species and seed lot',
        'Soil type and quantity',
        'Pot size',
        'Light and bench position',
        'Measurement schedule and observer',
      ],
      measurement_schedule: 'Every 2 days, 8 readings over 14 days',
      replicates_per_group: DEMO_PLANTS_PER_GROUP,
      status: 'demonstration',
      data_origin: 'demonstration',
      is_demo: true,
      notes: DEMO_NOTE,
    },
    treatments,
    plants,
    rows,
  };
}