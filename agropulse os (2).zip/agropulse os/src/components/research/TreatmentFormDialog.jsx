import { useEffect, useState } from 'react';
import { Loader2 } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';

const EMPTY = {
  name: '',
  code: '',
  is_control: false,
  water_ml: '',
  water_frequency: '',
  plants_planned: '',
  soil_type: '',
  soil_quantity: '',
  pot_size: '',
  light_conditions: '',
  temperature_c: '',
  level_note: '',
  description: '',
};

function Field({ label, children }) {
  return (
    <div>
      <Label>{label}</Label>
      {children}
    </div>
  );
}

export default function TreatmentFormDialog({ open, onOpenChange, treatment, sortOrder = 0, onSave }) {
  const { t } = useI18n();
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (open) {
      setError('');
      setForm(treatment ? { ...EMPTY, ...treatment } : EMPTY);
    }
  }, [open, treatment]);

  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  async function submit() {
    if (!form.name.trim()) {
      setError('A group name is required.');
      return;
    }
    const numbers = [
      ['water_ml', form.water_ml],
      ['plants_planned', form.plants_planned],
      ['temperature_c', form.temperature_c],
    ];
    const parsed = {};
    for (const [key, raw] of numbers) {
      if (raw === '' || raw === undefined || raw === null) {
        parsed[key] = undefined;
        continue;
      }
      const value = Number(raw);
      if (!Number.isFinite(value) || value < 0) {
        setError('Water volume, plant count and temperature must be numbers of zero or more.');
        return;
      }
      if (key === 'plants_planned' && !Number.isInteger(value)) {
        setError('Plant count must be a whole number.');
        return;
      }
      parsed[key] = value;
    }

    setSaving(true);
    try {
      await onSave({
        ...form,
        ...parsed,
        sort_order: treatment?.sort_order ?? sortOrder,
      });
      onOpenChange(false);
    } catch (e) {
      setError(e?.message || 'Could not save this group.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>{treatment ? t('research.editTreatment') : t('research.addTreatment')}</DialogTitle>
          <DialogDescription>{t('research.waterLevelsCaution')}</DialogDescription>
        </DialogHeader>

        <div className="space-y-3 py-1">
          <Field label={t('research.fieldTreatmentName')}>
            <Input value={form.name} onChange={set('name')} className="mt-1" placeholder="Low water (10 mL)" />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label={t('research.code')}>
              <Input value={form.code} onChange={set('code')} className="mt-1" placeholder="T1" />
            </Field>
            <Field label={t('research.waterMl')}>
              <Input type="number" min="0" value={form.water_ml} onChange={set('water_ml')} className="mt-1" />
            </Field>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <Field label={t('research.frequency')}>
              <Input value={form.water_frequency} onChange={set('water_frequency')} className="mt-1" placeholder="every 2 days" />
            </Field>
            <Field label={t('research.plantsPlanned')}>
              <Input type="number" min="0" value={form.plants_planned} onChange={set('plants_planned')} className="mt-1" />
            </Field>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <Field label={t('research.soil')}>
              <Input value={form.soil_type} onChange={set('soil_type')} className="mt-1" />
            </Field>
            <Field label={t('research.pot')}>
              <Input value={form.pot_size} onChange={set('pot_size')} className="mt-1" />
            </Field>
            <Field label={t('research.temperature')}>
              <Input type="number" value={form.temperature_c} onChange={set('temperature_c')} className="mt-1" placeholder="°C" />
            </Field>
          </div>
          <Field label={t('research.light')}>
            <Input value={form.light_conditions} onChange={set('light_conditions')} className="mt-1" />
          </Field>
          <Field label={t('research.levelNote')}>
            <Textarea value={form.level_note} onChange={set('level_note')} rows={2} className="mt-1" />
          </Field>
          <div className="flex items-center justify-between rounded-xl border border-border p-3">
            <div>
              <p className="text-sm font-medium">{t('research.markControl')}</p>
              <p className="text-[11px] text-muted-foreground">{t('research.markControlHint')}</p>
            </div>
            <Switch checked={Boolean(form.is_control)} onCheckedChange={(v) => setForm({ ...form, is_control: v })} />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t('common.cancel')}
          </Button>
          <Button onClick={submit} disabled={saving} className="gap-2">
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            {t('common.save')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}