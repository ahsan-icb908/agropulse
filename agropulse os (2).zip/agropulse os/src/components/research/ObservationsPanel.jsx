import { useMemo, useState } from 'react';
import { Download, Pencil, Plus, Trash2 } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import EvidenceBadge from './EvidenceBadge';
import DemoNotice from './DemoNotice';
import ObservationFormDialog from './ObservationFormDialog';
import { deleteObservation, exportObservationsCsv } from '@/lib/biology/researchStore';
import { valueOf } from '@/lib/biology/calculations';

const COLUMNS = ['plant_code', 'treatment_code', 'observation_date', 'height_cm', 'leaf_count', 'water_ml', 'soil_moisture_percent', 'biomass_g', 'plant_condition'];

export default function ObservationsPanel({ ctx }) {
  const { t } = useI18n();
  const { experiment, plants, treatments, observations, treatmentsById, reload } = ctx;
  const [filters, setFilters] = useState({ treatment_id: 'all', plant_id: 'all', from: '', to: '', record_type: 'all' });
  const [dialog, setDialog] = useState({ open: false, observation: null });
  const [exported, setExported] = useState(0);

  const filtered = useMemo(
    () =>
      observations.filter((o) => {
        if (filters.treatment_id !== 'all' && o.treatment_id !== filters.treatment_id) return false;
        if (filters.plant_id !== 'all' && o.plant_id !== filters.plant_id) return false;
        if (filters.record_type !== 'all' && (o.record_type || 'real') !== filters.record_type) return false;
        if (filters.from && o.observation_date < filters.from) return false;
        if (filters.to && o.observation_date > filters.to) return false;
        return true;
      }),
    [observations, filters]
  );

  const groupPlants = plants.filter(
    (p) => filters.treatment_id === 'all' || p.treatment_id === filters.treatment_id
  );
  const missingCount = filtered.filter((o) => o.record_type === 'missing' || valueOf(o, 'height_cm') === null).length;
  const hasDemoRows = filtered.some((o) => o.is_demo || o.record_type === 'demonstration');

  const remove = async (observation) => {
    if (!window.confirm(t('research.confirmDeleteObservation'))) return;
    await deleteObservation(observation.id);
    reload();
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.tab.observations')}</h2>
          <p className="text-xs text-muted-foreground">{t('research.numericHint')}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            size="sm"
            variant="outline"
            className="gap-1.5"
            disabled={filtered.length === 0}
            onClick={() => setExported(exportObservationsCsv({ experiment, observations: filtered, treatmentsById }))}
          >
            <Download className="h-3.5 w-3.5" />
            {t('research.exportCsv')}
          </Button>
          <Button size="sm" className="gap-1.5" onClick={() => setDialog({ open: true, observation: null })}>
            <Plus className="h-3.5 w-3.5" />
            {t('research.addObservation')}
          </Button>
        </div>
      </div>

      {hasDemoRows && <DemoNotice />}
      {exported > 0 && (
        <p className="text-xs text-muted-foreground">
          {exported} {t('research.recordsShown')} — CSV
        </p>
      )}

      <Widget className="p-3 sm:p-4">
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
          <Select value={filters.treatment_id} onValueChange={(v) => setFilters({ ...filters, treatment_id: v, plant_id: 'all' })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('research.allTreatments')}</SelectItem>
              {treatments.map((treatment) => (
                <SelectItem key={treatment.id} value={treatment.id}>
                  {treatment.code} — {treatment.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filters.plant_id} onValueChange={(v) => setFilters({ ...filters, plant_id: v })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('research.allPlants')}</SelectItem>
              {groupPlants.map((plant) => (
                <SelectItem key={plant.id} value={plant.id}>
                  {plant.plant_code}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={filters.record_type} onValueChange={(v) => setFilters({ ...filters, record_type: v })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">{t('research.recordType')}: {t('common.all')}</SelectItem>
              <SelectItem value="real">{t('research.badge.real')}</SelectItem>
              <SelectItem value="estimated">{t('research.badge.estimated')}</SelectItem>
              <SelectItem value="missing">{t('research.badge.missing')}</SelectItem>
              <SelectItem value="demonstration">{t('research.badge.demo')}</SelectItem>
            </SelectContent>
          </Select>
          <Input type="date" value={filters.from} onChange={(e) => setFilters({ ...filters, from: e.target.value })} />
          <Input type="date" value={filters.to} onChange={(e) => setFilters({ ...filters, to: e.target.value })} />
        </div>
        <p className="mt-3 text-xs text-muted-foreground">
          {filtered.length} {t('research.recordsShown')} • {missingCount} {t('research.missingCount')}
        </p>
      </Widget>

      {observations.length === 0 ? (
        <Widget className="p-8 text-center text-sm text-muted-foreground">{t('research.noObservationsYet')}</Widget>
      ) : (
        <Widget className="overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[900px] text-sm">
              <thead className="bg-muted/60 text-xs">
                <tr>
                  <th className="p-2.5 text-start font-medium">{t('research.recordType')}</th>
                  {COLUMNS.map((column) => (
                    <th key={column} className="p-2.5 text-start font-medium">
                      {t(`research.${column === 'plant_code' ? 'field.plant' : column === 'treatment_code' ? 'field.treatment' : column === 'observation_date' ? 'field.date' : column === 'height_cm' ? 'heightCm' : column === 'leaf_count' ? 'leafCount' : column === 'water_ml' ? 'waterMl' : column === 'soil_moisture_percent' ? 'soilMoisturePct' : column === 'biomass_g' ? 'biomassG' : 'plantCondition'}`)}
                    </th>
                  ))}
                  <th className="p-2.5 text-start font-medium">{t('research.recordCreated')}</th>
                  <th className="p-2.5" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((observation) => (
                  <tr key={observation.id} className="border-t border-border align-top">
                    <td className="p-2.5">
                      <EvidenceBadge type={observation.record_type || 'real'} />
                    </td>
                    <td className="p-2.5 font-medium">{observation.plant_code}</td>
                    <td className="p-2.5">{treatmentsById[observation.treatment_id]?.code || observation.treatment_code || '—'}</td>
                    <td className="p-2.5 whitespace-nowrap">{observation.observation_date}</td>
                    {['height_cm', 'leaf_count', 'water_ml', 'soil_moisture_percent', 'biomass_g'].map((field) => (
                      <td key={field} className="p-2.5">
                        {observation[field] !== undefined && observation[field] !== null ? observation[field] : '—'}
                      </td>
                    ))}
                    <td className="p-2.5">{observation.plant_condition ? t(`research.condition.${observation.plant_condition}`) : '—'}</td>
                    <td className="p-2.5 whitespace-nowrap text-[11px] text-muted-foreground">
                      {observation.created_date ? String(observation.created_date).slice(0, 16).replace('T', ' ') : '—'}
                    </td>
                    <td className="p-2.5">
                      <div className="flex items-center justify-end gap-1">
                        <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setDialog({ open: true, observation })}>
                          <Pencil className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 text-muted-foreground hover:text-destructive"
                          onClick={() => remove(observation)}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && (
            <p className="p-6 text-center text-sm text-muted-foreground">{t('common.empty')}</p>
          )}
        </Widget>
      )}

      <ObservationFormDialog
        ctx={ctx}
        observation={dialog.observation}
        open={dialog.open}
        onOpenChange={(open) => setDialog({ open, observation: open ? dialog.observation : null })}
      />

    </div>
  );
}