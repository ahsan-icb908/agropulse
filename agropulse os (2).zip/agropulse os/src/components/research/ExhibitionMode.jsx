import { useState } from 'react';
import { ChevronLeft, ChevronRight, Printer } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import EvidenceBadge from './EvidenceBadge';
import DemoNotice from './DemoNotice';
import { HeightChart, LeafChart, MeanBarChart } from './MiniCharts';
import { useChartData } from './useChartData';
import { BIO_CONCEPTS, INTERPRETATION_CAUTION } from './data/biologyExplanations';
import { formatValue, summariseByGroup } from '@/lib/biology/calculations';

// Presentation view for one selected experiment. Every slide carries the
// evidence label, so a demonstration dataset can never look like real data.
export default function ExhibitionMode({ ctx }) {
  const { t, lang } = useI18n();
  const { experiment, treatments, plants, observations, treatmentsById } = ctx;
  const data = useChartData(ctx);
  const [index, setIndex] = useState(0);
  const isDemo = Boolean(experiment.is_demo);
  const heightByGroup = summariseByGroup(observations, 'height_cm');

  const slides = [
    {
      key: 'title',
      title: experiment.title,
      body: (
        <div className="space-y-4">
          <p className="text-sm leading-relaxed text-muted-foreground">{experiment.research_question || '—'}</p>
          <div className="flex flex-wrap gap-2">
            <Badge variant="outline" className="text-[11px]">
              {t(`research.status.${experiment.status || 'planning'}`)}
            </Badge>
            {experiment.species && <Badge variant="secondary" className="text-[11px]">{experiment.species}</Badge>}
            <Badge variant="outline" className="text-[11px]">
              {t('research.independentPlants')}: {data.independentPlants}
            </Badge>
          </div>
        </div>
      ),
    },
    {
      key: 'background',
      title: t('research.exhibition.background'),
      body: (
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
          {BIO_CONCEPTS.slice(0, 4).map((concept) => (
            <div key={concept.id} className="rounded-xl border border-border p-3">
              <p className="font-heading text-sm font-semibold">{lang === 'ur' ? concept.title.ur : concept.title.en}</p>
              <p dir={lang === 'ur' ? 'rtl' : 'ltr'} className="mt-1 text-xs leading-relaxed text-muted-foreground">
                {lang === 'ur' ? concept.body.ur : concept.body.en}
              </p>
            </div>
          ))}
        </div>
      ),
    },
    {
      key: 'hypothesis',
      title: t('research.hypothesis'),
      body: (
        <div className="space-y-3">
          <p className="text-sm leading-relaxed">{experiment.hypothesis || '—'}</p>
          <p className="text-xs text-muted-foreground">
            {t('research.outcome')}: {t(`research.outcome.${experiment.hypothesis_outcome || 'not_assessed'}`)}
          </p>
        </div>
      ),
    },
    {
      key: 'setup',
      title: t('research.exhibition.setup'),
      body: (
        <div className="space-y-3">
          <ul className="space-y-1 text-xs">
            <li>
              <span className="text-muted-foreground">{t('research.independentVar')}:</span> {experiment.independent_variable || '—'}
            </li>
            <li>
              <span className="text-muted-foreground">{t('research.dependentVars')}:</span>{' '}
              {(experiment.dependent_variables || []).join(', ') || '—'}
            </li>
            <li>
              <span className="text-muted-foreground">{t('research.controlledVars')}:</span>{' '}
              {(experiment.controlled_variables || []).join(', ') || '—'}
            </li>
          </ul>
          <p className="whitespace-pre-line text-xs leading-relaxed text-muted-foreground">{experiment.methodology || '—'}</p>
        </div>
      ),
    },
    {
      key: 'groups',
      title: t('research.field.treatment'),
      body: (
        <div className="overflow-x-auto">
          <table className="w-full min-w-[520px] text-xs">
            <thead className="bg-muted/60">
              <tr>
                <th className="p-2 text-start font-medium">{t('research.code')}</th>
                <th className="p-2 text-start font-medium">{t('research.fieldTreatmentName')}</th>
                <th className="p-2 text-start font-medium">{t('research.waterMl')}</th>
                <th className="p-2 text-start font-medium">{t('research.plantsPlanned')}</th>
                <th className="p-2 text-start font-medium">{t('research.soil')}</th>
              </tr>
            </thead>
            <tbody>
              {treatments.map((treatment) => (
                <tr key={treatment.id} className="border-t border-border">
                  <td className="p-2">{treatment.code || '—'}</td>
                  <td className="p-2">
                    {treatment.name}
                    {treatment.is_control ? ` (${t('research.control')})` : ''}
                  </td>
                  <td className="p-2">{treatment.water_ml ?? '—'}</td>
                  <td className="p-2">{plants.filter((p) => p.treatment_id === treatment.id).length}</td>
                  <td className="p-2">{treatment.soil_type || '—'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ),
    },
    {
      key: 'summary',
      title: t('research.exhibition.summary'),
      body: (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {[
            [t('research.observationsCount'), data.quality.total],
            [t('research.independentPlants'), data.independentPlants],
            [t('research.missingCount'), data.quality.missing],
            [t('research.calc.germination'), data.germinationOverall.percent === null ? '—' : `${data.germinationOverall.percent}%`],
          ].map(([label, value]) => (
            <div key={label} className="rounded-xl border border-border p-3 text-center">
              <p className="font-heading text-2xl font-bold">{value}</p>
              <p className="text-[11px] text-muted-foreground">{label}</p>
            </div>
          ))}
        </div>
      ),
    },
    {
      key: 'charts',
      title: t('research.exhibition.charts'),
      body: (
        <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
          <HeightChart
            data={data.heightChartRows}
            codes={data.codes}
            plants={data.independentPlants}
            empty={data.heightChartRows.length ? null : t('research.noChartData')}
          />
          <LeafChart data={data.leafChartRows} codes={data.codes} empty={data.leafChartRows.length ? null : t('research.noChartData')} />
        </div>
      ),
    },
    {
      key: 'calculations',
      title: t('research.exhibition.calculations'),
      body: (
        <div className="space-y-3">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[600px] text-xs">
              <thead className="bg-muted/60">
                <tr>
                  <th className="p-2 text-start font-medium">{t('research.field.treatment')}</th>
                  <th className="p-2 text-start font-medium">{t('research.field.height')} (cm)</th>
                  <th className="p-2 text-start font-medium">{t('research.sd')} (cm)</th>
                  <th className="p-2 text-start font-medium">n</th>
                  <th className="p-2 text-start font-medium">{t('research.independentPlants')}</th>
                  <th className="p-2 text-start font-medium">{t('research.calc.mean_biomass')} (g)</th>
                </tr>
              </thead>
              <tbody>
                {heightByGroup.map((group) => (
                  <tr key={group.treatment_id} className="border-t border-border">
                    <td className="p-2">{treatmentsById[group.treatment_id]?.code || group.treatment_code}</td>
                    <td className="p-2 font-medium">{formatValue(group.mean)}</td>
                    <td className="p-2">{group.sd === null ? t('research.notCalculable') : formatValue(group.sd)}</td>
                    <td className="p-2">{group.n}</td>
                    <td className="p-2">{group.plants}</td>
                    <td className="p-2">
                      {formatValue(data.biomassPerGroup.find((b) => b.code === (treatmentsById[group.treatment_id]?.code || group.treatment_code))?.mean)}
                    </td>
                  </tr>
                ))}
                {heightByGroup.length === 0 && (
                  <tr>
                    <td colSpan={6} className="p-4 text-center text-muted-foreground">
                      {t('research.warn.no_observations')}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
          <div className="grid grid-cols-1 gap-3 lg:grid-cols-2">
            <MeanBarChart
              data={data.groupMeanBar}
              title={t('research.groupMeans')}
              unit="cm"
              empty={data.groupMeanBar.some((g) => g.mean !== null) ? null : t('research.noChartData')}
            />
            <MeanBarChart
              data={data.germinationPerGroup}
              title={t('research.germinationChart')}
              unit="%"
              dataKey="percent"
              withSd={false}
              empty={data.germinationPerGroup.some((g) => g.percent !== null) ? null : t('research.noChartData')}
            />
          </div>
        </div>
      ),
    },
    {
      key: 'results',
      title: t('research.exhibition.results'),
      body: (
        <div className="space-y-3 text-sm leading-relaxed">
          {heightByGroup.length ? (
            <ul className="list-disc space-y-1 ps-5">
              {heightByGroup.map((group) => (
                <li key={group.treatment_id}>
                  {(treatmentsById[group.treatment_id]?.code || group.treatment_code)}: {t('research.field.height')}{' '}
                  {formatValue(group.mean)} cm, {t('research.independentPlants')} {group.plants}
                </li>
              ))}
            </ul>
          ) : (
            <p>{t('research.warn.no_observations')}</p>
          )}
          <p className="text-xs text-muted-foreground">{lang === 'ur' ? INTERPRETATION_CAUTION.ur : INTERPRETATION_CAUTION.en}</p>
          <p className="text-xs text-muted-foreground">{t('research.warn.no_significance')}</p>
          <p className="whitespace-pre-line text-xs">{experiment.conclusion || '—'}</p>
        </div>
      ),
    },
    {
      key: 'limitations',
      title: t('research.exhibition.limitations'),
      body: (
        <div className="space-y-2 text-xs leading-relaxed">
          <p className="whitespace-pre-line">{experiment.limitations || '—'}</p>
          <ul className="list-disc space-y-1 ps-5 text-muted-foreground">
            {data.independentPlants < 3 && <li>{t('research.warn.few_plants')}</li>}
            {data.quality.missing > 0 && <li>{t('research.missingCount')}: {data.quality.missing}</li>}
            <li>{t('research.warn.no_significance')}</li>
          </ul>
          <p className="whitespace-pre-line">{experiment.future_research || '—'}</p>
        </div>
      ),
    },
  ];

  const slide = slides[index];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3 print:hidden">
        <div className="flex items-center gap-2">
          <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.tab.exhibition')}</h2>
          <EvidenceBadge type={isDemo ? 'demonstration' : 'real'} />
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="outline" className="gap-1.5" onClick={() => window.print()}>
            <Printer className="h-3.5 w-3.5" />
            {t('research.print')}
          </Button>
        </div>
      </div>

      {isDemo && <DemoNotice />}

      <Widget className="space-y-4 p-5 print:border-0 print:p-0 print:shadow-none">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-border pb-2">
          <h3 className="font-heading text-base font-semibold leading-snug tracking-tight">{slide.title}</h3>
          <span className="text-[11px] text-muted-foreground">
            {t('research.exhibition.slide')} {index + 1} {t('research.exhibition.of')} {slides.length}
          </span>
        </div>
        {slide.body}
      </Widget>

      <div className="flex items-center justify-between gap-3 print:hidden">
        <Button variant="outline" size="sm" className="gap-1.5" disabled={index === 0} onClick={() => setIndex((i) => i - 1)}>
          <ChevronLeft className="h-3.5 w-3.5 flip-x" />
          {t('research.exhibition.prev')}
        </Button>
        <div className="flex flex-wrap justify-center gap-1.5">
          {slides.map((item, i) => (
            <button
              key={item.key}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={item.title}
              className={`h-2 w-2 rounded-full transition-colors ${i === index ? 'bg-primary' : 'bg-border'}`}
            />
          ))}
        </div>
        <Button
          variant="outline"
          size="sm"
          className="gap-1.5"
          disabled={index === slides.length - 1}
          onClick={() => setIndex((i) => i + 1)}
        >
          {t('research.exhibition.next')}
          <ChevronRight className="h-3.5 w-3.5 flip-x" />
        </Button>
      </div>
    </div>
  );
}