import { Badge } from '@/components/ui/badge';
import { useI18n } from '@/i18n/LanguageContext';
import { BADGE } from '@/lib/biology/calculations';
import { cn } from '@/lib/utils';

const TONES = {
  real: 'bg-primary/10 text-primary border-primary/30',
  demonstration: 'bg-amber-500/15 text-amber-700 border-amber-500/40 dark:text-amber-400',
  estimated: 'bg-sky-500/15 text-sky-700 border-sky-500/40 dark:text-sky-400',
  missing: 'bg-destructive/10 text-destructive border-destructive/40',
};

// Evidence label used on every record, chart and slide.
export default function EvidenceBadge({ type = 'real', className }) {
  const { t } = useI18n();
  const tone = TONES[type] || TONES.real;
  const key = (BADGE[type] || BADGE.real).key;
  return (
    <Badge variant="outline" className={cn('text-[10px] font-semibold tracking-wide', tone, className)}>
      {t(key)}
    </Badge>
  );
}