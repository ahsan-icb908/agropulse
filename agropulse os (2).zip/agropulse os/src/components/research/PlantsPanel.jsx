import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Loader2, Plus, Trash2 } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { deletePlant } from '@/lib/biology/researchStore';

export default function PlantsPanel({ ctx }) {
  const { t } = useI18n();
  const { experiment, treatments, plants, observations, reload } = ctx;
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({ treatment_id: '', count: 4, startIndex: 1 });

  async function addPlants() {
    const treatment = treatments.find((tr) => tr.id === form.treatment_id);
    if (!treatment) {
      setError('Choose a treatment group.');
      return;
    }
    const count = Number(form.count);
    const startIndex = Number(form.startIndex);
    if (!Number.isInteger(count) || count < 1 || count > 100) {
      setError('Count must be a whole number between 1 and 100.');
      return;
    }
    if (!Number.isInteger(startIndex) || startIndex < 1) {
      setError('Start number must be a whole number of at least 1.');
      return;
    }

    setSaving(true);
    setError('');
    try {
      const existing = plants.filter((p) => p.treatment_id === treatment.id);
      const payload = [];
      for (let i = 0; i < count; i += 1) {
        const index = startIndex + i;
        const code = `${treatment.code || 'T'}-${index}`;
        if (existing.some((p) => p.plant_code === code)) continue;
        payload.push({
          experiment_id: experiment.id,
          treatment_id: treatment.id,
          treatment_code: treatment.code,
          plant_code: code,
          label: `Pot ${index}`,
          is_demo: Boolean(experiment.is_demo),
        });
      }
      if (payload.length) await base44.entities.ExperimentPlant.bulkCreate(payload);
      setOpen(false);
      reload();
    } catch (e) {
      setError(e?.message || 'Could not create the plants.');
    } finally {
      setSaving(false);
    }
  }

  async function removePlant(plant) {
    if (!window.confirm(t('research.confirmDeletePlant'))) return;
    await deletePlant(plant.id);
    reload();
  }

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.tab.plants')}</h2>
          <p className="text-xs text-muted-foreground">{t('research.addPlantsHint')}</p>
        </div>
        <Button size="sm" className="gap-1.5" onClick={() => setOpen(true)} disabled={treatments.length === 0}>
          <Plus className="h-3.5 w-3.5" />
          {t('research.addPlants')}
        </Button>
      </div>

      {treatments.length === 0 ? (
        <Widget className="p-8 text-center text-sm text-muted-foreground">{t('research.noTreatments')}</Widget>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {treatments.map((treatment) => {
            const groupPlants = plants.filter((p) => p.treatment_id === treatment.id);
            return (
              <Widget key={treatment.id} className="p-4">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-heading text-sm font-semibold">
                    <span className="text-muted-foreground">{treatment.code} </span>
                    {treatment.name}
                  </p>
                  <Badge variant="secondary" className="text-[10px]">
                    {groupPlants.length}
                  </Badge>
                </div>
                {groupPlants.length === 0 ? (
                  <p className="mt-3 text-xs text-muted-foreground">{t('research.noPlants')}</p>
                ) : (
                  <ul className="mt-3 divide-y divide-border">
                    {groupPlants.map((plant) => {
                      const plantObservations = observations.filter((o) => o.plant_id === plant.id);
                      return (
                        <li key={plant.id} className="flex items-center justify-between gap-2 py-2">
                          <div className="min-w-0">
                            <p className="text-sm font-medium">{plant.plant_code}</p>
                            <p className="text-[11px] text-muted-foreground">
                              {plant.label ? `${plant.label} • ` : ''}
                              {plantObservations.length} {t('research.observationsCount')}
                            </p>
                          </div>
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-8 w-8 text-muted-foreground hover:text-destructive"
                            onClick={() => removePlant(plant)}
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </Button>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </Widget>
            );
          })}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>{t('research.addPlants')}</DialogTitle>
            <DialogDescription>{t('research.addPlantsHint')}</DialogDescription>
          </DialogHeader>
          <div className="space-y-3 py-1">
            <div>
              <Label>{t('research.field.treatment')}</Label>
              <Select value={form.treatment_id} onValueChange={(v) => setForm({ ...form, treatment_id: v })}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {treatments.map((treatment) => (
                    <SelectItem key={treatment.id} value={treatment.id}>
                      {treatment.code} — {treatment.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>{t('research.count')}</Label>
                <Input
                  type="number"
                  min="1"
                  value={form.count}
                  onChange={(e) => setForm({ ...form, count: e.target.value })}
                  className="mt-1"
                />
              </div>
              <div>
                <Label>{t('research.startIndex')}</Label>
                <Input
                  type="number"
                  min="1"
                  value={form.startIndex}
                  onChange={(e) => setForm({ ...form, startIndex: e.target.value })}
                  className="mt-1"
                />
              </div>
            </div>
            {error && <p className="text-sm text-destructive">{error}</p>}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>
              {t('common.cancel')}
            </Button>
            <Button onClick={addPlants} disabled={saving} className="gap-2">
              {saving && <Loader2 className="h-4 w-4 animate-spin" />}
              {t('research.addPlants')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}