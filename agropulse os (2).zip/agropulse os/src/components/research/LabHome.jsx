import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FlaskConical, Loader2, Plus, RotateCcw, Sparkles } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget, WidgetBody, WidgetHeader } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import ExperimentCard from './ExperimentCard';
import NewExperimentDialog from './NewExperimentDialog';
import DemoNotice from './DemoNotice';
import { useCollection } from '@/hooks/useCollection';
import {
  deleteExperimentCascade,
  duplicateExperiment,
  loadExperimentBundle,
  resetDemoData,
  seedDemoExperiment,
  setExperimentStatus,
} from '@/lib/biology/researchStore';

export default function LabHome() {
  const { t } = useI18n();
  const navigate = useNavigate();
  const { data: experiments, loading, reload } = useCollection('BiologyExperiment', {
    sort: '-created_date',
    limit: 200,
  });
  const [busy, setBusy] = useState('');
  const [error, setError] = useState('');

  const demo = experiments.find((e) => e.is_demo);
  const real = experiments.filter((e) => !e.is_demo);

  async function withBusy(label, fn) {
    setBusy(label);
    setError('');
    try {
      await fn();
    } catch (e) {
      setError(e?.message || 'Something went wrong. Please try again.');
    } finally {
      setBusy('');
    }
  }

  const loadDemo = () =>
    withBusy('demo', async () => {
      const id = await seedDemoExperiment();
      reload();
      navigate(`/research/${id}`);
    });

  const resetDemo = () =>
    withBusy('reset', async () => {
      await resetDemoData();
      reload();
    });

  const duplicate = (experiment) =>
    withBusy('duplicate', async () => {
      const bundle = await loadExperimentBundle(experiment.id);
      await duplicateExperiment(bundle.experiment, bundle.treatments, bundle.plants);
      reload();
    });

  return (
    <div className="space-y-6">
      <header className="flex items-start gap-3">
        <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-primary/10 text-primary">
          <FlaskConical className="h-6 w-6" />
        </span>
        <div className="min-w-0">
          <h1 className="font-heading text-2xl font-bold tracking-tight">{t('research.title')}</h1>
          <p className="text-sm text-muted-foreground">{t('research.subtitle')}</p>
        </div>
      </header>

      {error && <p className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">{error}</p>}

      {/* Two ways in: labelled demonstration, or a real experiment */}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Widget className="border-amber-500/40 bg-amber-500/5">
          <WidgetHeader title={t('research.chooseDemo')} icon={Sparkles} />
          <WidgetBody className="space-y-3">
            <p className="text-sm leading-relaxed text-muted-foreground">{t('research.chooseDemoHint')}</p>
            {demo ? (
              <div className="flex flex-wrap gap-2">
                <Button onClick={() => navigate(`/research/${demo.id}`)} className="gap-2">
                  <FlaskConical className="h-4 w-4" />
                  {t('research.open')}
                </Button>
                <Button variant="outline" onClick={resetDemo} disabled={busy === 'reset'} className="gap-2">
                  {busy === 'reset' ? <Loader2 className="h-4 w-4 animate-spin" /> : <RotateCcw className="h-4 w-4" />}
                  {t('research.resetDemo')}
                </Button>
              </div>
            ) : (
              <Button onClick={loadDemo} disabled={busy === 'demo'} className="gap-2">
                {busy === 'demo' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
                {t('research.chooseDemo')}
              </Button>
            )}
            <p className="text-[11px] leading-relaxed text-muted-foreground">{t('research.resetDemoHint')}</p>
          </WidgetBody>
        </Widget>

        <Widget className="border-primary/30 bg-primary/5">
          <WidgetHeader title={t('research.chooseNew')} icon={Plus} />
          <WidgetBody className="space-y-3">
            <p className="text-sm leading-relaxed text-muted-foreground">{t('research.chooseNewHint')}</p>
            <NewExperimentDialog
              onCreated={(experiment) => {
                reload();
                navigate(`/research/${experiment.id}`);
              }}
              trigger={
                <Button className="gap-2">
                  <Plus className="h-4 w-4" />
                  {t('research.newProject')}
                </Button>
              }
            />
          </WidgetBody>
        </Widget>
      </div>

      {demo && <DemoNotice />}

      <section className="space-y-3">
        <div className="flex items-center justify-between gap-3">
          <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.myProjects')}</h2>
          <Badge variant="secondary" className="text-[10px]">
            {real.length}
          </Badge>
        </div>

        {loading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
          </div>
        ) : real.length === 0 ? (
          <Widget className="p-8 text-center text-sm text-muted-foreground">{t('research.empty')}</Widget>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {real.map((experiment) => (
              <ExperimentCard
                key={experiment.id}
                experiment={experiment}
                onDuplicate={duplicate}
                onArchive={(e) => withBusy('status', () => setExperimentStatus(e.id, 'archived').then(reload))}
                onReopen={(e) => withBusy('status', () => setExperimentStatus(e.id, 'planning').then(reload))}
                onDelete={(e) => {
                  if (!window.confirm(t('research.confirmDelete'))) return;
                  withBusy('delete', () => deleteExperimentCascade(e.id).then(reload));
                }}
              />
            ))}
          </div>
        )}
      </section>

      {demo && (
        <section className="space-y-3">
          <h2 className="font-heading text-sm font-semibold tracking-tight">
            {t('research.chooseDemo')} <span className="text-muted-foreground">— {t('research.badge.demo')}</span>
          </h2>
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            <ExperimentCard
              experiment={demo}
              onDuplicate={duplicate}
              onArchive={() => {}}
              onReopen={() => {}}
              onDelete={() => {
                if (!window.confirm(t('research.confirmDelete'))) return;
                withBusy('delete', () => resetDemoData().then(reload));
              }}
            />
          </div>
        </section>
      )}
    </div>
  );
}