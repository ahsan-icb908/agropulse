import { useEffect, useState } from 'react';
import { base44 } from '@/api/base44Client';
import { ImagePlus, Loader2 } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { CONDITION_OPTIONS, saveObservation } from '@/lib/biology/researchStore';
import EvidenceBadge from './EvidenceBadge';

const NUMERIC = [
  { key: 'height_cm', labelKey: 'research.heightCm' },
  { key: 'leaf_count', labelKey: 'research.leafCount' },
  { key: 'water_ml', labelKey: 'research.waterMl' },
  { key: 'soil_moisture_percent', labelKey: 'research.soilMoisturePct' },
  { key: 'biomass_g', labelKey: 'research.biomassG' },
];

const todayISO = () => new Date().toISOString().slice(0, 10);

const EMPTY = {
  treatment_id: '',
  plant_id: '',
  observation_date: todayISO(),
  record_type: 'real',
  height_cm: '',
  leaf_count: '',
  water_ml: '',
  soil_moisture_percent: '',
  biomass_g: '',
  germinated: false,
  plant_condition: '',
  leaf_colour: '',
  root_notes: '',
  notes: '',
  photo_uri: '',
};

export default function ObservationFormDialog({ ctx, observation, open, onOpenChange }) {
  const { t } = useI18n();
  const { experiment, treatments, plants, reload } = ctx;
  const [form, setForm] = useState(EMPTY);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [photoMessage, setPhotoMessage] = useState('');
  const [uploading, setUploading] = useState(false);

  useEffect(() => {
    if (!open) return;
    setError('');
    setPhotoMessage('');
    if (observation) {
      setForm({
        ...EMPTY,
        ...observation,
        germinated: Boolean(observation.germinated),
        plant_condition: observation.plant_condition || '',
      });
    } else {
      setForm({ ...EMPTY, treatment_id: treatments[0]?.id || '', plant_id: '' });
    }
  }, [open, observation, treatments]);

  const groupPlants = plants.filter((p) => p.treatment_id === form.treatment_id);
  const set = (key) => (e) => setForm({ ...form, [key]: e.target.value });

  const missingFields = NUMERIC.filter(
    ({ key }) => form[key] === '' || form[key] === null || form[key] === undefined
  ).map(({ key }) => key);

  async function uploadPhoto(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setPhotoMessage('');
    try {
      const { file_uri } = await base44.integrations.Core.UploadPrivateFile({ file });
      setForm((prev) => ({ ...prev, photo_uri: file_uri }));
      setPhotoMessage(t('research.photoStoredPrivate'));
    } catch {
      setPhotoMessage(t('research.photoUnavailable'));
    } finally {
      setUploading(false);
    }
  }

  async function viewPhoto() {
    try {
      const { signed_url } = await base44.integrations.Core.CreateFileSignedUrl({
        file_uri: form.photo_uri,
        expires_in: 300,
      });
      window.open(signed_url, '_blank', 'noopener');
    } catch {
      setPhotoMessage(t('research.photoViewUnavailable'));
    }
  }

  async function submit() {
    if (!form.plant_id) {
      setError('Choose the plant this observation belongs to.');
      return;
    }
    if (!form.observation_date) {
      setError('An observation date is required.');
      return;
    }

    const payload = {
      experiment_id: experiment.id,
      treatment_id: form.treatment_id,
      plant_id: form.plant_id,
      plant_code: plants.find((p) => p.id === form.plant_id)?.plant_code,
      treatment_code: treatments.find((tr) => tr.id === form.treatment_id)?.code,
      observation_date: form.observation_date,
      record_type: form.record_type,
      germinated: form.germinated,
      plant_condition: form.plant_condition || undefined,
      leaf_colour: form.leaf_colour || undefined,
      root_notes: form.root_notes || undefined,
      notes: form.notes || undefined,
      photo_uri: form.photo_uri || undefined,
      is_demo: Boolean(experiment.is_demo),
      missing_fields: form.record_type === 'missing' ? NUMERIC.map((n) => n.key) : missingFields,
    };

    for (const { key, labelKey } of NUMERIC) {
      const raw = form[key];
      if (raw === '' || raw === null || raw === undefined) continue;
      const value = Number(raw);
      if (!Number.isFinite(value) || value < 0) {
        setError(`${t(labelKey)}: enter a number of zero or more, or leave it blank.`);
        return;
      }
      if (key === 'leaf_count' && !Number.isInteger(value)) {
        setError(`${t(labelKey)}: leaves must be a whole number.`);
        return;
      }
      payload[key] = value;
    }

    setSaving(true);
    setError('');
    try {
      await saveObservation(payload, observation?.id);
      onOpenChange(false);
      reload();
    } catch (e) {
      setError(e?.message || 'Could not save the observation.');
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{observation ? t('research.editObservation') : t('research.addObservation')}</DialogTitle>
          <DialogDescription>{t('research.numericHint')}</DialogDescription>
        </DialogHeader>

        <div className="space-y-3 py-1">
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <Label>{t('research.field.treatment')}</Label>
              <Select
                value={form.treatment_id}
                onValueChange={(v) => setForm({ ...form, treatment_id: v, plant_id: '' })}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {treatments.map((treatment) => (
                    <SelectItem key={treatment.id} value={treatment.id}>
                      {treatment.code} — {treatment.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t('research.field.plant')}</Label>
              <Select value={form.plant_id} onValueChange={(v) => setForm({ ...form, plant_id: v })}>
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder={t('research.allPlants')} />
                </SelectTrigger>
                <SelectContent>
                  {groupPlants.map((plant) => (
                    <SelectItem key={plant.id} value={plant.id}>
                      {plant.plant_code}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t('research.measurementDate')}</Label>
              <Input type="date" value={form.observation_date} onChange={set('observation_date')} className="mt-1" />
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
            <div>
              <Label>{t('research.recordType')}</Label>
              <Select value={form.record_type} onValueChange={(v) => setForm({ ...form, record_type: v })}>
                <SelectTrigger className="mt-1">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="real">{t('research.badge.real')}</SelectItem>
                  <SelectItem value="estimated">{t('research.badge.estimated')}</SelectItem>
                  <SelectItem value="missing">{t('research.badge.missing')}</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>{t('research.field.germination')}</Label>
              <div className="mt-2 flex items-center gap-2">
                <Switch checked={Boolean(form.germinated)} onCheckedChange={(v) => setForm({ ...form, germinated: v })} />
                <span className="text-xs text-muted-foreground">
                  {form.germinated ? t('research.condition.healthy') : t('research.condition.not_germinated')}
                </span>
              </div>
            </div>
            <div>
              <Label>{t('research.plantCondition')}</Label>
              <Select
                value={form.plant_condition || ''}
                onValueChange={(v) => setForm({ ...form, plant_condition: v })}
              >
                <SelectTrigger className="mt-1">
                  <SelectValue placeholder="—" />
                </SelectTrigger>
                <SelectContent>
                  {CONDITION_OPTIONS.map((condition) => (
                    <SelectItem key={condition} value={condition}>
                      {t(`research.condition.${condition}`)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
            {NUMERIC.map(({ key, labelKey }) => (
              <div key={key}>
                <Label className="text-xs">{t(labelKey)}</Label>
                <Input
                  type="number"
                  step={key === 'leaf_count' ? '1' : '0.1'}
                  min="0"
                  value={form[key] ?? ''}
                  onChange={set(key)}
                  className="mt-1"
                />
              </div>
            ))}
          </div>

          {missingFields.length > 0 && (
            <p className="rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-xs text-destructive">
              {t('research.badge.missing')}: {missingFields.join(', ')}
            </p>
          )}

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <Label>{t('research.leafColour')}</Label>
              <Input value={form.leaf_colour} onChange={set('leaf_colour')} className="mt-1" />
            </div>
            <div>
              <Label>{t('research.rootNotes')}</Label>
              <Input value={form.root_notes} onChange={set('root_notes')} className="mt-1" />
            </div>
          </div>

          <div>
            <Label>{t('research.field.notes')}</Label>
            <Textarea value={form.notes || ''} onChange={set('notes')} rows={2} className="mt-1" />
          </div>

          <div>
            <Label>{t('research.uploadPhoto')}</Label>
            <div className="mt-1 flex flex-wrap items-center gap-2">
              <Button asChild variant="outline" size="sm" className="gap-1.5" disabled={uploading}>
                <label>
                  {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <ImagePlus className="h-3.5 w-3.5" />}
                  {t('research.uploadPhoto')}
                  <input type="file" accept="image/*" hidden onChange={uploadPhoto} />
                </label>
              </Button>
              {form.photo_uri && (
                <Button variant="ghost" size="sm" onClick={viewPhoto}>
                  {t('research.viewPhoto')}
                </Button>
              )}
              <EvidenceBadge type={form.record_type} />
            </div>
            {photoMessage && <p className="mt-1 text-[11px] leading-relaxed text-muted-foreground">{photoMessage}</p>}
          </div>

          {error && <p className="text-sm text-destructive">{error}</p>}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t('common.cancel')}
          </Button>
          <Button onClick={submit} disabled={saving} className="gap-2">
            {saving && <Loader2 className="h-4 w-4 animate-spin" />}
            {t('common.save')}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}