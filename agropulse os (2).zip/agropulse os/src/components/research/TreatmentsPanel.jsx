import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Droplets, Pencil, Plus, Trash2, Thermometer } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import TreatmentFormDialog from './TreatmentFormDialog';

export default function TreatmentsPanel({ ctx }) {
  const { t } = useI18n();
  const { experiment, treatments, plants, reload } = ctx;
  const [dialog, setDialog] = useState({ open: false, treatment: null });

  const save = async (fields) => {
    const payload = { ...fields, experiment_id: experiment.id, is_demo: Boolean(experiment.is_demo) };
    if (dialog.treatment) {
      await base44.entities.ExperimentTreatment.update(dialog.treatment.id, payload);
    } else {
      await base44.entities.ExperimentTreatment.create(payload);
    }
    reload();
  };

  const remove = async (treatment) => {
    if (!window.confirm(t('research.confirmDeleteTreatment'))) return;
    await base44.entities.PlantObservation.deleteMany({ treatment_id: treatment.id });
    await base44.entities.ExperimentPlant.deleteMany({ treatment_id: treatment.id });
    await base44.entities.ExperimentTreatment.delete(treatment.id);
    reload();
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.tab.design')}</h2>
          <p className="text-xs text-muted-foreground">{t('research.waterLevelsCaution')}</p>
        </div>
        <Button size="sm" className="gap-1.5" onClick={() => setDialog({ open: true, treatment: null })}>
          <Plus className="h-3.5 w-3.5" />
          {t('research.addTreatment')}
        </Button>
      </div>

      {treatments.length === 0 ? (
        <Widget className="p-8 text-center text-sm text-muted-foreground">{t('research.noTreatments')}</Widget>
      ) : (
        <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
          {treatments.map((treatment) => {
            const plantCount = plants.filter((p) => p.treatment_id === treatment.id).length;
            return (
              <Widget key={treatment.id} className="p-4">
                <div className="flex items-start justify-between gap-2">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <Badge variant="secondary" className="text-[10px]">
                        {treatment.code || '—'}
                      </Badge>
                      {treatment.is_control && (
                        <Badge variant="outline" className="border-primary/40 text-[10px] text-primary">
                          {t('research.control')}
                        </Badge>
                      )}
                      <p className="font-heading text-sm font-semibold">{treatment.name}</p>
                    </div>
                  </div>
                  <div className="flex shrink-0 items-center gap-1">
                    <Button size="icon" variant="ghost" className="h-8 w-8" onClick={() => setDialog({ open: true, treatment })}>
                      <Pencil className="h-3.5 w-3.5" />
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      className="h-8 w-8 text-muted-foreground hover:text-destructive"
                      onClick={() => remove(treatment)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>

                <div className="mt-3 flex flex-wrap gap-2 text-[11px]">
                  {treatment.water_ml !== undefined && treatment.water_ml !== null && (
                    <Badge variant="outline" className="gap-1 text-[10px]">
                      <Droplets className="h-3 w-3" />
                      {treatment.water_ml} mL {treatment.water_frequency ? `• ${treatment.water_frequency}` : ''}
                    </Badge>
                  )}
                  <Badge variant="outline" className="text-[10px]">
                    {t('research.plantsPlanned')}: {plantCount} / {treatment.plants_planned ?? '—'}
                  </Badge>
                  {treatment.temperature_c !== undefined && treatment.temperature_c !== null && (
                    <Badge variant="outline" className="gap-1 text-[10px]">
                      <Thermometer className="h-3 w-3" />
                      {treatment.temperature_c} °C
                    </Badge>
                  )}
                </div>

                <dl className="mt-3 space-y-1.5 text-xs">
                  {[
                    [t('research.soil'), [treatment.soil_type, treatment.soil_quantity].filter(Boolean).join(' • ')],
                    [t('research.pot'), treatment.pot_size],
                    [t('research.light'), treatment.light_conditions],
                    [t('research.levelNote'), treatment.level_note],
                  ]
                    .filter(([, value]) => value)
                    .map(([label, value]) => (
                      <div key={label} className="flex gap-2">
                        <dt className="w-28 shrink-0 text-muted-foreground">{label}</dt>
                        <dd className="leading-relaxed">{value}</dd>
                      </div>
                    ))}
                </dl>
              </Widget>
            );
          })}
        </div>
      )}

      <TreatmentFormDialog
        open={dialog.open}
        onOpenChange={(open) => setDialog({ open, treatment: open ? dialog.treatment : null })}
        treatment={dialog.treatment}
        sortOrder={treatments.length}
        onSave={save}
      />
    </div>
  );
}