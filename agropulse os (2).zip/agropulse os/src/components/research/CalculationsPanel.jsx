import { useState } from 'react';
import { Calculator, Info } from 'lucide-react';
import { useI18n } from '@/i18n/LanguageContext';
import { Widget } from '@/components/common/Widget';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import EvidenceBadge from './EvidenceBadge';
import { useChartData } from './useChartData';
import {
  CALC_META,
  changeOverTime,
  formatValue,
  groupDateSeries,
  mean,
  percentageDifference,
  summariseByGroup,
  validValues,
} from '@/lib/biology/calculations';

function CalcCard({ metaKey, title, unit, formula, formulaUr, missing, missingUr, sample, inputs, value, note }) {
  const { t, lang } = useI18n();
  const meta = CALC_META[metaKey];
  const [showInputs, setShowInputs] = useState(false);
  return (
    <Widget className="p-4 print:break-inside-avoid">
      <div className="flex items-start justify-between gap-2">
        <h3 className="font-heading text-sm font-semibold tracking-tight">{title}</h3>
        <Badge variant="outline" className="shrink-0 gap-1 text-[10px]">
          <Calculator className="h-3 w-3" />
          {unit}
        </Badge>
      </div>

      <p className="mt-2 font-mono text-[11px] leading-relaxed text-muted-foreground">
        {lang === 'ur' ? formulaUr : formula}
      </p>

      <div className="mt-3 grid grid-cols-2 gap-2">
        <div className="rounded-lg border border-border p-2.5">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{t('research.sampleSize')}</p>
          <p className="font-heading text-lg font-bold">{sample}</p>
        </div>
        <div className="rounded-lg border border-border p-2.5">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{t('research.field.height')}</p>
          <p className="font-heading text-lg font-bold">{value}</p>
        </div>
      </div>

      {note && <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">{note}</p>}

      <p className="mt-2 flex items-start gap-1.5 text-[11px] leading-relaxed text-muted-foreground">
        <Info className="mt-0.5 h-3 w-3 shrink-0" />
        {lang === 'ur' ? missingUr || meta.missingUr : missing || meta.missing}
      </p>

      <Button variant="ghost" size="sm" className="mt-2 h-7 px-2 text-[11px]" onClick={() => setShowInputs((s) => !s)}>
        {t('research.inputs')} ({inputs.length})
      </Button>
      {showInputs && (
        <div className="mt-1 max-h-40 space-y-1 overflow-y-auto rounded-lg bg-muted/50 p-2">
          {inputs.map((row, index) => (
            <p key={index} className="text-[11px] text-muted-foreground">
              {row}
            </p>
          ))}
          {inputs.length === 0 && <p className="text-[11px] text-muted-foreground">{t('common.empty')}</p>}
        </div>
      )}
    </Widget>
  );
}

const line = (group, field, value) =>
  `${group.code}: ${field} = ${value === null ? '—' : value}`;

export default function CalculationsPanel({ ctx }) {
  const { t, lang } = useI18n();
  const { experiment, treatments, observations, plants } = ctx;
  const data = useChartData(ctx);

  const control = treatments.find((tr) => tr.is_control) || treatments[0];
  const controlGroup = summariseByGroup(observations, 'height_cm').find((g) => g.treatment_id === control?.id);

  const heightByGroup = summariseByGroup(observations, 'height_cm');
  const leafByGroup = summariseByGroup(observations, 'leaf_count');

  const changeRows = treatments.map((treatment) => {
    const groupObservations = observations.filter((o) => o.treatment_id === treatment.id);
    const first = groupDateSeries(groupObservations, 'height_cm')[0];
    const lastRow = groupDateSeries(groupObservations, 'height_cm').slice(-1)[0];
    const change = changeOverTime([
      { date: first?.date, value: first?.mean },
      { date: lastRow?.date, value: lastRow?.mean },
    ]);
    return { treatment, change, first, lastRow };
  });

  const overallInputs = observations
    .map((o) => {
      const value = o.height_cm;
      const treatment = treatments.find((tr) => tr.id === o.treatment_id);
      return value === undefined || value === null || o.record_type === 'missing'
        ? `${o.plant_code} (${treatment?.code || '—'}) ${o.observation_date}: ${t('research.notCalculable')}`
        : line({ code: `${o.plant_code} • ${o.observation_date}` }, t('research.heightCm'), `${value} cm`);
    })
    .slice(0, 200);

  const meanHeightSample = heightByGroup.map((g) => `${g.treatment_code}: n = ${g.n}, ${t('research.independentPlants')} = ${g.plants}`);
  const overallMeanNote =
    heightByGroup.length > 0
      ? heightByGroup
          .map((g) => `${g.treatment_code}: ${formatValue(g.mean)} cm (n = ${g.n})`)
          .join(' • ')
      : t('research.notCalculable');

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="font-heading text-sm font-semibold tracking-tight">{t('research.tab.calculations')}</h2>
          <p className="text-xs text-muted-foreground">{t('research.numericHint')}</p>
        </div>
        <EvidenceBadge type={experiment.is_demo ? 'demonstration' : 'real'} />
      </div>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <CalcCard
          metaKey="meanHeight"
          title={t('research.calc.mean_height')}
          unit="cm"
          sample={meanHeightSample.length ? `${heightByGroup.length} ${t('research.field.treatment')}` : '0'}
          inputs={meanHeightSample}
          value={overallMeanNote}
          note={t('research.warn.repeated_measures')}
        />

        <CalcCard
          metaKey="heightChange"
          title={t('research.calc.height_change')}
          unit="cm"
          sample={`${changeRows.filter((r) => r.change.calculable).length} / ${treatments.length}`}
          inputs={changeRows.map((row) =>
            `${row.treatment.code}: ${row.change.calculable ? `${formatValue(row.change.first?.value)} → ${formatValue(row.change.last?.value)} cm (${row.change.days} d)` : t('research.notCalculable')}`
          )}
          value={changeRows.map((row) => `${row.treatment.code}: ${row.change.calculable ? `${formatValue(row.change.delta)}` : '—'}`).join(' • ')}
        />

        <CalcCard
          metaKey="absoluteDiff"
          title={t('research.calc.absolute_difference')}
          unit="cm"
          sample={`${heightByGroup.length} ${t('research.field.treatment')}`}
          inputs={heightByGroup.map((g) =>
            `${g.treatment_code}: ${formatValue(g.mean)} cm − ${control?.code || '—'} ${formatValue(controlGroup?.mean)} cm`
          )}
          value={
            control
              ? heightByGroup
                  .map((g) => `${g.treatment_code}: ${formatValue(g.mean - (controlGroup?.mean ?? NaN))}`)
                  .join(' • ')
              : t('research.notCalculable')
          }
        />

        <CalcCard
          metaKey="percentDiff"
          title={t('research.calc.percentage_difference')}
          unit="%"
          sample={`${heightByGroup.length} ${t('research.field.treatment')}`}
          inputs={heightByGroup.map((g) => {
            const result = percentageDifference(g.mean, controlGroup?.mean);
            return `${g.treatment_code}: ${result.calculable ? `${result.value} %` : t('research.notCalculable')}`;
          })}
          value={heightByGroup
            .map((g) => {
              const result = percentageDifference(g.mean, controlGroup?.mean);
              return `${g.treatment_code}: ${result.calculable ? `${result.value}` : '—'}`;
            })
            .join(' • ')}
        />

        <CalcCard
          metaKey="germination"
          title={t('research.calc.germination')}
          unit="%"
          sample={`${data.germinationOverall.total} ${t('research.field.plant')}`}
          inputs={data.germinationPerGroup.map(
            (g) => `${g.code}: ${g.germinated} / ${g.total} (${t('research.badge.missing')}: ${g.unrecorded})`
          )}
          value={data.germinationPerGroup.map((g) => `${g.code}: ${g.percent === null ? '—' : g.percent}`).join(' • ')}
        />

        <CalcCard
          metaKey="meanLeaves"
          title={t('research.calc.mean_leaves')}
          unit={t('research.field.leaves')}
          sample={`${leafByGroup.length} ${t('research.field.treatment')}`}
          inputs={leafByGroup.map((g) => `${g.treatment_code}: n = ${g.n}, ${t('research.independentPlants')} = ${g.plants}`)}
          value={leafByGroup.map((g) => `${g.treatment_code}: ${formatValue(g.mean)}`).join(' • ')}
        />

        <CalcCard
          metaKey="meanBiomass"
          title={t('research.calc.mean_biomass')}
          unit="g"
          sample={`${data.biomassPerGroup.reduce((acc, b) => acc + b.plants, 0)} ${t('research.field.plant')}`}
          inputs={data.biomassPerGroup.map((b) => `${b.code}: ${b.plants} × ${b.values?.join(', ') || '—'}`)}
          value={data.biomassPerGroup.map((b) => `${b.code}: ${formatValue(b.mean)}`).join(' • ')}
        />
      </div>

      <Widget className="p-4">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="font-heading text-sm font-semibold tracking-tight">{t('research.calc.standard_deviation')}</h3>
          <span className="font-mono text-[11px] text-muted-foreground">
            {lang === 'ur' ? CALC_META.sd.formulaUr : CALC_META.sd.formula}
          </span>
        </div>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead className="bg-muted/60 text-xs">
              <tr>
                <th className="p-2 text-start font-medium">{t('research.field.treatment')}</th>
                <th className="p-2 text-start font-medium">n</th>
                <th className="p-2 text-start font-medium">{t('research.independentPlants')}</th>
                <th className="p-2 text-start font-medium">{t('research.sd')} (cm)</th>
                <th className="p-2 text-start font-medium">SEM (cm)</th>
              </tr>
            </thead>
            <tbody>
              {heightByGroup.map((g) => (
                <tr key={g.treatment_id} className="border-t border-border">
                  <td className="p-2">{g.treatment_code}</td>
                  <td className="p-2">{g.n}</td>
                  <td className="p-2">{g.plants}</td>
                  <td className="p-2">{g.sd === null ? t('research.notCalculable') : formatValue(g.sd)}</td>
                  <td className="p-2">{g.sem === null ? t('research.notCalculable') : formatValue(g.sem)}</td>
                </tr>
              ))}
              {heightByGroup.length === 0 && (
                <tr>
                  <td colSpan={5} className="p-4 text-center text-sm text-muted-foreground">
                    {t('research.warn.no_observations')}
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">{CALC_META.sd.missing}</p>
      </Widget>

      <Widget className="p-4">
        <h3 className="font-heading text-sm font-semibold tracking-tight">{t('research.inputs')}</h3>
        <p className="mt-1 text-[11px] text-muted-foreground">
          {validValues(observations, 'height_cm').length} / {observations.length} {t('research.recordsShown')} •{' '}
          {t('research.field.height')} (cm) • {t('research.independentPlants')}: {data.independentPlants}
        </p>
        <p className="mt-2 text-xs text-muted-foreground">
          {t('research.sampleSize')} — {mean(validValues(observations, 'height_cm')) === null ? t('research.notCalculable') : formatValue(mean(validValues(observations, 'height_cm')))} cm ({t('common.all')})
        </p>
        <div className="mt-2 max-h-56 space-y-1 overflow-y-auto rounded-lg bg-muted/50 p-2">
          {overallInputs.map((row, index) => (
            <p key={index} className="text-[11px] text-muted-foreground">
              {row}
            </p>
          ))}
          {overallInputs.length === 0 && <p className="text-[11px] text-muted-foreground">{t('common.empty')}</p>}
        </div>
        <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">{t('research.numericHint')}</p>
        <p className="mt-2 text-[11px] leading-relaxed text-muted-foreground">{t('research.warn.no_significance')}</p>
        <p className="mt-2 text-[11px] text-muted-foreground">
          {plants.length} {t('research.field.plant')} • {t('research.report.dataOrigin')}:{' '}
          {experiment.is_demo ? t('research.badge.demo') : t('research.badge.real')}
        </p>
      </Widget>
    </div>
  );
}