import { motion } from 'framer-motion';

// Restrained motion tokens (see design system §11.1).
export const EASE = [0.22, 1, 0.36, 1];

export const DUR = {
  fast: 0.16,
  menu: 0.22,
  page: 0.3,
  card: 0.26,
};

// Page-level entrance: soft fade + small rise. Driven by CSS rather than a
// motion state so routed content can never be left stuck at zero opacity.
export function PageTransition({ children }) {
  return (
    <div className="animate-in fade-in slide-in-from-bottom-2 duration-300">
      {children}
    </div>
  );
}

// Staggered container for lists/grids.
export function Stagger({ children, delay = 0, className }) {
  return (
    <motion.div
      className={className}
      initial="hidden"
      animate="show"
      variants={{
        hidden: {},
        show: { transition: { staggerChildren: 0.05, delayChildren: delay } },
      }}
    >
      {children}
    </motion.div>
  );
}

// Child of Stagger — subtle fade-up.
export function StaggerItem({ children, className }) {
  return (
    <motion.div
      className={className}
      variants={{
        hidden: { opacity: 0, y: 10 },
        show: { opacity: 1, y: 0, transition: { duration: DUR.card, ease: EASE } },
      }}
    >
      {children}
    </motion.div>
  );
}