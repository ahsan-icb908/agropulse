import { Card } from '@/components/ui/card';
import { cn } from '@/lib/utils';

// Reusable dashboard widget — consistent radius, padding, border, hover.
export function Widget({ className, children, ...props }) {
  return (
    <Card
      className={cn(
        'rounded-2xl border-border/70 shadow-sm hover:shadow-md transition-shadow duration-200',
        className
      )}
      {...props}
    >
      {children}
    </Card>
  );
}

export function WidgetHeader({ title, subtitle, action, icon: Icon }) {
  return (
    <div className="flex items-start justify-between gap-3 p-4 sm:p-5 pb-0">
      <div className="flex items-center gap-2.5 min-w-0">
        {Icon && (
          <span className="w-8 h-8 rounded-lg bg-primary/10 text-primary flex items-center justify-center shrink-0">
            <Icon className="w-4 h-4" />
          </span>
        )}
        <div className="min-w-0">
          <h3 className="font-heading font-semibold text-[15px] truncate">{title}</h3>
          {subtitle && <p className="text-xs text-muted-foreground truncate">{subtitle}</p>}
        </div>
      </div>
      {action}
    </div>
  );
}

export function WidgetBody({ className, children }) {
  return <div className={cn('p-4 sm:p-5 pt-3', className)}>{children}</div>;
}