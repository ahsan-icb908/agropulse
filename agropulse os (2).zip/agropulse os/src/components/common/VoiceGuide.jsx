import { useState } from 'react';
import { useLocation } from 'react-router-dom';
import { Volume2, Square } from 'lucide-react';
import { useSpeech } from '@/hooks/useSpeech';
import { useI18n } from '@/i18n/LanguageContext';

const PAGE_GUIDES = {
  '/': {
    en: 'Welcome to AgroPulse OS overview. Here you can see active alerts, open tasks, water usage, and crop health at a glance. Use the action bar to report issues, scan crops, ask the AI assistant, or open the map.',
    ur: 'ایگرو پلس او ایس اوورویو میں خوش آمدید۔ یہاں آپ فعال الرٹس، کھلے کام، پانی کا استعمال اور فصل کی صحت ایک نظر میں دیکھ سکتے ہیں۔',
  },
  '/farms': {
    en: 'Farms page. Manage your farm records here. Add new farms with their location, area, and crop focus. Each farm shows its field and task counts.',
    ur: 'فارمز پیج۔ اپنے فارم ریکارڈز یہاں منتظم کریں۔ مقام، رقبہ اور فصل کی توجہ کے ساتھ نئے فارم شامل کریں۔',
  },
  '/fields': {
    en: 'Fields page. Track individual field plots with their crops, growth stages, soil health, and sowing dates.',
    ur: 'فیلڈز پیج۔ انفرادی فیلڈ پلاٹس کو ان کی فصلوں، نشوونما کے مراحل، مٹی کی صحت اور بونے کی تاریخوں کے ساتھ ٹریک کریں۔',
  },
  '/map': {
    en: 'Map page. View your farms, fields, active hazard alerts, and community reports on an interactive map. Toggle layers to focus on what matters.',
    ur: 'نقشہ پیج۔ اپنے فارمز، فیلڈز، فعال خطرے کی الرٹس اور کمیونٹی رپورٹس ایک انٹرایکٹو نقشے پر دیکھیں۔',
  },
  '/assistant': {
    en: 'AI Assistant. Ask any agricultural question about crops, weather, soil, or pest control and get AI-powered guidance.',
    ur: 'اے آئی اسسٹنٹ۔ فصلوں، موسم، مٹی یا کیڑے مکوڑوں کے کنٹرول کے بارے میں کوئی بھی زرعی سوال پوچھیں۔',
  },
  '/crop-scan': {
    en: 'Crop Scan. Upload a photo of your crop to get AI-powered disease diagnosis and treatment recommendations.',
    ur: 'فصل سکین۔ اپنی فصل کی تصویر اپ لوڈ کریں اور اے آئی سے بیماری کی تشخیص اور علاج کی سفارشات حاصل کریں۔',
  },
  '/weather': {
    en: 'Weather page. View current weather conditions and forecast for your area to plan farming activities.',
    ur: 'موسم پیج۔ اپنے علاقے کے موجودہ موسم اور پیش گوئی دیکھیں اور زرعی سرگرمیاں منصوب بندی کریں۔',
  },
  '/sdgs': {
    en: 'SDG Explorer. Track how AgroPulse OS contributes to the 17 Sustainable Development Goals.',
    ur: 'ایس ڈی جی ایکسپلورر۔ ایگرو پلس او ایس 17 پائیدار ترقیاتی اہداف میں کیسے حصہ ڈالتا ہے دیکھیں۔',
  },
  '/community': {
    en: 'Community page. Report and track civic issues like water leakage, drainage, waste, and infrastructure problems.',
    ur: 'کمیونٹی پیج۔ پانی کے رساؤ، نکاسی، کچرا اور بنیادی ڈھانچے کے مسائل کی اطلاع دیں اور ٹریک کریں۔',
  },
  '/analytics': {
    en: 'Analytics page. View charts and summaries of your harvest yields, alerts, civic reports, and task completion.',
    ur: 'اینالیٹکس پیج۔ اپنی فصل کی پیداوار، الرٹس، سول رپورٹس اور کام مکمل ہونے کے چارٹس دیکھیں۔',
  },
  '/programs': {
    en: 'Programs hub. Access 16 agricultural and social support programs including marketplace, jobs, equipment rental, and more.',
    ur: 'پروگرامز ہب۔ مارکیٹ پلیس، نوکریاں، اوزار کرایہ، اور مزید سمیت 16 زرعی اور سماجی مدد پروگرامز تک رسائی حاصل کریں۔',
  },
  '/programs/marketplace': {
    en: 'Marketplace. List your produce directly for buyers and check real-time mandi price rates. Set price alerts to get notified when rates hit your target. No middleman commissions.',
    ur: 'مارکیٹ پلیس۔ اپنی پیداوار براہ راست خریداروں کے لیے درج کریں اور ریئل ٹائم مندی قیمتوں کی شرحوں کو دیکھیں۔ قیمت الرٹس سیٹ کریں۔',
  },
  '/programs/knowledge-hub': {
    en: 'Knowledge Hub. Browse voice-guided tutorials on disease identification, irrigation, soil management, and pest control. Click Listen to hear any tutorial in your language.',
    ur: 'نالج ہب۔ بیماری کی شناخت، آبپاشی، مٹی کے انتظام اور کیڑے مکوڑوں کے کنٹرول پر وائس گائیڈڈ ٹیوٹوریلز دیکھیں۔ سنیں کے بٹن پر کلک کریں۔',
  },
  '/settings': {
    en: 'Settings. Manage your profile, language preference, accessibility options, and low-bandwidth mode.',
    ur: 'سیٹنگز۔ اپنی پروفائل، زبان کی ترجیح، رسائی کے اختیارات اور لو بینڈ وِد موڈ منتظم کریں۔',
  },
};

export default function VoiceGuide() {
  const location = useLocation();
  const { lang } = useI18n();
  const { speak, stop, speaking, supported } = useSpeech();
  const [showLabel, setShowLabel] = useState(false);

  if (!supported) return null;

  const guide = PAGE_GUIDES[location.pathname];
  const text = guide ? (guide[lang] || guide.en) : null;

  function handleClick() {
    if (speaking) { stop(); return; }
    if (text) speak(text, lang);
  }

  return (
    <div className="fixed bottom-20 lg:bottom-6 right-4 sm:right-6 z-40">
      <button
        onClick={handleClick}
        onMouseEnter={() => setShowLabel(true)}
        onMouseLeave={() => setShowLabel(false)}
        disabled={!text}
        className={`w-12 h-12 rounded-full shadow-lg flex items-center justify-center transition-all ${
          speaking ? 'bg-primary text-primary-foreground scale-110' : 'bg-card border border-border text-primary hover:bg-primary/10'
        } ${!text ? 'opacity-50 cursor-not-allowed' : ''}`}
        title={text ? 'Listen to page guide' : 'No guide for this page'}
      >
        {speaking ? <Square className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
      </button>
      {showLabel && text && (
        <span className="absolute right-14 top-1/2 -translate-y-1/2 whitespace-nowrap text-xs bg-card border border-border rounded-lg px-2.5 py-1.5 shadow-md">
          {speaking ? 'Stop' : 'Listen to guide'}
        </span>
      )}
    </div>
  );
}