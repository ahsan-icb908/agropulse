import { Play } from 'lucide-react';
import { Image } from '@/components/ui/image';
import { thumbnailUrl } from './videos';

// One video in the Agro Vids grid — thumbnail with a hover play affordance.
export default function VideoCard({ video, onPlay }) {
  return (
    <button
      type="button"
      onClick={() => onPlay(video)}
      className="group overflow-hidden rounded-xl border border-border bg-card text-left transition-colors hover:border-primary/50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      <span className="relative block aspect-video bg-muted">
        <Image
          src={thumbnailUrl(video.id)}
          alt={video.title}
          fittingType="fill"
          className="h-full w-full object-cover"
        />
        <span className="absolute inset-0 grid place-items-center bg-black/30 opacity-0 transition-opacity group-hover:opacity-100">
          <Play className="h-9 w-9 text-white" fill="currentColor" />
        </span>
        {video.language === 'ur' && (
          <span className="absolute right-2 top-2 rounded bg-black/75 px-1.5 py-0.5 text-[10px] font-medium text-white">
            اردو
          </span>
        )}
      </span>
      <span className="block p-2.5">
        <span className="line-clamp-2 text-sm font-medium leading-snug">{video.title}</span>
      </span>
    </button>
  );
}