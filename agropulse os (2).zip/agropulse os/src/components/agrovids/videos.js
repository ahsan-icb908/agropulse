// Curated Agro Vids library.
//
// Every entry points at a real, publicly available YouTube video: `id` is the
// watch?v= value and is used for both the thumbnail and the in-app player.
// Categories drive the tabs on the Agro Vids page; `language: 'ur'` marks the
// Urdu-language videos so they can be badged in the grid.

export const VIDEO_CATEGORIES = [
  { key: 'all', labelKey: 'videos.cat.all' },
  { key: 'crops', labelKey: 'videos.cat.crops' },
  { key: 'soil', labelKey: 'videos.cat.soil' },
  { key: 'water', labelKey: 'videos.cat.water' },
  { key: 'machinery', labelKey: 'videos.cat.machinery' },
  { key: 'livestock', labelKey: 'videos.cat.livestock' },
  { key: 'horticulture', labelKey: 'videos.cat.horticulture' },
  { key: 'pests', labelKey: 'videos.cat.pests' },
  { key: 'fisheries', labelKey: 'videos.cat.fisheries' },
  { key: 'business', labelKey: 'videos.cat.business' },
];

export const AGRO_VIDEOS = [
  // ── Crops: wheat ──────────────────────────────────────────────────────────
  { id: 'z_RWSMv2i48', title: 'Everything You Need to Know About Modern Wheat Farming', category: 'crops' },
  { id: 'R_GulZ2iW9o', title: 'Harvesting Millions of Tons of Wheat by Machine', category: 'crops' },
  { id: 'vA_Bgwia26U', title: 'Direct Drilling Wheat: What Works and What Does Not', category: 'crops' },
  { id: 'O4URChiVtas', title: 'From Seed to Flour: How Wheat Is Grown', category: 'crops' },
  { id: 'p48e3moktyE', title: 'Kansas Wheat Harvest: Where Technology Never Sleeps', category: 'crops' },
  { id: 'WWZVnTm6Q98', title: 'How US Farmers Harvest Millions of Tons of Wheat', category: 'crops' },
  { id: '1mfdTaLWb7Y', title: 'How Australian Farmers Make Billions from Agriculture', category: 'crops' },
  { id: 'xOBO-8F0u2Y', title: 'How to Harvest Wheat: Modern Cultivation', category: 'crops' },
  { id: 'rhJ3cCdfyss', title: 'Two Combines Harvesting Winter Wheat', category: 'crops' },
  { id: 'IzLubrDypq0', title: 'Modern Wheat Farming Machines', category: 'crops' },
  { id: 'ZLoUSU9m3Ro', title: 'Wheat Harvest with John Deere Combines', category: 'crops' },
  { id: 'Cj50I5ww-N4', title: 'Harvesting Wheat with an 1880s Reaper', category: 'crops' },
  { id: 't03pW_KMnIo', title: 'Four Combines Harvesting Kentucky Wheat', category: 'crops' },

  // ── Crops: rice ───────────────────────────────────────────────────────────
  { id: 'YncRnNH49Lo', title: 'Rice Planting Journey: Weeding and Transplanting', category: 'crops' },
  { id: 'BomO2rDg25M', title: 'Why Transplanting Rice Gives Higher Yields', category: 'crops' },
  { id: 'WSQsDi4kU6Y', title: 'Managing a Rice Field with SRI Technology', category: 'crops' },
  { id: 'R2rqGqLCDNg', title: 'Preparing Rice Seedlings for Transplanting', category: 'crops' },
  { id: 'Q9rMYq0t2I0', title: 'Rice Transplanting Secrets for Higher Yield', category: 'crops' },
  { id: 'mDE-Xd2J6aA', title: 'Life Cycle of Rice: Seed to Harvest', category: 'crops' },
  { id: 'cZwx_VeK2gI', title: 'Transplanting the Rice Nursery: Expert Advice', category: 'crops' },
  { id: 'owngX70dz-Y', title: 'Manual Rice Planting in Paddy Fields', category: 'crops' },
  { id: 'InzUYwdfWkw', title: 'High-Tech Rice Planting in China', category: 'crops' },
  { id: 'ghO7M5snCeg', title: 'Hand Transplanting Rice Seedlings', category: 'crops' },

  // ── Crops: maize ──────────────────────────────────────────────────────────
  { id: 'Zeo5AWR0zjk', title: 'Maize Farming: Spacing, Planting Depth and Fertilizer', category: 'crops' },
  { id: 'uhVUKK3h0L4', title: 'Corn Farming: Complete Maize Cultivation Guide', category: 'crops' },
  { id: 'nfMLKP1nXK0', title: 'Maize Cultivation Step by Step', category: 'crops' },
  { id: 'SyNrebh5U2o', title: 'Maize Farming Guidance for High Yields', category: 'crops' },
  { id: '7WU3Eko8J-o', title: 'How to Plant and Maintain a Maize Farm', category: 'crops' },
  { id: 'XRf3oQPMr2g', title: 'Getting Perfect Maize Germination', category: 'crops' },
  { id: 'pBEt9IWaKJQ', title: 'Earning from an Acre of Maize', category: 'crops' },
  { id: '1gBV-tISKoE', title: 'How to Grow Maize for Maximum Yield', category: 'crops' },
  { id: 'wlst8dxx0cI', title: 'Harvesting Maize by Hand', category: 'crops' },
  { id: 'CItXvBomX7k', title: 'Organic Corn Farming: Complete Guide', category: 'crops' },

  // ── Crops: cotton ─────────────────────────────────────────────────────────
  { id: 'BxTc3hV7kLE', title: 'Cotton Farming: Complete Guide', category: 'crops' },
  { id: 'Ob2zTw1VRsc', title: 'Profitable Cotton Growing on Small Plots', category: 'crops' },

  // ── Soil, compost and organic matter ──────────────────────────────────────
  { id: 'yfE2o_5X-kI', title: 'Compost and Soil Health', category: 'soil' },
  { id: 'wyV5X-R_4X0', title: 'Compost and Soil Health: A Deeper Dive', category: 'soil' },
  { id: 'gBkEQR5h7Vs', title: 'Why Compost Alone Will Not Build the Healthiest Soils', category: 'soil' },
  { id: 'u8sRxVwgdbI', title: 'Nine Proven Ways to Boost Soil Health', category: 'soil' },
  { id: 'swOqYLCKOQY', title: 'Improving Soil with Organic Matter', category: 'soil' },
  { id: 'sg_LJqM11T4', title: 'Composting for Soil Health', category: 'soil' },
  { id: 'nhvL9pOuxvQ', title: 'Organic Matter Decomposition and Composting', category: 'soil' },
  { id: 'FcDUh1oS1Yo', title: 'How to Make and Use Compost: Masterclass', category: 'soil' },
  { id: 'YzJPekAmce8', title: 'How to Create Perfect Soil', category: 'soil' },
  { id: 'l9zIayka23k', title: 'Five Tips to Boost Soil Health', category: 'soil' },
  { id: 'OOseADKMavw', title: 'Complete Guide to Natural Farming', category: 'soil' },
  { id: '6xK0CCwwdVo', title: 'Organic Farming Explained', category: 'soil' },
  { id: 'phXLgKFFZzs', title: 'Korean Natural Farming for Your Garden', category: 'soil' },
  { id: '2eA3Qwm0L7c', title: 'Mastering Organic Farming: Principles and Practices', category: 'soil' },
  { id: '2MFabfkP5xI', title: 'What Is Natural Farming? Chemical-Free Agriculture', category: 'soil' },
  { id: 'jw1qeCAZlts', title: 'A Gardener’s Guide to Korean Natural Farming', category: 'soil' },
  { id: 'mkEsLdNKlPM', title: 'Thirty Essential Organic Farming Techniques', category: 'soil' },
  { id: 'MDzvIN9AEH4', title: 'Five Years of JADAM Organic Farming', category: 'soil' },
  { id: '_AM2fX24vtQ', title: 'How to Start an Organic Farming Business', category: 'soil' },
  { id: 'fyDI4NfgUMs', title: 'Sustainable Natural Farming in Sri Lanka', category: 'soil' },

  // ── Irrigation and water ──────────────────────────────────────────────────
  { id: '8AveE6-OHL8', title: 'Installing Drip Irrigation on a Large Farm', category: 'water' },
  { id: 'Y0BI2cMNOj0', title: 'Setting Up Drip Irrigation for Small Farms', category: 'water' },
  { id: 'N9j1BeQp0rI', title: 'Automatic Drip Irrigation for Long Rows', category: 'water' },
  { id: 'LMMOyIsxKBI', title: 'Drip Irrigation for Open Field Farming', category: 'water' },
  { id: 'mxhstmplM-g', title: 'DIY Drip Irrigation for Small Farms', category: 'water' },
  { id: 'SxObbiZB120', title: 'Setting Up Drip Irrigation in a Vineyard', category: 'water' },
  { id: 'f_YpEhEN16g', title: 'Drip Irrigation from Start to Finish', category: 'water' },
  { id: 'SGwUg2IuXq8', title: 'Installing a Drip Tape System', category: 'water' },
  { id: 'Z-W4Ivi54cw', title: 'Subsurface Drip Irrigation Installation', category: 'water' },
  { id: 'jNjv4pobJeM', title: 'Complete Garden Drip Irrigation Setup', category: 'water' },

  // ── Machinery ─────────────────────────────────────────────────────────────
  { id: 'OQRtGbwyhRU', title: 'John Deere X9 Combines Harvesting 12,000 Acres', category: 'machinery' },
  { id: 'WzjjhILZ4Bc', title: 'Harvesting with the World’s Biggest Combine', category: 'machinery' },
  { id: 'ElonVL_q6Nw', title: 'John Deere 9750 STS Combine Harvesting Wheat', category: 'machinery' },
  { id: '2Nf6uOlQPN8', title: 'What Does a Combine Do?', category: 'machinery' },
  { id: '-cf7SmValXE', title: 'Big Combines, Tractors and Balers at Harvest', category: 'machinery' },
  { id: 'XJbb2HIXXFE', title: '775 HP Case IH Combine Harvesting Wheat', category: 'machinery' },
  { id: 'FaEc-CLcoiw', title: 'Ten Smallest Combine Harvesters', category: 'machinery' },
  { id: 'WAmAyXPte-0', title: 'New Holland CR11: 10,000 Bushels an Hour', category: 'machinery' },
  { id: 'fNdK6MwMoSA', title: 'The Gigantic Combine Harvester', category: 'machinery' },
  { id: '4xQHNHk7KPk', title: '1990s John Deere Wheat Harvest', category: 'machinery' },

  // ── Livestock and dairy ───────────────────────────────────────────────────
  { id: 'JeUPzWML8wY', title: 'How Milking Works on a Dairy Farm', category: 'livestock' },
  { id: 'myCq--XESaU', title: 'Inside a Modern Dairy Farm', category: 'livestock' },
  { id: '3A8OBmzN4ZM', title: 'How to Milk a Cow by Hand', category: 'livestock' },
  { id: 'NGv3QiVjzvE', title: 'The Milking Process Explained by a Dairy Farmer', category: 'livestock' },
  { id: 'B4zrjGVqMXg', title: 'Morning Milking on a Small Family Farm', category: 'livestock' },
  { id: 'OgVW3qQwCoA', title: 'Milking 230 Cows Through a New Parlour', category: 'livestock' },
  { id: 'nr4VEgY5odE', title: 'Planning Your Cow’s Daily Milking Schedule', category: 'livestock' },
  { id: 'wpGia7uC_I0', title: 'Milking and Feeding on a Small Dairy Farm', category: 'livestock' },
  { id: '6GoyELTBm_U', title: 'Milking Cows in a Modern Parlour', category: 'livestock' },
  { id: 'rR3RnIFd91s', title: 'Milking Holstein Cows: Parlour Tour', category: 'livestock' },
  { id: 'ZOOSLPB8qeU', title: 'Profits from Broiler Chicken Farming', category: 'livestock' },
  { id: 'KRAosMk9HfU', title: 'Broiler Chicken Farming Guide, Part 1', category: 'livestock' },
  { id: 'IBWjPwjvEn8', title: 'Achieving Success in Broiler Farming', category: 'livestock' },
  { id: 'W-JxXAAULWo', title: 'Starting a Broiler Farm on a Small Budget', category: 'livestock' },
  { id: 'OSWDgkfaElo', title: 'Raising Day-Old Chicks in Winter', category: 'livestock' },
  { id: 'J9hqQLNLR_c', title: 'Growing Income Through Broiler Farming', category: 'livestock' },
  { id: 'GmnXdBSBkk4', title: 'Life Cycle of a Broiler Chicken', category: 'livestock' },
  { id: '9nDSTCn48Ow', title: 'Raising Broilers to Market', category: 'livestock' },
  { id: '_aMiauzOLak', title: 'Starting a 500-Chicken Farm on a Low Budget', category: 'livestock' },
  { id: 'FwYYvO1OmeA', title: 'Starting Poultry Farming with 50 Chickens', category: 'livestock' },

  // ── Orchards, greenhouse and hydroponics ──────────────────────────────────
  { id: 'qrI_vetqMnY', title: 'How to Prune a Mango Tree for Maximum Fruit', category: 'horticulture' },
  { id: 'zhFoa1RtXx0', title: 'Pruning and Maintaining Large Fruit Trees', category: 'horticulture' },
  { id: 'TUJgPY9TzTs', title: 'Mango Pruning and Its Effect on Fruit Production', category: 'horticulture' },
  { id: 'jXzpjZA38N0', title: 'Why Prune: The Idea Behind Small Mango Trees', category: 'horticulture' },
  { id: 'cmb0OsYI8WQ', title: 'Hard-Pruning Forty Fruit Trees', category: 'horticulture' },
  { id: '1i-Dm73iHpQ', title: 'How to Plant and Care for a Mango Tree', category: 'horticulture' },
  { id: '-OvY_oAKZOg', title: 'Spacing, Pruning and Disease Control in a Mango Orchard', category: 'horticulture' },
  { id: 'eS2vkvzHiiE', title: 'High-Density Mango Orchards on Espalier Trellis', category: 'horticulture' },
  { id: '4waNqzpx6KY', title: 'Pruning to Boost Your Mango Harvest', category: 'horticulture' },
  { id: '5E6vplneB6s', title: 'Open Tatura Trellis Mango Orchard', category: 'horticulture' },
  { id: 'fXDrSD6DaEw', title: 'Hydroponic Greenhouse: From Hobby to Business', category: 'horticulture' },
  { id: 'upkos1MNiMI', title: 'Hydroponic Greenhouse Tour', category: 'horticulture' },
  { id: '3Ww2TP_tU7o', title: 'Farming Without Soil and 90% Less Water', category: 'horticulture' },
  { id: 'K82E4B5o9cg', title: 'Indoor Farming: What Works and What Does Not', category: 'horticulture' },
  { id: 'UvQW2lInT5c', title: 'Low-Maintenance Home Hydroponic System', category: 'horticulture' },
  { id: 'h1Kdd1lP2qw', title: 'Inside a Hydroponic Lettuce Greenhouse', category: 'horticulture' },
  { id: 'cMG2HlcZ_fg', title: 'Inside a Thriving Hydroponic Greenhouse', category: 'horticulture' },
  { id: 'dLEVQw-bHhc', title: 'Building an Inexpensive Hydroponic System', category: 'horticulture' },
  { id: 'W5tnHfikb64', title: 'Rooftop Hydroponics in a City', category: 'horticulture' },
  { id: 'z0zBj9ugz0E', title: 'Hydroponic Vegetable Production on a Farm', category: 'horticulture' },

  // ── Pests and disease ─────────────────────────────────────────────────────
  { id: '95lpZNlBQGM', title: 'Cotton Cultivation Practices for Pest Control', category: 'pests' },
  { id: 'wAt-r6nR-fc', title: 'Cotton Pest and Disease Control Guide', category: 'pests' },
  { id: 'ECUEL3kcKkM', title: 'Control of Pests and Diseases in Cotton', category: 'pests' },
  { id: 'hP0XNqr_Doo', title: 'Cotton Pest and Disease Control Explained', category: 'pests' },
  { id: 'qqdoTTykuxU', title: 'Cotton Crop Pest Control Tips', category: 'pests' },
  { id: 'eZL84CHqRkE', title: 'Protecting Cotton in the Rainy Season', category: 'pests', language: 'ur' },
  { id: 'a6Lm81JQjcY', title: 'Integrated Pest Management for Sucking Pests in Cotton', category: 'pests' },
  { id: '1ymqdTSPCTM', title: 'Thrips and Sesame Pest Management', category: 'pests', language: 'ur' },

  // ── Fisheries and bees ────────────────────────────────────────────────────
  { id: '1GxSnm7jQKQ', title: 'Making Millions from Fish Farming', category: 'fisheries' },
  { id: 'sGoxStAywTY', title: 'Building 170 Fish Farms from Scratch', category: 'fisheries' },
  { id: 'aHd4LB4dkX8', title: 'How to Start Fish Farming: Beginner Tutorial', category: 'fisheries' },
  { id: 'hw83i7ZMRFA', title: 'Four Types of Fish Ponds', category: 'fisheries' },
  { id: 'Oz90OEhV7Vw', title: 'Backyard Aquaponics with Tilapia', category: 'fisheries' },
  { id: '9LkAp0guaDs', title: 'A Turnkey Aquaculture System', category: 'fisheries' },
  { id: 'MH5CoW6sBt8', title: 'Aquaculture Farm Tour', category: 'fisheries' },
  { id: 'JTtDDFTeMSU', title: 'Fish Farming Tips and Tricks', category: 'fisheries' },
  { id: 'QW4p_3RMIn8', title: 'Integrating Aquaculture with Traditional Farming', category: 'fisheries' },
  { id: 'NkD9SlzzjMQ', title: 'In-Pond Raceway System for Fish Farms', category: 'fisheries' },
  { id: 'jeFxOUZreXI', title: 'Beekeeping for Absolute Beginners', category: 'fisheries' },
  { id: 'C2h4fYL73_M', title: 'How to Read a Frame of Bees', category: 'fisheries' },
  { id: 'yKUJ2fx14Y0', title: 'Rookie Beekeeper Mistakes', category: 'fisheries' },
  { id: '1VWCEydW72A', title: 'Beekeeping Lies and Misconceptions', category: 'fisheries' },
  { id: '-Geg9GSnEeo', title: 'How to Grow a Ton of Honey with One Hive', category: 'fisheries' },
  { id: 'xf2ogKbuM84', title: 'Starting a Beehive and Harvesting Honey', category: 'fisheries' },
  { id: 'lqAysFXcZ64', title: 'Homegrown Honey: Keeping Bees and Harvesting', category: 'fisheries' },
  { id: 'IFgHkJaDx8I', title: 'Beekeeping for Beginners: What You Actually Need', category: 'fisheries' },
  { id: 'db2fgPEs4ks', title: 'A Full Season of Beekeeping', category: 'fisheries' },
  { id: 'D7kf2dAtWEM', title: 'Beekeeping Basics: Caring for Your First Bees', category: 'fisheries' },

  // ── Farm business and policy ──────────────────────────────────────────────
  { id: 't_j1-snZFgk', title: 'What Is Agriculture? Explained in Urdu', category: 'business', language: 'ur' },
  { id: 'Cp3bu1Lh2RA', title: 'Agriculture Business Ideas', category: 'business', language: 'ur' },
  { id: '5n-V1itmZrY', title: 'Earning from Tunnel Farming in Pakistan', category: 'business', language: 'ur' },
  { id: 'LthvvZMHGH0', title: 'Pakistan Agriculture Revolution', category: 'business', language: 'ur' },
  { id: '1PGmQvDRuoU', title: 'Australian and Pakistani Agriculture Compared', category: 'business', language: 'ur' },
  { id: 'VwnyrE13Rvg', title: 'Hum Aur Hamari Zaraat: Episode 12', category: 'business', language: 'ur' },
  { id: 'IKXl7TgN3n4', title: 'Budget Impact on Pakistan’s Agriculture', category: 'business', language: 'ur' },
];

// Stable thumbnail + watch URLs for a catalogue entry.
export const thumbnailUrl = (id) => `https://i.ytimg.com/vi/${id}/mqdefault.jpg`;
export const watchUrl = (id) => `https://www.youtube.com/watch?v=${id}`;
export const embedUrl = (id) => `https://www.youtube.com/embed/${id}?autoplay=1&rel=0`;