import { ExternalLink } from 'lucide-react';
import { Dialog, DialogContent, DialogTitle } from '@/components/ui/dialog';
import { useI18n } from '@/i18n/LanguageContext';
import { embedUrl, watchUrl } from './videos';

// In-app YouTube player — opens over the Agro Vids grid and returns to it.
export default function VideoPlayerDialog({ video, onClose }) {
  const { t } = useI18n();

  return (
    <Dialog open={!!video} onOpenChange={(open) => { if (!open) onClose(); }}>
      <DialogContent className="max-w-3xl gap-0 overflow-hidden p-0">
        {video && (
          <>
            <div className="aspect-video w-full bg-black">
              <iframe
                src={embedUrl(video.id)}
                title={video.title}
                className="h-full w-full"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                allowFullScreen
              />
            </div>
            <div className="flex items-start justify-between gap-3 p-4 pr-12">
              <DialogTitle className="text-sm font-semibold leading-snug">{video.title}</DialogTitle>
              <a
                href={watchUrl(video.id)}
                target="_blank"
                rel="noreferrer"
                className="inline-flex shrink-0 items-center gap-1 text-xs font-medium text-primary hover:underline"
              >
                <ExternalLink className="h-3.5 w-3.5" />
                {t('videos.watchOnYouTube')}
              </a>
            </div>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}