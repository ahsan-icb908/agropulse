// Single source of truth for the platform documentation.
// The same blocks are rendered on the Documentation page and inside the PDF.

export const DOCS_META = {
  title: 'AgroPulse OS',
  subtitle: 'Platform Documentation',
  version: '1.0',
};

export const DOCS_BLOCKS = [
  { type: 'section', text: '1. What AgroPulse OS is' },
  {
    type: 'para',
    text: 'AgroPulse OS is an agricultural and community development platform. It brings farm records, field and crop tracking, environmental intelligence, hazard alerts, civic reporting, a biology research lab and a set of rural livelihood programmes into one interface, all tied to the same farm and field records.',
  },
  {
    type: 'para',
    text: 'Every page is available in English and Urdu. The Urdu option switches the whole interface to right-to-left layout.',
  },
  {
    type: 'note',
    text: 'Any record marked DEMONSTRATION is example material supplied to show how the platform works. It is not a real measurement, farm or study result.',
  },

  { type: 'section', text: '2. Getting started' },
  {
    type: 'bullets',
    items: [
      'Sign in with email and password, or with a connected Google account.',
      'Create a farm under Farms: name, location, area and the primary crop focus.',
      'Add fields to that farm under Fields: crop, area, sowing date, soil readings and optional map coordinates.',
      'Log work under tasks, and record what a field actually produced under harvests.',
      'Open the Map to see farms, fields, hazard alerts and community reports on one map.',
      'Use the Overview page as the daily starting point: weather, active alerts, upcoming tasks and community activity.',
    ],
  },

  { type: 'section', text: '3. Module reference' },
  { type: 'sub', text: 'Overview' },
  {
    type: 'para',
    text: 'A single dashboard of current conditions: farm totals, weather, hazard alerts, upcoming tasks, recent community reports and sustainability categories. Cards link into the module that owns each record.',
  },
  { type: 'sub', text: 'Farms and Fields' },
  {
    type: 'para',
    text: 'Farms hold the top-level location and area; fields belong to a farm and carry crop, area, sowing and harvest dates, growth stage, soil pH and soil moisture. Each field has a growth-stage tracker so the season history is dated and reviewable.',
  },
  { type: 'sub', text: 'Map' },
  {
    type: 'para',
    text: 'An interactive map of farms (area outline), fields (points), active hazard alerts and community reports, with layer toggles. Fields that sit close to an active alert are highlighted. A farm or field only appears at its true position once coordinates have been entered.',
  },
  { type: 'sub', text: 'AI Assistant and Crop Scan' },
  {
    type: 'para',
    text: 'The Assistant answers agronomy questions in plain language, and Crop Scan diagnoses a problem from a described symptom set and an optional photo. Both return guidance to confirm with an extension officer; they are decision support, not a diagnosis.',
  },
  { type: 'sub', text: 'Weather and Alerts' },
  {
    type: 'para',
    text: 'Current conditions and a short forecast, plus hazard alerts (heat, frost, rain, wind) raised against the farm location. Alerts surface on the Overview, the Map, the Weather page and in Notifications.',
  },
  { type: 'sub', text: 'SDG Explorer' },
  {
    type: 'para',
    text: 'The 17 Sustainable Development Goals as searchable, theme-filtered cards, with an indicator matrix. Each indicator carries a data type — measured, sourced, estimated or missing — so an unverified figure is never shown as a measurement.',
  },
  { type: 'sub', text: 'Programs (livelihood modules)' },
  {
    type: 'para',
    text: 'Sixteen SDG-linked tools, including the produce marketplace with mandi rates, farm labour jobs, equipment rental, land and tenancy contracts, a women entrepreneurs directory, composting, pesticide advisory, irrigation scheduling, nitrogen balance and a knowledge hub of extension material.',
  },
  { type: 'sub', text: 'Community reporting' },
  {
    type: 'para',
    text: 'Residents file civic issues — water leakage, drainage, flooded roads, waste, infrastructure, pollution, agricultural water access — with location, urgency and an optional photo. Each report gets a reference number and a dated status history, from submitted through resolved.',
  },
  { type: 'sub', text: 'Analytics' },
  {
    type: 'para',
    text: 'Yield summaries and charts built from your own records: yield, yield per hectare, harvested area, alert severity, civic report status and task status. A module with no records shows an empty state rather than invented numbers.',
  },
  { type: 'sub', text: 'Biology Lab' },
  {
    type: 'para',
    text: 'An exhibition-oriented teaching module that links the science to the farm: growth stages, plant organisation, nutrient and water cycles, the soil food web and a mapping of each app record type onto the biology it represents.',
  },
  { type: 'sub', text: 'Agro Vids' },
  {
    type: 'para',
    text: 'A curated, categorised library of agricultural training videos played inside the app.',
  },

  { type: 'section', text: '4. Biology Research Lab' },
  {
    type: 'para',
    text: 'The research lab is a structured record-keeping tool for a real school or college study: one experiment, its treatment groups, the individual plants in each group, and dated observations of those plants.',
  },
  { type: 'sub', text: 'Workflow' },
  {
    type: 'bullets',
    items: [
      'Create the experiment: title, research question, hypothesis, objectives, methodology, independent, dependent and controlled variables, measurement schedule and planned replicates.',
      'Add treatment groups, marking exactly one as the control, and set the water volume and frequency applied to each.',
      'Register individual plants per group with a plant code such as T1-3. Plants are the replicate unit.',
      'Record observations by date: height, leaf count, water applied, germination, plant condition, soil moisture and notes.',
      'Review Charts and analysis, then write the conclusion and print or export the report.',
    ],
  },
  { type: 'sub', text: 'Evidence labels' },
  {
    type: 'para',
    text: 'Every observation carries one of four labels: real measurement, labelled demonstration value, estimated value, or a flagged missing measurement. Counts by label are shown in the data-quality panel so a reader can see exactly what proportion of the dataset is measured.',
  },
  { type: 'sub', text: 'Calculations and units' },
  {
    type: 'bullets',
    items: [
      'Mean height (cm) = sum of valid plant heights ÷ number of plants measured.',
      'Sample standard deviation (cm) = square root of the sum of squared deviations ÷ (n − 1). Requires at least two readings.',
      'Change over time (cm) = mean of the latest date − mean of the first date, per group.',
      'Difference from control (cm) = treatment group mean − control group mean.',
      'Percentage difference (%) = (difference from control ÷ control mean) × 100. Not calculable when the control mean is zero.',
      'Germination (%) = germinated plants ÷ plants sown × 100.',
      'Mean leaf count = sum of leaf counts ÷ plants measured.',
      'Yield per hectare = harvested quantity ÷ harvested area. Unit follows the harvest record (kg, tons or maunds).',
    ],
  },
  { type: 'sub', text: 'Statistical caution' },
  {
    type: 'para',
    text: 'Repeated readings from the same plant are not independent replicates. The summary states the number of observations and the number of independent plants separately, and warns when several readings come from the same plants. Small samples show a standard deviation as not calculable instead of a misleading figure. Calculations are descriptive; they are not a significance test.',
  },
  { type: 'sub', text: 'Demonstration dataset' },
  {
    type: 'para',
    text: 'A clearly labelled demonstration experiment shows how a finished study looks. It is stored separately from real research, marked DEMO throughout, and can be reset at any time; resetting it never touches real experiments and observations.',
  },
  { type: 'sub', text: 'Reports and exhibition mode' },
  {
    type: 'para',
    text: 'The report view assembles the research question, hypothesis, method, group summary, results and conclusion, and marks which figures were generated by the platform rather than written by the researcher. Print styling hides the navigation and interface chrome, so the browser print dialogue or a PDF export gives a clean document. Exhibition mode presents the same study as a sequence of presentation slides.',
  },

  { type: 'section', text: '5. Data, privacy and access' },
  {
    type: 'bullets',
    items: [
      'Research records are private to the account that created them. Other signed-in users cannot read, change or delete them; workspace administrators can.',
      'Farm, field, harvest and civic records belong to the account that entered them.',
      'Uploaded evidence photos are stored privately and opened through short-lived signed links.',
      'Demo records are flagged in the data itself, not only in the interface, so they remain distinguishable in an export.',
    ],
  },

  { type: 'section', text: '6. Bilingual and accessibility' },
  {
    type: 'bullets',
    items: [
      'A language toggle switches the interface between English and Urdu, with right-to-left layout for Urdu.',
      'A voice guide can read page instructions aloud, for users who prefer listening to reading.',
      'Keyboard focus, labelled controls and readable contrast are applied across the interface.',
    ],
  },

  { type: 'section', text: '7. Known limitations' },
  {
    type: 'bullets',
    items: [
      'The AI Assistant and Crop Scan depend on the workspace integration credits for AI calls. When those credits are exhausted the features show an unavailable message and the rest of the app continues to work; this is a workspace billing limit, not an app fault.',
      'Map positions are only meaningful once real coordinates are entered for a farm or field.',
      'Civic report routing to a department is recorded in the report history; the platform does not transmit reports to any external authority.',
      'The documentation describes how the software behaves. It is not scientific validation of any experiment, and it is not agronomic advice.',
    ],
  },
];

export const DOCS_FOOTER = 'AgroPulse OS — Platform Documentation';