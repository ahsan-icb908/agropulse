import { useState } from 'react';
import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
import { LanguageProvider } from '@/i18n/LanguageContext';
import AppLayout from '@/components/layout/AppLayout';
// Auth pages
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
// App pages
import Home from '@/pages/Home';
import Farms from '@/pages/Farms';
import Fields from '@/pages/Fields';
import HarvestRecords from '@/pages/HarvestRecords';
import MapPage from '@/pages/MapPage';
import Assistant from '@/pages/Assistant';
import CropScan from '@/pages/CropScan';
import Weather from '@/pages/Weather';
import Community from '@/pages/Community';
import Analytics from '@/pages/Analytics';
import Settings from '@/pages/Settings';
import Notifications from '@/pages/Notifications';
import Programs from '@/pages/Programs';
import Marketplace from '@/pages/Marketplace';
import Jobs from '@/pages/Jobs';
import EquipmentRental from '@/pages/EquipmentRental';
import Contracts from '@/pages/Contracts';
import WomenDirectory from '@/pages/WomenDirectory';
import Composting from '@/pages/Composting';
import PesticideAdvisory from '@/pages/PesticideAdvisory';
import IrrigationManager from '@/pages/IrrigationManager';
import NitrogenBalance from '@/pages/NitrogenBalance';
import KnowledgeHub from '@/pages/KnowledgeHub';
import BiologyLab from '@/pages/BiologyLab';
import AgroVids from '@/pages/AgroVids';
import ResearchLab from '@/pages/ResearchLab';
import ResearchExperiment from '@/pages/ResearchExperiment';
import Documentation from '@/pages/Documentation';
import MandiConnect from '@/pages/MandiConnect';
import VoiceAssistant from '@/pages/VoiceAssistant';
import Impact from '@/pages/Impact';
import IntroAnimation from '@/components/IntroAnimation';
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<AppLayout />}>
          <Route path="/" element={<Home />} />
          <Route path="/farms" element={<Farms />} />
          <Route path="/fields" element={<Fields />} />
          <Route path="/map" element={<MapPage />} />
          <Route path="/assistant" element={<Assistant />} />
          <Route path="/crop-scan" element={<CropScan />} />
          <Route path="/weather" element={<Weather />} />
          <Route path="/harvest" element={<HarvestRecords />} />
          <Route path="/biology" element={<BiologyLab />} />
          <Route path="/agro-vids" element={<AgroVids />} />
          <Route path="/mandi-connect" element={<MandiConnect />} />
          <Route path="/voice" element={<VoiceAssistant />} />
          <Route path="/impact" element={<Impact />} />
          <Route path="/research" element={<ResearchLab />} />
          <Route path="/research/:experimentId" element={<ResearchExperiment />} />
          <Route path="/community" element={<Community />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/notifications" element={<Notifications />} />
          <Route path="/documentation" element={<Documentation />} />
          <Route path="/programs" element={<Programs />} />
          <Route path="/programs/marketplace" element={<Marketplace />} />
          <Route path="/programs/jobs" element={<Jobs />} />
          <Route path="/programs/equipment" element={<EquipmentRental />} />
          <Route path="/programs/contracts" element={<Contracts />} />
          <Route path="/programs/directory" element={<WomenDirectory />} />
          <Route path="/programs/composting" element={<Composting />} />
          <Route path="/programs/pesticide-advisory" element={<PesticideAdvisory />} />
          <Route path="/programs/irrigation" element={<IrrigationManager />} />
          <Route path="/programs/nitrogen-balance" element={<NitrogenBalance />} />
          <Route path="/programs/knowledge-hub" element={<KnowledgeHub />} />
          {/* Add your page Route elements here */}
        </Route>
      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {
  const [introDone, setIntroDone] = useState(false);
  return (
    <AuthProvider>
      <LanguageProvider>
        <QueryClientProvider client={queryClientInstance}>
          <Router>
            <ScrollToTop />
            <AuthenticatedApp />
            {!introDone && <IntroAnimation onComplete={() => setIntroDone(true)} />}
          </Router>
          <Toaster />
        </QueryClientProvider>
      </LanguageProvider>
    </AuthProvider>
  )
}

export default App