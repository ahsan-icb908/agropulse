import { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react';
import { translations } from './translations';

const LanguageContext = createContext(null);

const STORAGE_KEY = 'agropulse.lang';

export function LanguageProvider({ children }) {
  const [lang, setLang] = useState(() => {
    if (typeof window === 'undefined') return 'en';
    return localStorage.getItem(STORAGE_KEY) || 'en';
  });

  const dir = lang === 'ur' ? 'rtl' : 'ltr';

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, lang);
    const root = document.documentElement;
    root.setAttribute('dir', dir);
    root.setAttribute('lang', lang);
    if (lang === 'ur') root.classList.add('font-urdu');
    else root.classList.remove('font-urdu');
  }, [lang, dir]);

  const t = useCallback(
    (key) => {
      const en = translations.en[key];
      const tr = translations[lang] && translations[lang][key];
      return tr || en || key;
    },
    [lang]
  );

  const toggleLang = useCallback(() => {
    setLang((prev) => (prev === 'en' ? 'ur' : 'en'));
  }, []);

  const value = useMemo(() => ({ lang, dir, t, setLang, toggleLang }), [lang, dir, t, toggleLang]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

export function useI18n() {
  const ctx = useContext(LanguageContext);
  if (!ctx) throw new Error('useI18n must be used within LanguageProvider');
  return ctx;
}