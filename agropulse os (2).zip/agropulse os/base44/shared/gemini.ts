import { secrets } from "base44:runtime";

// Shared Gemini client. The key lives only in the workspace secret
// GEMINI_API_KEY and is never returned to the browser.
const MODELS = ["gemini-3.8-flash", "gemini-flash-latest"];
const ATTEMPT_TIMEOUT_MS = 22000;

function buildBody({ prompt, systemInstruction, jsonSchema, useSearch, images }) {
  const generationConfig = { temperature: 0.4 };
  if (jsonSchema) {
    generationConfig.responseMimeType = "application/json";
    generationConfig.responseSchema = jsonSchema;
  }

  const parts = [{ text: prompt }];
  for (const image of images || []) {
    parts.push({ inlineData: { mimeType: image.mimeType, data: image.data } });
  }

  const body = {
    contents: [{ role: "user", parts }],
    generationConfig,
  };
  if (systemInstruction) body.systemInstruction = { parts: [{ text: systemInstruction }] };
  if (useSearch) body.tools = [{ google_search: {} }];
  return body;
}

async function attemptModel(model, body, key) {
  let res;
  try {
    res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(ATTEMPT_TIMEOUT_MS),
      }
    );
  } catch (error) {
    return { ok: false, error: "timeout", message: `${model} did not answer in time.` };
  }

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const message = data?.error?.message || `Gemini returned HTTP ${res.status}`;
    const quota = res.status === 429 || /quota|rate limit|billing/i.test(message);
    return { ok: false, quota, error: quota ? "quota" : "gemini_http", message };
  }

  const text = (data?.candidates?.[0]?.content?.parts || [])
    .map((part) => part?.text || "")
    .join("")
    .trim();

  if (!text) return { ok: false, error: "empty", message: "Gemini returned an empty answer." };
  return { ok: true, text };
}

export async function callGemini(params) {
  const key = secrets.get("GEMINI_API_KEY");
  if (!key || !String(key).trim()) {
    return { error: "missing_key", message: "GEMINI_API_KEY is not configured for this app." };
  }

  const body = buildBody(params);
  let lastError = { error: "unavailable", message: "Gemini did not answer. Try again." };

  for (const model of MODELS) {
    const result = await attemptModel(model, body, String(key).trim());
    if (result.ok) return { text: result.text };
    if (result.quota) {
      return {
        error: "quota",
        message: "Your Gemini API key has reached its quota or billing limit. Check the key's plan in Google AI Studio.",
      };
    }
    lastError = { error: result.error, message: result.message };
  }

  return lastError;
}