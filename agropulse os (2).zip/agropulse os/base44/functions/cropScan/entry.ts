import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { callGemini } from '../../shared/gemini.ts';

const MAX_BYTES = 8 * 1024 * 1024;
const ALLOWED = ['image/jpeg', 'image/png', 'image/webp'];

const SCHEMA = {
  type: 'object',
  properties: {
    diagnosis: { type: 'string' },
    confidence: { type: 'number' },
    possible_causes: { type: 'array', items: { type: 'string' } },
    next_steps: { type: 'array', items: { type: 'string' } },
    needs_expert: { type: 'boolean' },
    note: { type: 'string' },
  },
  required: ['diagnosis', 'possible_causes', 'next_steps', 'needs_expert'],
};

const SYSTEM = [
  'You are an agronomy assistant reviewing a farmer photo from Pakistan.',
  'Look for disease, pest damage, nutrient deficiency or water stress.',
  'Be conservative: if the image is unclear or is not a plant, set diagnosis to "Unclear image" and omit confidence.',
  'Never fabricate a precise disease name or a chemical dose from a low-quality image.',
  'Write the diagnosis, causes and steps in simple English.',
].join(' ');

function toBase64(bytes) {
  let binary = '';
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const imageUrl = String(body.image_url || '').trim();
    const crop = String(body.crop || '').trim();
    const symptoms = String(body.symptoms || '').trim();

    if (!imageUrl) return Response.json({ error: 'image_url is required' }, { status: 400 });

    let imgRes;
    try {
      imgRes = await fetch(imageUrl, { signal: AbortSignal.timeout(20000) });
    } catch {
      return Response.json({ status: 'unavailable', message: 'The photo could not be read. Try uploading it again.' });
    }
    if (!imgRes.ok) {
      return Response.json({ status: 'unavailable', message: 'The photo could not be read. Try uploading it again.' });
    }

    const mimeType = (imgRes.headers.get('content-type') || '').split(';')[0].trim() || 'image/jpeg';
    if (!ALLOWED.includes(mimeType)) {
      return Response.json({ error: 'Only JPG, PNG or WebP photos can be scanned.' }, { status: 400 });
    }

    const bytes = new Uint8Array(await imgRes.arrayBuffer());
    if (bytes.byteLength > MAX_BYTES) {
      return Response.json({ error: 'The photo is larger than 8 MB.' }, { status: 400 });
    }

    const prompt = [
      `Analyse this crop photo${crop ? ` (crop: ${crop})` : ''}.`,
      symptoms ? `The farmer describes these symptoms: "${symptoms}".` : 'The farmer gave no symptom description.',
      'Return the diagnosis, up to 3 possible causes, up to 3 practical next steps, whether a human agronomist should confirm, and a one-line caveat.',
    ].join(' ');

    const result = await callGemini({
      prompt,
      systemInstruction: SYSTEM,
      jsonSchema: SCHEMA,
      images: [{ mimeType, data: toBase64(bytes) }],
    });

    if (result.error === 'missing_key') {
      return Response.json({
        status: 'unconfigured',
        message: 'The Gemini API key is not set for this app yet, so the scan cannot run.',
      });
    }
    if (result.error) return Response.json({ status: 'unavailable', message: result.message });

    let parsed;
    try {
      parsed = JSON.parse(result.text);
    } catch {
      return Response.json({ status: 'unavailable', message: 'The scan result could not be read. Try again.' });
    }

    return Response.json({
      status: 'ok',
      diagnosis: parsed.diagnosis || 'Unclear image',
      confidence: typeof parsed.confidence === 'number' ? Math.round(parsed.confidence) : null,
      possible_causes: Array.isArray(parsed.possible_causes) ? parsed.possible_causes.slice(0, 3) : [],
      next_steps: Array.isArray(parsed.next_steps) ? parsed.next_steps.slice(0, 3) : [],
      needs_expert: !!parsed.needs_expert,
      note: parsed.note || '',
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}