import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { callGemini } from '../../shared/gemini.ts';

const SYSTEM = [
  'You are AgroPulse AgriBot, an agronomy assistant for smallholder farmers in Pakistan.',
  'Answer in the same language the farmer used: English, Urdu script, or Roman Urdu.',
  'Be concise and practical: at most 4 short paragraphs or a short numbered list.',
  'Separate verified agronomic advice from estimates, and never invent pesticide or fertiliser doses —',
  'tell the farmer to confirm any chemical and its dose with the local agriculture officer.',
  'If the question is outside farming, say briefly what you can help with instead.',
].join(' ');

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const message = String(body.message || '').trim();
    const context = String(body.context || '').slice(0, 1500);
    const history = Array.isArray(body.history) ? body.history.slice(-6) : [];

    if (message.length < 2) return Response.json({ error: 'message is required' }, { status: 400 });
    if (message.length > 1500) return Response.json({ error: 'message is too long' }, { status: 400 });

    const transcript = history
      .filter((m) => m && m.content)
      .map((m) => `${m.role === 'user' ? 'Farmer' : 'AgriBot'}: ${String(m.content).slice(0, 500)}`)
      .join('\n');

    const prompt = [
      context ? `Farm context: ${context}` : '',
      transcript ? `Earlier in this conversation:\n${transcript}` : '',
      `Farmer's question: ${message}`,
      'Answer as instructed.',
    ].filter(Boolean).join('\n\n');

    const result = await callGemini({ prompt, systemInstruction: SYSTEM });

    if (result.error === 'missing_key') {
      return Response.json({
        status: 'unconfigured',
        message: 'The Gemini API key is not set for this app yet, so the assistant cannot answer.',
      });
    }
    if (result.error) return Response.json({ status: 'unavailable', message: result.message });

    return Response.json({ status: 'ok', answer: result.text });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}