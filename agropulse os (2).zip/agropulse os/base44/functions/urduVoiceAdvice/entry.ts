import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { callGemini } from '../../shared/gemini.ts';

const SCHEMA = {
  type: 'object',
  properties: {
    answer_ur: { type: 'string' },
    answer_en: { type: 'string' },
    urgency: { type: 'string' },
    actions: { type: 'array', items: { type: 'string' } },
  },
  required: ['answer_ur', 'answer_en'],
};

const SYSTEM = [
  'You are AgroPulse Salahkar, a crop advisor for smallholder farmers in Pakistan.',
  'The farmer usually speaks in Urdu, sometimes with limited literacy.',
  'Answer in very simple Urdu script, 2 to 4 short sentences, no English words where an Urdu word exists.',
  'Then give the same advice in simple English.',
  'Give 2 or 3 practical next actions, written in Urdu.',
  'Set urgency to low, medium or high based on how fast the crop could be lost.',
  'Never invent pesticide or fertiliser doses; tell the farmer to confirm any chemical with the local agriculture officer.',
  'If the question is unclear, say briefly what you still need to know.',
].join(' ');

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const question = String(body.question || '').trim();
    const crop = String(body.crop || '').trim();
    const location = String(body.location || '').trim();

    if (question.length < 3) {
      return Response.json({ error: 'question is required' }, { status: 400 });
    }
    if (question.length > 800) {
      return Response.json({ error: 'question is too long' }, { status: 400 });
    }

    const prompt = [
      `Farmer's question (Urdu speech transcript): "${question}"`,
      crop ? `Crop: ${crop}` : '',
      location ? `Location: ${location}, Pakistan` : '',
      'Answer as instructed.',
    ].filter(Boolean).join('\n');

    const result = await callGemini({ prompt, jsonSchema: SCHEMA, systemInstruction: SYSTEM });

    if (result.error === 'missing_key') {
      return Response.json({
        status: 'unconfigured',
        message: 'The Gemini API key is not set for this app yet, so the voice assistant cannot answer.',
      });
    }
    if (result.error) {
      return Response.json({ status: 'unavailable', message: result.message });
    }

    let parsed;
    try {
      parsed = JSON.parse(result.text);
    } catch {
      return Response.json({ status: 'unavailable', message: 'The answer could not be read. Try again.' });
    }

    return Response.json({
      status: 'ok',
      question,
      answer_ur: parsed.answer_ur || '',
      answer_en: parsed.answer_en || '',
      urgency: ['low', 'medium', 'high'].includes(parsed.urgency) ? parsed.urgency : 'medium',
      actions: Array.isArray(parsed.actions) ? parsed.actions.slice(0, 3) : [],
      source: 'Gemini advice — confirm chemicals and doses with your local agriculture officer',
      retrieved_at: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}