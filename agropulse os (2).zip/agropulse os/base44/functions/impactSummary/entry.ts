import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';

// Documented assumptions — mirrored in the app's methodology page.
const WATER_L_PER_HA = 150000;      // litres of irrigation water avoided per active hectare per season (optimised scheduling)
const COMPOST_FERT_FACTOR = 0.35;   // kg of chemical fertiliser replaced by 1 kg of finished compost (N-equivalent)
const COMMISSION_RATE = 0.15;       // mandi commission + arhat spread avoided on a direct sale

const KG_FACTOR = { kg: 1, tons: 1000, maunds: 40, bag: 50, dozen: 0 };

function toKg(quantity, unit) {
  return (Number(quantity) || 0) * (KG_FACTOR[unit] ?? 1);
}

function pricePerKg(price, priceUnit, quantityKg) {
  const p = Number(price) || 0;
  if (priceUnit === 'per_maund') return p / 40;
  if (priceUnit === 'per_bag') return p / 50;
  if (priceUnit === 'total') return quantityKg > 0 ? p / quantityKg : 0;
  if (priceUnit === 'per_kg') return p;
  return 0; // per_dozen is not a weight measure
}

async function fetchAll(entity) {
  const items = [];
  let cursor;
  for (let page = 0; page < 5; page += 1) {
    const res = await entity.filter({}, { limit: 500, cursor });
    items.push(...(res.items || []));
    if (!res.has_more) break;
    cursor = res.next_cursor;
  }
  return items;
}

const blank = () => ({
  water_liters: 0,
  fertilizer_kg: 0,
  middleman_pkr: 0,
  from_records: { water_liters: 0, fertilizer_kg: 0, middleman_pkr: 0 },
  from_manual: { water_liters: 0, fertilizer_kg: 0, middleman_pkr: 0 },
});

function add(bucket, values, kind) {
  bucket.water_liters += values.water_liters;
  bucket.fertilizer_kg += values.fertilizer_kg;
  bucket.middleman_pkr += values.middleman_pkr;
  bucket[kind].water_liters += values.water_liters;
  bucket[kind].fertilizer_kg += values.fertilizer_kg;
  bucket[kind].middleman_pkr += values.middleman_pkr;
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const admin = base44.asServiceRole;
    const [fields, compost, listings, savings] = await Promise.all([
      fetchAll(admin.entities.Field),
      fetchAll(admin.entities.CompostBatch),
      fetchAll(admin.entities.Listing),
      fetchAll(admin.entities.ImpactSaving),
    ]);

    const platform = blank();
    const mine = blank();
    const counts = { fields: 0, compost_batches: 0, direct_listings: 0, manual_entries: 0 };

    const record = (values, createdById) => {
      add(platform, values, 'from_records');
      if (createdById === user.id) add(mine, values, 'from_records');
    };

    fields.forEach((field) => {
      if (field.status === 'harvested' || field.status === 'fallow') return;
      const water = (Number(field.area_hectares) || 0) * WATER_L_PER_HA;
      if (water <= 0) return;
      counts.fields += 1;
      record({ water_liters: water, fertilizer_kg: 0, middleman_pkr: 0 }, field.created_by_id);
    });

    compost.forEach((batch) => {
      if (!['ready', 'used'].includes(batch.status)) return;
      const fert = (Number(batch.volume_kg) || 0) * COMPOST_FERT_FACTOR;
      if (fert <= 0) return;
      counts.compost_batches += 1;
      record({ water_liters: 0, fertilizer_kg: fert, middleman_pkr: 0 }, batch.created_by_id);
    });

    listings.forEach((listing) => {
      if (listing.status !== 'sold') return;
      const kg = toKg(listing.quantity, listing.quantity_unit);
      const perKg = pricePerKg(listing.price, listing.price_unit, kg);
      const saved = kg * perKg * COMMISSION_RATE;
      if (saved <= 0) return;
      counts.direct_listings += 1;
      record({ water_liters: 0, fertilizer_kg: 0, middleman_pkr: saved }, listing.created_by_id);
    });

    savings.forEach((entry) => {
      const values = {
        water_liters: Number(entry.water_liters) || 0,
        fertilizer_kg: Number(entry.fertilizer_kg) || 0,
        middleman_pkr: Number(entry.middleman_pkr) || 0,
      };
      if (values.water_liters + values.fertilizer_kg + values.middleman_pkr <= 0) return;
      counts.manual_entries += 1;
      add(platform, values, 'from_manual');
      if (entry.created_by_id === user.id) add(mine, values, 'from_manual');
    });

    const tidy = (bucket) => ({
      water_liters: Math.round(bucket.water_liters),
      fertilizer_kg: Math.round(bucket.fertilizer_kg * 10) / 10,
      middleman_pkr: Math.round(bucket.middleman_pkr),
      from_records: {
        water_liters: Math.round(bucket.from_records.water_liters),
        fertilizer_kg: Math.round(bucket.from_records.fertilizer_kg * 10) / 10,
        middleman_pkr: Math.round(bucket.from_records.middleman_pkr),
      },
      from_manual: {
        water_liters: Math.round(bucket.from_manual.water_liters),
        fertilizer_kg: Math.round(bucket.from_manual.fertilizer_kg * 10) / 10,
        middleman_pkr: Math.round(bucket.from_manual.middleman_pkr),
      },
    });

    return Response.json({
      mine: tidy(mine),
      platform: tidy(platform),
      counts,
      constants: {
        water_liters_per_hectare: WATER_L_PER_HA,
        compost_fertilizer_factor: COMPOST_FERT_FACTOR,
        commission_rate: COMMISSION_RATE,
      },
      generated_at: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}