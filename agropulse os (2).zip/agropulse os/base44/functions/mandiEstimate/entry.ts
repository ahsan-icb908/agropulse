import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { callGemini } from '../../shared/gemini.ts';

const SCHEMA = {
  type: 'object',
  properties: {
    benchmark_price_per_kg: { type: 'number' },
    mandi_price_per_kg: { type: 'number' },
    fair_margin_percent: { type: 'number' },
    price_basis: { type: 'string' },
    assumptions: { type: 'array', items: { type: 'string' } },
    notes_en: { type: 'string' },
    notes_ur: { type: 'string' },
  },
  required: ['benchmark_price_per_kg', 'mandi_price_per_kg', 'fair_margin_percent'],
};

const KG_FACTOR = { kg: 1, tons: 1000, maunds: 40, bag: 50, dozen: 0 };

function round(value) {
  return Math.round(Number(value) || 0);
}

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const crop = String(body.crop || '').trim();
    const mandi = String(body.mandi || '').trim();
    const location = String(body.location || '').trim();
    const quantity = Number(body.quantity) || 0;
    const unit = String(body.quantity_unit || 'kg');

    if (!crop) return Response.json({ error: 'crop is required' }, { status: 400 });
    if (crop.length > 80 || mandi.length > 80 || location.length > 80) {
      return Response.json({ error: 'input too long' }, { status: 400 });
    }

    const marketLine = mandi
      ? `The farmer sells at or near the ${mandi} mandi${location ? ` (district: ${location})` : ''}.`
      : `The farmer has not chosen a specific mandi${location ? `; they are located near ${location}` : ''}. Use a Pakistan-wide average mandi price.`;

    const prompt = [
      `Estimate the current wholesale (mandi) price in Pakistan for this produce: ${crop}.`,
      marketLine,
      quantity > 0 ? `The farmer has ${quantity} ${unit} to sell.` : '',
      'Use the most recent available Pakistani mandi / wholesale price information.',
      'Report both a Pakistan-wide benchmark price per kg and a price per kg for the chosen mandi.',
      'Recommend a fair profit margin percent for a farmer selling directly to consumers (fair for the farmer, still attractive to a buyer), between 8 and 35.',
      'State the price basis briefly (what market, what period, wholesale or retail).',
      'List 2-4 short assumptions or caveats.',
      'Write notes_en in simple English and notes_ur in simple Urdu script for a farmer with limited literacy.',
      'All prices in PKR per kg. This is an estimate for guidance, never a verified live market feed.',
    ].filter(Boolean).join('\n');

    const result = await callGemini({
      prompt,
      jsonSchema: SCHEMA,
      useSearch: true,
      systemInstruction:
        'You are a Pakistani agricultural market analyst. Give cautious, realistic price estimates in PKR per kg. Never claim a price is official or verified. Keep language simple.',
    });

    if (result.error === 'missing_key') {
      return Response.json({
        status: 'unconfigured',
        message: 'The Gemini API key is not set for this app yet, so estimates are unavailable.',
      });
    }
    if (result.error) {
      return Response.json({ status: 'unavailable', message: result.message });
    }

    let parsed;
    try {
      parsed = JSON.parse(result.text);
    } catch {
      return Response.json({ status: 'unavailable', message: 'The estimate could not be read. Try again.' });
    }

    const benchmark = Number(parsed.benchmark_price_per_kg) || 0;
    const mandiPrice = Number(parsed.mandi_price_per_kg) || benchmark;
    if (!benchmark && !mandiPrice) {
      return Response.json({ status: 'unavailable', message: 'No usable price was returned for this crop.' });
    }

    const marginRaw = Number(parsed.fair_margin_percent) || 15;
    const fairMargin = Math.min(35, Math.max(8, Math.round(marginRaw)));
    const base = mandiPrice || benchmark;
    const suggested = round(base * (1 + fairMargin / 100));

    return Response.json({
      status: 'ok',
      crop,
      mandi: mandi || 'Pakistan-wide',
      benchmark_price_per_kg: round(benchmark),
      mandi_price_per_kg: round(base),
      fair_margin_percent: fairMargin,
      suggested_price_per_kg: suggested,
      range_low_per_kg: round(suggested * 0.95),
      range_high_per_kg: round(suggested * 1.08),
      quantity_kg: round(quantity * (KG_FACTOR[unit] ?? 1)),
      price_basis: parsed.price_basis || '',
      assumptions: Array.isArray(parsed.assumptions) ? parsed.assumptions.slice(0, 4) : [],
      notes_en: parsed.notes_en || '',
      notes_ur: parsed.notes_ur || '',
      source: 'Gemini estimate (Google Search grounded) — not a verified live mandi feed',
      retrieved_at: new Date().toISOString(),
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}